"""Identity REST surface: signup/login, session (Bearer JWT), API keys."""

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models import User
from app.schemas.identity import (
    LoginRequest,
    MeResponse,
    SignupRequest,
    SignupResponse,
    TokenResponse,
)
from app.services.auth_service import AuthService, get_token_user

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])

DbSession = Annotated[Session, Depends(get_db)]


def current_user(request: Request, db: DbSession) -> User:
    header = request.headers.get("Authorization", "")
    if not header.lower().startswith("bearer "):
        from app.core.errors import UnauthorizedError

        raise UnauthorizedError("Missing bearer token")
    return get_token_user(db, header.split(" ", 1)[1].strip())


@router.post("/signup", response_model=SignupResponse, status_code=201)
def signup(body: SignupRequest, db: DbSession) -> dict:
    return AuthService(db).signup(
        email=body.email, password=body.password,
        name=body.name, org_name=body.org_name,
    )


@router.post("/login", response_model=TokenResponse)
def login(body: LoginRequest, db: DbSession) -> dict:
    return AuthService(db).login(email=body.email, password=body.password)


@router.get("/me", response_model=MeResponse)
def me(user: Annotated[User, Depends(current_user)], db: DbSession) -> dict:
    return AuthService(db).me(user.id)


@router.post("/api-keys")
def issue_api_key(
    request: Request,
    name: str,
    user: Annotated[User, Depends(current_user)],
    db: DbSession,
) -> dict:
    org_id = request.state.org_id
    if not org_id:
        from app.core.errors import UnauthorizedError

        raise UnauthorizedError("Missing X-Org-Id header")
    return AuthService(db).issue_api_key(
        org_id=uuid.UUID(str(org_id)), user_id=user.id, name=name,
    )
