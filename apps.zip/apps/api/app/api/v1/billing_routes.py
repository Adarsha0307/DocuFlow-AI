"""Billing REST surface: plan, checkout, subscription, Stripe webhook handoff."""

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.v1.auth_routes import current_user
from app.db.session import get_db
from app.models import User
from app.schemas.content import (
    CheckoutRequest,
    CheckoutResponse,
    PlanRead,
    SubscriptionRead,
    WebhookEvent,
    WebhookResponse,
)
from app.services.billing_service import BillingService

router = APIRouter(prefix="/api/v1/orgs/{org_id}/billing", tags=["billing"])

DbSession = Annotated[Session, Depends(get_db)]
CurrentUser = Annotated[User, Depends(current_user)]


@router.get("/plan", response_model=PlanRead)
def get_plan(org_id: uuid.UUID, user: CurrentUser, db: DbSession) -> PlanRead:
    del user
    return PlanRead(**BillingService(db).current_plan(org_id))


@router.post("/checkout", response_model=CheckoutResponse)
def create_checkout(org_id: uuid.UUID, body: CheckoutRequest,
                    user: CurrentUser, db: DbSession) -> CheckoutResponse:
    return CheckoutResponse(**BillingService(db).checkout_session(
        org_id=org_id, user_id=user.id, plan_code=body.plan_code,
    ))


@router.get("/subscription", response_model=SubscriptionRead)
def get_subscription(org_id: uuid.UUID, user: CurrentUser, db: DbSession) -> SubscriptionRead:
    del user
    sub = BillingService(db).subscription(org_id)
    if not sub:
        from app.core.errors import NotFoundError

        raise NotFoundError("No subscription yet")
    return sub


@router.post("/subscription/activate", response_model=SubscriptionRead)
def activate_subscription(org_id: uuid.UUID, body: CheckoutRequest,
                          user: CurrentUser, db: DbSession) -> SubscriptionRead:
    del user
    return BillingService(db).apply_subscription(org_id=org_id, plan_code=body.plan_code)


@router.post("/webhook", response_model=WebhookResponse, include_in_schema=False)
def webhook(body: WebhookEvent, db: DbSession) -> WebhookResponse:
    return WebhookResponse(**BillingService(db).handle_webhook(body.model_dump()))
