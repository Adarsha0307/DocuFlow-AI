"""REST surface for project content: scripts, scenes, assets, characters, prompts, voiceovers, thumbnails."""

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.v1.auth_routes import current_user
from app.db.session import get_db
from app.models import User
from app.schemas.content import (
    AssetCreate,
    AssetRead,
    AssetScoreUpdate,
    CharacterCreate,
    CharacterRead,
    PromptCreate,
    PromptRead,
    PromptVersionizeRequest,
    SceneCreate,
    SceneRead,
    SceneRevise,
    SceneVersionRead,
    ScriptCreate,
    ScriptRead,
    ScriptRevise,
    ScriptVersionRead,
    ThumbnailCreate,
    ThumbnailRead,
    VoiceoverCreate,
    VoiceoverRead,
)
from app.services.content_service import (
    AssetService,
    CharacterService,
    ContentService,
    PromptService,
    ThumbnailService,
    VoiceoverService,
)

router = APIRouter(prefix="/api/v1/orgs/{org_id}/projects/{project_id}", tags=["content"])

DbSession = Annotated[Session, Depends(get_db)]
CurrentUser = Annotated[User, Depends(current_user)]


# --- scripts ---------------------------------------------------------------
@router.post("/scripts", response_model=ScriptRead, status_code=201)
def create_script(org_id: uuid.UUID, project_id: uuid.UUID, body: ScriptCreate,
                  user: CurrentUser, db: DbSession) -> ScriptRead:
    return ContentService(db).create_script(
        org_id=org_id, user_id=user.id, project_id=project_id,
        title=body.title, body=body.body, language=body.language,
    )


@router.get("/scripts", response_model=list[ScriptRead])
def list_scripts(org_id: uuid.UUID, project_id: uuid.UUID,
                 user: CurrentUser, db: DbSession) -> list[ScriptRead]:
    return ContentService(db).list_scripts(org_id=org_id, user_id=user.id, project_id=project_id)


@router.get("/scripts/{script_id}", response_model=ScriptRead)
def get_script(script_id: uuid.UUID, org_id: uuid.UUID,
               user: CurrentUser, db: DbSession) -> ScriptRead:
    return ContentService(db).get_script(script_id, org_id=org_id, user_id=user.id)


@router.post("/scripts/{script_id}/revisions", response_model=ScriptVersionRead, status_code=201)
def revise_script(script_id: uuid.UUID, org_id: uuid.UUID, body: ScriptRevise,
                  user: CurrentUser, db: DbSession) -> ScriptVersionRead:
    return ContentService(db).revise_script(
        org_id=org_id, user_id=user.id, script_id=script_id, body=body.body, notes=body.notes,
    )


# --- scenes ---------------------------------------------------------------
@router.post("/scenes", response_model=SceneRead, status_code=201)
def create_scene(org_id: uuid.UUID, project_id: uuid.UUID, body: SceneCreate,
                 user: CurrentUser, db: DbSession) -> SceneRead:
    return ContentService(db).create_scene(
        org_id=org_id, user_id=user.id, project_id=project_id,
        scene_number=body.scene_number, title=body.title, narration=body.narration,
        visual_direction=body.visual_direction, duration_seconds=body.duration_seconds,
    )


@router.get("/scenes", response_model=list[SceneRead])
def list_scenes(org_id: uuid.UUID, project_id: uuid.UUID,
                user: CurrentUser, db: DbSession) -> list[SceneRead]:
    return ContentService(db).list_scenes(org_id=org_id, user_id=user.id, project_id=project_id)


@router.patch("/scenes/{scene_id}", response_model=SceneVersionRead)
def revise_scene(scene_id: uuid.UUID, org_id: uuid.UUID, body: SceneRevise,
                 user: CurrentUser, db: DbSession) -> SceneVersionRead:
    return ContentService(db).revise_scene(
        org_id=org_id, user_id=user.id, scene_id=scene_id,
        narration=body.narration, visual_direction=body.visual_direction,
    )


# --- assets ----------------------------------------------------------------
@router.post("/assets", response_model=AssetRead, status_code=201)
def create_asset(org_id: uuid.UUID, project_id: uuid.UUID, body: AssetCreate,
                 user: CurrentUser, db: DbSession) -> AssetRead:
    return AssetService(db).create(
        org_id=org_id, user_id=user.id, project_id=project_id, kind=body.kind, name=body.name,
        storage_key=body.storage_key, public_url=body.public_url, mime_type=body.mime_type,
        scene_id=body.scene_id, provider=body.provider, provenance=body.provenance,
    )


@router.get("/assets", response_model=list[AssetRead])
def list_assets(org_id: uuid.UUID, project_id: uuid.UUID, user: CurrentUser, db: DbSession,
                kind: str | None = None) -> list[AssetRead]:
    return AssetService(db).list(org_id=org_id, user_id=user.id, project_id=project_id, kind=kind)


@router.patch("/assets/{asset_id}/score", response_model=AssetRead)
def score_asset(asset_id: uuid.UUID, org_id: uuid.UUID, body: AssetScoreUpdate,
                user: CurrentUser, db: DbSession) -> AssetRead:
    return AssetService(db).score(asset_id, org_id=org_id, user_id=user.id, score=body.score)


# --- characters -------------------------------------------------------------
@router.post("/characters", response_model=CharacterRead, status_code=201)
def create_character(org_id: uuid.UUID, project_id: uuid.UUID, body: CharacterCreate,
                     user: CurrentUser, db: DbSession) -> CharacterRead:
    return CharacterService(db).create(
        org_id=org_id, user_id=user.id, project_id=project_id,
        name=body.name, role=body.role, appearance_prompt=body.appearance_prompt,
    )


@router.get("/characters", response_model=list[CharacterRead])
def list_characters(org_id: uuid.UUID, project_id: uuid.UUID,
                    user: CurrentUser, db: DbSession) -> list[CharacterRead]:
    del user
    return CharacterService(db).list(org_id=org_id, project_id=project_id)


# --- prompts ----------------------------------------------------------------
@router.post("/prompts", response_model=PromptRead, status_code=201)
def create_prompt(org_id: uuid.UUID, project_id: uuid.UUID, body: PromptCreate,
                  user: CurrentUser, db: DbSession) -> PromptRead:
    del user, org_id
    return PromptService(db).create(
        project_id=project_id, scene_id=body.scene_id, target=body.target,
        kind=body.kind, text=body.text, negative_prompt=body.negative_prompt,
    )


@router.get("/prompts", response_model=list[PromptRead])
def list_prompts(org_id: uuid.UUID, project_id: uuid.UUID,
                 user: CurrentUser, db: DbSession) -> list[PromptRead]:
    del user, org_id
    return PromptService(db).list_for_project(project_id)


@router.post("/prompts/{prompt_id}/versions", response_model=PromptRead, status_code=201)
def versionize_prompt(prompt_id: uuid.UUID, org_id: uuid.UUID, body: PromptVersionizeRequest,
                      user: CurrentUser, db: DbSession) -> PromptRead:
    del org_id, user
    from app.models import Prompt

    PromptService(db).versionize(prompt_id, body.text)
    prompt = db.get(Prompt, prompt_id)
    if prompt is None:
        from app.core.errors import NotFoundError

        raise NotFoundError("Prompt not found")
    return prompt


# --- voiceovers / thumbnails -------------------------------------------------
@router.post("/voiceovers", response_model=VoiceoverRead, status_code=201)
def create_voiceover(org_id: uuid.UUID, project_id: uuid.UUID, body: VoiceoverCreate,
                     user: CurrentUser, db: DbSession) -> VoiceoverRead:
    del user
    return VoiceoverService(db).create(
        organization_id=org_id, project_id=project_id, voice=body.voice, language=body.language,
        sample_url=body.sample_url, character_count=body.character_count,
        duration_seconds=body.duration_seconds,
    )


@router.post("/thumbnails", response_model=ThumbnailRead, status_code=201)
def create_thumbnail(org_id: uuid.UUID, project_id: uuid.UUID, body: ThumbnailCreate,
                     user: CurrentUser, db: DbSession) -> ThumbnailRead:
    del user
    return ThumbnailService(db).create(
        organization_id=org_id, project_id=project_id, title_text=body.title_text,
        style=body.style, preview_url=body.preview_url, prompt_id=body.prompt_id,
    )


@router.get("/thumbnails", response_model=list[ThumbnailRead])
def list_thumbnails(org_id: uuid.UUID, project_id: uuid.UUID,
                    user: CurrentUser, db: DbSession) -> list[ThumbnailRead]:
    del org_id, user
    return ThumbnailService(db).list(project_id)
