"""MCP (Model Context Protocol) JSON-RPC endpoint."""

from typing import Annotated

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session

from app.api.v1.auth_routes import current_user
from app.db.session import get_db
from app.mcp.server import McpError, error_json, handle
from app.models import User

router = APIRouter(prefix="/api/v1/mcp", tags=["mcp"])

DbSession = Annotated[Session, Depends(get_db)]
CurrentUser = Annotated[User, Depends(current_user)]


@router.post("", response_model=dict)
def mcp_endpoint(request: Request, user: CurrentUser, db: DbSession,
                 body: dict) -> dict | JSONResponse:
    """JSON-RPC 2.0 entrypoint for MCP clients (initialize, tools/list, tools/call)."""
    org_id = getattr(request.state, "org_id", None)
    request_id = body.get("id")
    try:
        return handle(db, user, str(org_id) if org_id else None, body)
    except McpError as exc:
        return JSONResponse(status_code=200, content=error_json(exc, request_id))
