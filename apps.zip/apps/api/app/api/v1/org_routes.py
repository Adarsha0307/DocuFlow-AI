"""Organization & team REST surface."""

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.v1.auth_routes import current_user
from app.db.session import get_db
from app.models import Organization, User
from app.models.enums import Role
from app.schemas.identity import (
    AcceptInvite,
    InviteCreate,
    InviteRead,
    MemberRead,
    OrganizationRead,
    OrgCreate,
    OrgUpdate,
    RoleUpdate,
)
from app.services.org_service import OrgService

router = APIRouter(prefix="/api/v1/orgs", tags=["orgs"])

DbSession = Annotated[Session, Depends(get_db)]
CurrentUser = Annotated[User, Depends(current_user)]


@router.post("", response_model=OrganizationRead, status_code=201)
def create_org(body: OrgCreate, user: CurrentUser, db: DbSession) -> Organization:
    return OrgService(db).create(user_id=user.id, name=body.name, slug=body.slug)


@router.get("", response_model=list[OrganizationRead])
def my_orgs(user: CurrentUser, db: DbSession) -> list[Organization]:
    return OrgService(db).list_for_user(user.id)


@router.get("/{org_id}", response_model=OrganizationRead)
def get_org(org_id: uuid.UUID, user: CurrentUser, db: DbSession) -> Organization:
    return OrgService(db).get(org_id, user.id)


@router.patch("/{org_id}", response_model=OrganizationRead)
def update_org(org_id: uuid.UUID, body: OrgUpdate,
               user: CurrentUser, db: DbSession) -> Organization:
    return OrgService(db).update(org_id, user.id, name=body.name, slug=body.slug)


@router.get("/{org_id}/members", response_model=list[MemberRead])
def members(org_id: uuid.UUID, user: CurrentUser, db: DbSession) -> list[dict]:
    return OrgService(db).members(org_id, user.id)


@router.post("/{org_id}/invites", response_model=InviteRead, status_code=201)
def invite(org_id: uuid.UUID, body: InviteCreate,
           user: CurrentUser, db: DbSession):
    return OrgService(db).invite(
        org_id=org_id, inviter_id=user.id, email=body.email, role=Role(body.role),
    )


@router.post("/accept-invite", response_model=OrganizationRead)
def accept_invite(body: AcceptInvite, user: CurrentUser, db: DbSession) -> Organization:
    return OrgService(db).accept_invite(token=body.token, user_id=user.id)


@router.patch("/{org_id}/members/{member_id}", response_model=MemberRead)
def set_role(org_id: uuid.UUID, member_id: uuid.UUID, body: RoleUpdate,
             user: CurrentUser, db: DbSession):
    membership = OrgService(db).set_role(
        org_id=org_id, admin_id=user.id, member_id=member_id, role=Role(body.role),
    )
    return {
        "user_id": membership.user_id,
        "role": str(membership.role),
        "status": str(membership.status),
    }


@router.delete("/{org_id}/members/{member_id}", status_code=204)
def remove_member(org_id: uuid.UUID, member_id: uuid.UUID,
                  user: CurrentUser, db: DbSession) -> None:
    OrgService(db).remove_member(org_id=org_id, admin_id=user.id, member_id=member_id)
