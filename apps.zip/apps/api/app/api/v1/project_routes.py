"""Project REST surface."""

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.v1.auth_routes import current_user
from app.db.session import get_db
from app.models import Project, User
from app.schemas.identity import ProjectCreate, ProjectRead, ProjectUpdate
from app.services.project_service import ProjectService

router = APIRouter(prefix="/api/v1/orgs/{org_id}/projects", tags=["projects"])

DbSession = Annotated[Session, Depends(get_db)]
CurrentUser = Annotated[User, Depends(current_user)]


@router.post("", response_model=ProjectRead, status_code=201)
def create_project(org_id: uuid.UUID, body: ProjectCreate,
                   user: CurrentUser, db: DbSession) -> Project:
    return ProjectService(db).create(
        org_id=org_id, user_id=user.id, data=body.model_dump(exclude_unset=True),
    )


@router.get("", response_model=list[ProjectRead])
def list_projects(org_id: uuid.UUID, user: CurrentUser, db: DbSession) -> list[Project]:
    return ProjectService(db).list(org_id, user.id)


@router.get("/{project_id}", response_model=ProjectRead)
def get_project(project_id: uuid.UUID, org_id: uuid.UUID,
                user: CurrentUser, db: DbSession) -> Project:
    return ProjectService(db).get_for_org(project_id, org_id)


@router.patch("/{project_id}", response_model=ProjectRead)
def update_project(project_id: uuid.UUID, org_id: uuid.UUID, body: ProjectUpdate,
                   user: CurrentUser, db: DbSession) -> Project:
    return ProjectService(db).update(
        project_id, org_id=org_id, user_id=user.id, data=body.model_dump(exclude_unset=True),
    )


@router.delete("/{project_id}", status_code=204)
def delete_project(project_id: uuid.UUID, org_id: uuid.UUID,
                   user: CurrentUser, db: DbSession) -> None:
    ProjectService(db).delete(project_id, org_id=org_id, user_id=user.id)
