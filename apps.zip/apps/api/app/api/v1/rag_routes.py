"""RAG REST surface: ingest research snippets, store/read project memory, semantic search."""

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.v1.auth_routes import current_user
from app.db.session import get_db
from app.models import User
from app.schemas.content import (
    MemoryCreate,
    MemoryRead,
    RAGContextResponse,
    RAGIngestRequest,
    RAGIngestResponse,
    RAGSearchRequest,
)
from app.services.rag_service import RagService

router = APIRouter(prefix="/api/v1/orgs/{org_id}/projects/{project_id}/rag", tags=["rag"])

DbSession = Annotated[Session, Depends(get_db)]
CurrentUser = Annotated[User, Depends(current_user)]


@router.post("/snippets", response_model=RAGIngestResponse, status_code=201)
def ingest_snippets(org_id: uuid.UUID, project_id: uuid.UUID, body: RAGIngestRequest,
                    user: CurrentUser, db: DbSession) -> RAGIngestResponse:
    del user
    stored = RagService(db).store_snippets(
        org_id=org_id, project_id=project_id, texts=body.texts, kinds=body.kinds,
    )
    return RAGIngestResponse(stored=stored)


@router.post("/search", response_model=list[dict])
def search_snippets(org_id: uuid.UUID, project_id: uuid.UUID, body: RAGSearchRequest,
                    user: CurrentUser, db: DbSession) -> list[dict]:
    del user
    return RagService(db).search_snippets(
        org_id=org_id, project_id=project_id, query=body.query,
        k=body.k, kinds=body.kinds,
    )


@router.post("/context", response_model=RAGContextResponse)
def retrieve_context(org_id: uuid.UUID, project_id: uuid.UUID, body: RAGSearchRequest,
                     user: CurrentUser, db: DbSession) -> RAGContextResponse:
    del user
    context = RagService(db).retrieve_context(
        org_id=org_id, project_id=project_id, query=body.query, k=body.k,
    )
    return RAGContextResponse(context=context)


@router.post("/memories", response_model=MemoryRead, status_code=201)
def store_memory(org_id: uuid.UUID, project_id: uuid.UUID, body: MemoryCreate,
                 user: CurrentUser, db: DbSession) -> MemoryRead:
    del user
    return RagService(db).store_memory(
        org_id=org_id, project_id=project_id, memory_type=body.memory_type,
        content=body.content, source_step=body.source_step, provenance=body.provenance,
    )


@router.get("/memories", response_model=list[MemoryRead])
def list_memories(org_id: uuid.UUID, project_id: uuid.UUID, user: CurrentUser, db: DbSession,
                  memory_type: str | None = None) -> list[MemoryRead]:
    del org_id, user
    return RagService(db).list_memories(project_id=project_id, memory_type=memory_type)
