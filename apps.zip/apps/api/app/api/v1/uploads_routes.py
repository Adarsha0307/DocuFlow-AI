"""Upload job REST surface (YouTube publishing pipeline)."""

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.v1.auth_routes import current_user
from app.core.errors import NotFoundError
from app.db.session import get_db
from app.models import UploadJob, User
from app.schemas.content import UploadJobCreate, UploadJobRead
from app.services.upload_service import UploadService

router = APIRouter(prefix="/api/v1/orgs/{org_id}/uploads", tags=["uploads"])

DbSession = Annotated[Session, Depends(get_db)]
CurrentUser = Annotated[User, Depends(current_user)]


@router.post("", response_model=UploadJobRead, status_code=201)
def create_upload_job(org_id: uuid.UUID, body: UploadJobCreate,
                      user: CurrentUser, db: DbSession) -> UploadJob:
    return UploadService(db).create_job(
        org_id=org_id, user_id=user.id, project_id=body.project_id,
        channel_id=body.channel_id, render_id=body.render_id,
        title=body.title, description=body.description, tags=body.tags,
        privacy_status=body.privacy_status, publish_at=body.publish_at,
    )


@router.get("", response_model=list[UploadJobRead])
def list_upload_jobs(org_id: uuid.UUID, user: CurrentUser, db: DbSession,
                     project_id: uuid.UUID | None = None) -> list[UploadJob]:
    del user
    q = db.query(UploadJob).filter(UploadJob.organization_id == org_id)
    if project_id:
        q = q.filter(UploadJob.project_id == project_id)
    return list(q.order_by(UploadJob.created_at.desc()))


@router.get("/{job_id}", response_model=UploadJobRead)
def get_upload_job(job_id: uuid.UUID, org_id: uuid.UUID,
                   user: CurrentUser, db: DbSession) -> UploadJob:
    del user
    job = db.get(UploadJob, job_id)
    if not job or job.organization_id != org_id:
        raise NotFoundError("Upload job not found")
    return job


@router.post("/{job_id}/execute", response_model=UploadJobRead)
def execute_upload(job_id: uuid.UUID, org_id: uuid.UUID,
                   user: CurrentUser, db: DbSession) -> UploadJob:
    del user
    return UploadService(db).execute(org_id=org_id, job_id=job_id)


@router.post("/{job_id}/resume", response_model=UploadJobRead)
def resume_upload(job_id: uuid.UUID, org_id: uuid.UUID,
                  user: CurrentUser, db: DbSession) -> UploadJob:
    del user
    return UploadService(db).resume(org_id=org_id, job_id=job_id)
