﻿"""Workflow engine REST surface: runs, steps, approvals, definitions."""

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session

from app.core.errors import NotFoundError, UnauthorizedError
from app.db.session import get_db
from app.models import Approval, Project, WorkflowDefinition, WorkflowRun, WorkflowStep
from app.schemas.workflow import (
    ApprovalDecision,
    ApprovalRead,
    RunCreate,
    RunDetail,
    RunRead,
    WorkflowStepRead,
)
from app.services.approval_service import ApprovalService
from app.workflow.engine import RunController

DbSession = Annotated[Session, Depends(get_db)]

router = APIRouter(prefix="/api/v1", tags=["workflow"])


def _org_id(request: Request) -> uuid.UUID:
    org_id = getattr(request.state, "org_id", None)
    if not org_id:
        raise UnauthorizedError("Missing X-Org-Id header")
    return uuid.UUID(str(org_id))


def _user_id(request: Request) -> uuid.UUID | None:
    raw = request.headers.get("X-User-Id")
    return uuid.UUID(raw) if raw else None


def _project_for(db: Session, org_id: uuid.UUID, project_id: uuid.UUID) -> Project:
    project = db.get(Project, project_id)
    if not project or project.organization_id != org_id:
        raise NotFoundError("Project not found")
    return project


@router.post("/projects/{project_id}/runs", response_model=RunRead, status_code=201)
def create_run(project_id: uuid.UUID, body: RunCreate, request: Request,
               db: DbSession) -> WorkflowRun:
    org_id = _org_id(request)
    _project_for(db, org_id, project_id)

    if body.definition_id:
        definition = db.get(WorkflowDefinition, body.definition_id)
        if not definition or (definition.organization_id and definition.organization_id != org_id):
            raise NotFoundError("Workflow definition not found")

    run = RunController.create(
        db, org_id=org_id, project_id=project_id,
        definition_id=body.definition_id, user_id=_user_id(request),
        automation_mode=body.automation_mode,
    )
    RunController(db, run).start()
    db.refresh(run)
    return run


@router.get("/runs/{run_id}", response_model=RunDetail)
def get_run(run_id: uuid.UUID, request: Request, db: DbSession) -> RunDetail:
    org_id = _org_id(request)
    run = db.get(WorkflowRun, run_id)
    if not run or run.organization_id != org_id:
        raise NotFoundError("Run not found")
    steps = (
        db.query(WorkflowStep)
        .filter(WorkflowStep.run_id == run_id)
        .order_by(WorkflowStep.created_at.asc())
        .all()
    )
    detail = RunDetail.model_validate(run)
    detail.steps = [WorkflowStepRead.model_validate(s) for s in steps]
    return detail


@router.post("/runs/{run_id}/pause", response_model=RunRead)
def pause_run(run_id: uuid.UUID, request: Request, db: DbSession) -> WorkflowRun:
    run = _get_run(db, run_id, _org_id(request))
    return RunController(db, run).pause()


@router.post("/runs/{run_id}/resume", response_model=RunRead)
def resume_run(run_id: uuid.UUID, request: Request, db: DbSession) -> WorkflowRun:
    run = _get_run(db, run_id, _org_id(request))
    return RunController(db, run).resume()


@router.post("/runs/{run_id}/cancel", response_model=RunRead)
def cancel_run(run_id: uuid.UUID, request: Request, db: DbSession) -> WorkflowRun:
    run = _get_run(db, run_id, _org_id(request))
    return RunController(db, run).cancel()


@router.post("/runs/{run_id}/advance", response_model=RunRead)
def advance_run(run_id: uuid.UUID, request: Request, db: DbSession) -> WorkflowRun:
    run = _get_run(db, run_id, _org_id(request))
    return RunController(db, run).advance()


@router.get("/approvals/pending", response_model=list[ApprovalRead])
def pending_approvals(request: Request, db: DbSession) -> list[Approval]:
    return ApprovalService(db).list_pending(_org_id(request), 100)


@router.get("/projects/{project_id}/approvals", response_model=list[ApprovalRead])
def project_approvals(project_id: uuid.UUID, request: Request,
                      db: DbSession) -> list[Approval]:
    _project_for(db, _org_id(request), project_id)
    return ApprovalService(db).list_for_project(project_id)


@router.post("/approvals/{approval_id}/decision", response_model=ApprovalRead)
def decide_approval(approval_id: uuid.UUID, body: ApprovalDecision,
                    request: Request, db: DbSession) -> Approval:
    org_id = _org_id(request)
    approval = ApprovalService(db).decide(
        approval_id=approval_id, org_id=org_id,
        user_id=_user_id(request) or uuid.UUID(int=0),
        decision=body.decision, comment=body.comment,
    )
    if approval.run_id and str(approval.state) in ("approved", "auto_approved"):
        from app.workflow.events import apply_approval_decision

        apply_approval_decision(db, uuid.UUID(str(approval.run_id)), approval.stage)
    return approval


@router.get("/workflow-definitions", response_model=list[object])
def list_definitions(request: Request, db: DbSession) -> list[WorkflowDefinition]:
    org_id = _org_id(request)
    rows = (
        db.query(WorkflowDefinition)
        .filter(
            (WorkflowDefinition.organization_id == org_id)
            | (WorkflowDefinition.is_system.is_(True))
        )
        .order_by(WorkflowDefinition.created_at.desc())
        .all()
    )
    return [
        {
            "id": str(d.id),
            "name": d.name,
            "slug": d.slug,
            "version": d.version,
            "is_system": d.is_system,
            "node_count": len((d.flow_json or {}).get("nodes", [])),
        }
        for d in rows
    ]


@router.get("/runs/{run_id}/steps")
def run_steps(run_id: uuid.UUID, request: Request,
              db: DbSession) -> list[WorkflowStepRead]:
    run = _get_run(db, run_id, _org_id(request))
    steps = (
        db.query(WorkflowStep)
        .filter(WorkflowStep.run_id == run.id)
        .order_by(WorkflowStep.created_at.asc())
        .all()
    )
    return [WorkflowStepRead.model_validate(s) for s in steps]


def _get_run(db: Session, run_id: uuid.UUID, org_id: uuid.UUID) -> WorkflowRun:
    run = db.get(WorkflowRun, run_id)
    if not run or run.organization_id != org_id:
        raise NotFoundError("Run not found")
    return run
