"""Application bootstrap shared by the API server and Celery workers.

Seeds system workflow definitions and registers domain-event handlers exactly
once per process.
"""

import logging

from app.db.session import SessionLocal
from app.workflow.events import register_event_handlers

logger = logging.getLogger("docuflow.bootstrap")

_seeded = False


def bootstrap(seed_db: bool = True) -> None:
    global _seeded

    register_event_handlers()
    if _seeded:
        return
    _seeded = True
    if not seed_db:
        return
    try:
        from app.workflow.definitions import seed_system_definitions

        db = SessionLocal()
        try:
            seed_system_definitions(db)
        finally:
            db.close()
        logger.info("workflow definitions seeded")
    except Exception:  # pragma: no cover
        logger.exception("failed to seed workflow definitions")
