from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Centralized, env-driven application configuration."""

    model_config = SettingsConfigDict(
        env_file=(".env", "../.env", "../../.env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    app_name: str = "DocuFlow AI"
    app_env: str = "development"
    api_base_url: str = "http://localhost:8000"
    frontend_url: str = "http://localhost:3000"

    # Database / cache
    database_url: str = "postgresql+psycopg://docuflow:docuflow@localhost:5432/docuflow"
    redis_url: str = "redis://localhost:6379/0"
    events_bus: str = "in-memory"  # in-memory | redis (redis only for cross-process fanout)

    # Auth
    auth_secret: str = "dev-only-change-me"
    auth_token_ttl_hours: int = 168
    auth_issuer: str = "docuflow"
    allow_signup: bool = True
    default_org_name: str = "My Studio"

    # CORS
    cors_allowed_origins: list[str] = ["http://localhost:3000"]

    # Storage
    storage_driver: str = "s3"
    storage_bucket: str = "docuflow"
    storage_region: str = "us-east-1"
    storage_endpoint: str = ""
    storage_access_key: str = ""
    storage_secret_key: str = ""
    storage_force_path_style: bool = True
    storage_public_base_url: str = ""

    # Security
    secret_vault_key: str = ""
    encryption_key: str = ""
    api_key_prefix: str = "df_"
    api_key_hash_rounds: int = 12

    # Media
    media_worker_enabled: bool = True
    ffmpeg_path: str = "ffmpeg"
    ffprobe_path: str = "ffprobe"
    render_temp_dir: str = "media/tmp"

    # Workflow
    workflow_engine: str = "celery"  # celery | temporal
    auto_approve_after_seconds: int = 0  # 0 disables timeout auto-approval
    default_workflow_id: str = "default_documentary_2d"

    # Observability
    sentry_dsn: str = ""
    otel_service_name: str = "docuflow-api"
    otel_exporter_endpoint: str = ""
    posthog_api_key: str = ""
    log_level: str = "INFO"

    # Billing
    stripe_secret_key: str = ""
    stripe_webhook_secret: str = ""
    billing_provider: str = "mock"  # mock | stripe

    # --- AI provider keys (blank => mock adapters) ---
    openai_api_key: str = ""
    anthropic_api_key: str = ""
    gemini_api_key: str = ""
    groq_api_key: str = ""
    elevenlabs_api_key: str = ""
    cartesia_api_key: str = ""
    stability_api_key: str = ""
    flux_api_key: str = ""
    runway_api_key: str = ""

    # --- YouTube OAuth ---
    youtube_oauth_client_id: str = ""
    youtube_oauth_client_secret: str = ""
    youtube_oauth_redirect_uri: str = ""

    @property
    def is_production(self) -> bool:
        return self.app_env.lower() in {"production", "prod"}

    @property
    def sane_origins(self) -> list[str]:
        origins = list(self.cors_allowed_origins)
        if self.frontend_url and self.frontend_url not in origins:
            origins.append(self.frontend_url)
        return [o for o in origins if o]


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
