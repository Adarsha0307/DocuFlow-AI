"""Typed API errors with stable codes for the frontend."""

from fastapi import HTTPException, status


class AppError(HTTPException):
    code = "app_error"
    status_code = status.HTTP_400_BAD_REQUEST

    def __init__(self, message: str, *, status_code: int | None = None, **details):
        super().__init__(
            status_code or self.status_code,
            detail={"code": self.code, "message": message, **details},
        )


class NotFoundError(AppError):
    code = "not_found"
    status_code = status.HTTP_404_NOT_FOUND


class ForbiddenError(AppError):
    code = "forbidden"
    status_code = status.HTTP_403_FORBIDDEN


class UnauthorizedError(AppError):
    code = "unauthorized"
    status_code = status.HTTP_401_UNAUTHORIZED


class ConflictError(AppError):
    code = "conflict"
    status_code = status.HTTP_409_CONFLICT


class ValidationFailedError(AppError):
    code = "validation_failed"
    status_code = status.HTTP_422_UNPROCESSABLE_ENTITY


class QuotaExceededError(AppError):
    code = "quota_exceeded"
    status_code = status.HTTP_402_PAYMENT_REQUIRED


class ProviderUnavailableError(AppError):
    code = "provider_unavailable"
    status_code = status.HTTP_503_SERVICE_UNAVAILABLE


class IdempotencyReplayError(AppError):
    code = "idempotency_replay"
    status_code = status.HTTP_409_CONFLICT
