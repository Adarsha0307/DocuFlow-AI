"""Request-scoped middleware: correlation IDs, structured request logging, timing."""

import logging
import time
import uuid

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

from app.observability import metrics

logger = logging.getLogger("docuflow.http")


class RequestContextMiddleware(BaseHTTPMiddleware):
    """Adds X-Request-Id headers, logs structured summaries and records metrics."""

    async def dispatch(self, request: Request, call_next):
        request_id = request.headers.get("X-Request-Id") or str(uuid.uuid4())
        request.state.request_id = request_id
        request.state.start_time = time.perf_counter()

        response = await call_next(request)
        response.headers["X-Request-Id"] = request_id

        duration = time.perf_counter() - request.state.start_time
        route = request.url.path
        logger.info(
            "http_request",
            extra={
                "request_id": request_id,
                "method": request.method,
                "path": route,
                "status": response.status_code,
                "duration_ms": round(duration * 1000, 1),
            },
        )
        metrics.http_requests_total.labels(request.method, route, response.status_code).inc()
        metrics.http_request_duration_seconds.labels(request.method, route).observe(duration)
        return response


class OrgContextMiddleware(BaseHTTPMiddleware):
    """Resolves the active organization from X-Org-Id for downstream access checks."""

    async def dispatch(self, request: Request, call_next):
        request.state.org_id = request.headers.get("X-Org-Id")
        return await call_next(request)
