"""Security primitives: password hashing, JWT, signed asset URLs, secrets vault."""

import base64
import hashlib
import hmac
import os
import uuid

import jwt
from cryptography.fernet import Fernet, InvalidToken

from app.core.config import get_settings


# --- Password hashing (dependency-free, salted PBKDF2) ---
def hash_password(password: str, salt: bytes | None = None) -> str:
    salt = salt or os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 120_000)
    return f"pbkdf2${base64.b64encode(salt).decode()}${base64.b64encode(digest).decode()}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        algo, salt_b64, digest_b64 = encoded.split("$")
        assert algo == "pbkdf2"
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(digest_b64)
        actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 120_000)
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False


# --- JWT ---
def encode_access_token(user_id: uuid.UUID, extra: dict | None = None) -> str:
    settings = get_settings()
    payload = {
        "sub": str(user_id),
        "iss": settings.auth_issuer,
        "iat": int(__import__("time").time()),
    }
    if extra:
        payload.update(extra)
    return jwt.encode(payload, settings.auth_secret, algorithm="HS256")


def decode_access_token(token: str) -> dict:
    settings = get_settings()
    return jwt.decode(token, settings.auth_secret, algorithms=["HS256"], issuer=settings.auth_issuer)


# --- Fernet encryption for stored secrets / OAuth tokens ---
def _fernet() -> Fernet:
    settings = get_settings()
    raw = settings.encryption_key or settings.secret_vault_key or settings.auth_secret
    if not raw:
        raise ValueError("No encryption key configured")
    key = base64.urlsafe_b64encode(hashlib.sha256(raw.encode()).digest())
    return Fernet(key)


def encrypt_secret(value: str) -> str:
    if value is None:
        return ""
    enc = _fernet()
    return enc.encrypt(value.encode()).decode()


def decrypt_secret(value: str) -> str | None:
    if not value:
        return None
    try:
        return _fernet().decrypt(value.encode()).decode()
    except InvalidToken:
        return None


def sign_string(value: str) -> str:
    settings = get_settings()
    return hmac.new(settings.auth_secret.encode(), value.encode(), hashlib.sha256).hexdigest()


def generate_secure_token(nbytes: int = 32) -> str:
    return base64.urlsafe_b64encode(os.urandom(nbytes)).decode().rstrip("=")


def hash_api_key(key: str) -> str:
    settings = get_settings()
    return hashlib.pbkdf2_hmac(
        "sha256", key.encode(), settings.auth_secret.encode("utf-8"), 210_000
    ).hex()
