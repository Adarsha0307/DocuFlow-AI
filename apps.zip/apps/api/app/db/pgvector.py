"""
pgvector compatibility layer.

Production uses PostgreSQL + pgvector for semantic retrieval. pgvector ships as
the `pgvector` pip package plus the `vector` postgres extension. When it is
unavailable (e.g. sqlite-based unit tests), vector columns transparently fall
back to JSON so the whole app keeps working without schema changes.
"""

from sqlalchemy import JSON

try:  # pragma: no cover - depends on deployment
    from pgvector.sqlalchemy import Vector

    PG_VECTOR_AVAILABLE = True
except Exception:  # pragma: no cover
    PG_VECTOR_AVAILABLE = False

VECTOR_DIM: int = 1536


def vector_column(dimension: int = VECTOR_DIM):
    """Return a pgvector Vector column, or a JSON fallback for non-pg envs."""
    if PG_VECTOR_AVAILABLE:
        return Vector(dimension)
    return JSON()


def supports_pgvector() -> bool:
    return PG_VECTOR_AVAILABLE
