from collections.abc import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from app.core.config import settings


def _build_engine(url: str):
    """SQLite (tests/local dev) rejects pool args; Postgres wants them."""
    if url.startswith("sqlite"):
        return create_engine(url, future=True)
    return create_engine(
        url,
        pool_pre_ping=True,
        pool_size=10,
        max_overflow=20,
        future=True,
    )


engine = _build_engine(settings.database_url)

SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False, class_=Session)


def get_db() -> Generator[Session, None, None]:
    """FastAPI dependency that yields a scoped DB session."""
    db = SessionLocal()
    try:
        yield db
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def make_session(url: str) -> Session:
    """Creates a standalone session against an arbitrary URL (used by tests)."""
    eng = create_engine(url, pool_pre_ping=True)
    factory = sessionmaker(bind=eng, autoflush=False, expire_on_commit=False)
    return factory()
