﻿"""Domain event definitions and the event bus abstraction.

The bus is transport-agnostic: in-process in tests, Redis pub/sub in local dev,
and pluggable to Redis Streams / RabbitMQ / Kafka / NATS in production.
"""

import asyncio  # noqa: F401  # kept for transport upgrade paths
import json
import logging
import threading
import uuid
from abc import ABC, abstractmethod
from collections.abc import Callable
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from typing import Any

from app.core.config import get_settings

logger = logging.getLogger(__name__)

EVENT_NAMES = {
    "project_created",
    "workflow_started",
    "workflow_completed",
    "workflow_failed",
    "step_completed",
    "approval_requested",
    "approval_completed",
    "asset_generated",
    "render_completed",
    "upload_failed",
    "upload_completed",
    "analytics_synced",
    "quota_exceeded",
    "cost_recorded",
    "notification_created",
}


@dataclass
class DomainEvent:
    name: str
    organization_id: str | None = None
    project_id: str | None = None
    run_id: str | None = None
    payload: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    correlation_id: str | None = None

    def to_json(self) -> str:
        return json.dumps(asdict(self), default=str)


class EventBus(ABC):
    @abstractmethod
    def publish(self, event: DomainEvent) -> None: ...

    @abstractmethod
    def subscribe(self, name: str, handler: Callable[[DomainEvent], None]) -> None: ...


class InMemoryEventBus(EventBus):
    def __init__(self) -> None:
        self._handlers: dict[str, list[Callable[[DomainEvent], None]]] = {}

    def publish(self, event: DomainEvent) -> None:
        for handler in self._handlers.get(event.name, []):
            try:
                handler(event)
            except Exception:  # pragma: no cover
                logger.exception("event handler failed for %s", event.name)

    def subscribe(self, name: str, handler: Callable[[DomainEvent], None]) -> None:
        self._handlers.setdefault(name, []).append(handler)


class RedisEventBus(EventBus):
    """Redis pub/sub bus. Upgrade path: Redis Streams, RabbitMQ, Kafka, NATS."""

    def __init__(self, redis_url: str | None = None) -> None:
        import redis

        self._redis = redis.Redis.from_url(redis_url or get_settings().redis_url)
        self._sub = self._redis.pubsub()
        self._handlers: dict[str, list[Callable[[DomainEvent], None]]] = {}
        self._thread: Any = None
        self._running = False

    def probe(self) -> None:
        self._redis.ping()

    def publish(self, event: DomainEvent) -> None:
        try:
            self._redis.publish("docuflow.events", event.to_json())
        except Exception:  # broker down — events are best-effort, never crash the run
            logger.warning("redis publish failed; event %s dropped", event.name)

    def subscribe(self, name: str, handler: Callable[[DomainEvent], None]) -> None:
        self._handlers.setdefault(name, []).append(handler)
        self._ensure_loop()

    def _ensure_loop(self) -> None:
        if self._running:
            return
        self._running = True
        self._sub.subscribe("docuflow.events")
        self._thread = threading.Thread(target=self._listen, daemon=True)
        self._thread.start()

    def _listen(self) -> None:
        for raw in self._sub.listen():
            if raw.get("type") != "message":
                continue
            try:
                event = DomainEvent(**json.loads(raw["data"]))
            except Exception:  # pragma: no cover
                logger.exception("failed to parse redis event")
                continue
            for handler in self._handlers.get(event.name, []):
                try:
                    handler(event)
                except Exception:  # pragma: no cover
                    logger.exception("failed to dispatch redis event")


_bus: EventBus | None = None


def get_bus() -> EventBus:
    global _bus
    if _bus is None:
        if get_settings().events_bus == "redis":
            try:
                candidate = RedisEventBus()
                candidate.probe()
                _bus = candidate
            except Exception:
                logger.warning("redis unavailable — falling back to in-memory event bus")
                _bus = InMemoryEventBus()
        else:
            _bus = InMemoryEventBus()
    return _bus


def reset_bus_for_tests() -> None:
    global _bus
    _bus = None
