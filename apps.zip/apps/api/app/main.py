"""DocuFlow AI API — FastAPI application entrypoint.

Run (dev):
    uvicorn app.main:app --reload --port 8000
"""

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response
from sqlalchemy import text

from app.bootstrap import bootstrap
from app.core.config import get_settings
from app.core.errors import AppError
from app.core.logging import setup_logging
from app.db.session import engine
from app.observability import metrics
from app.observability.tracing import setup_tracing

logger = logging.getLogger("docuflow.api")


@asynccontextmanager
async def lifespan(_app: FastAPI):
    setup_tracing(get_settings().otel_service_name)
    bootstrap(seed_db=True)
    logger.info("api started (env=%s engine=%s)", get_settings().app_env, get_settings().workflow_engine)
    yield
    engine.dispose()
    logger.info("api stopped")


def create_app() -> FastAPI:
    setup_logging()
    settings = get_settings()

    app = FastAPI(
        title=settings.app_name,
        version="0.1.0",
        lifespan=lifespan,
        docs_url="/docs" if not settings.is_production else None,
        redoc_url="/redoc" if not settings.is_production else None,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.sane_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Order matters: request-context middleware runs last (innermost).
    from app.core.middleware import OrgContextMiddleware, RequestContextMiddleware

    app.add_middleware(OrgContextMiddleware)
    app.add_middleware(RequestContextMiddleware)

    @app.exception_handler(AppError)
    async def app_error_handler(_request: Request, exc: AppError) -> JSONResponse:
        return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})

    @app.exception_handler(Exception)
    async def unhandled_error_handler(request: Request, exc: Exception) -> JSONResponse:
        logger.exception("unhandled error on %s", request.url.path)
        return JSONResponse(
            status_code=500,
            content={"detail": {"code": "internal_error", "message": "Internal server error"}},
        )

    @app.get("/health", tags=["ops"])
    def health() -> dict:
        return {"status": "ok", "app": get_settings().app_name}

    @app.get("/readyz", tags=["ops"], response_model=None)
    def readyz() -> dict | JSONResponse:
        try:
            with engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            return {"status": "ready", "database": "up"}
        except Exception as exc:
            logger.warning("readyz failed: %s", exc)
            return JSONResponse(status_code=503, content={"status": "not_ready", "database": "down"})

    @app.get("/metrics", tags=["ops"])
    def metrics_endpoint() -> Response:
        return Response(
            content=metrics.generate_latest(),
            media_type=metrics.CONTENT_TYPE_LATEST,
        )

    from app.api.v1.auth_routes import router as auth_router
    from app.api.v1.billing_routes import router as billing_router
    from app.api.v1.content_routes import router as content_router
    from app.api.v1.mcp_routes import router as mcp_router
    from app.api.v1.org_routes import router as org_router
    from app.api.v1.project_routes import router as project_router
    from app.api.v1.rag_routes import router as rag_router
    from app.api.v1.uploads_routes import router as uploads_router
    from app.api.v1.workflow_routes import router as workflow_router

    app.include_router(workflow_router)
    app.include_router(auth_router)
    app.include_router(org_router)
    app.include_router(project_router)
    app.include_router(content_router)
    app.include_router(billing_router)
    app.include_router(uploads_router)
    app.include_router(rag_router)
    app.include_router(mcp_router)

    return app


app = create_app()
