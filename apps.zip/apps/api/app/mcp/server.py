"""Minimal MCP (Model Context Protocol) server: JSON-RPC 2.0 over HTTP.

Implements the transport-fixed subset of the MCP spec used by assistant clients:
initialize, ping, tools/list, tools/call. Standard JSON responses suffice for
request/response tools (no server-initiated streams, no SSE).

Tools operate within the caller's org scope: X-Org-Id header when provided,
otherwise the authenticated user's default org.
"""

import json
import uuid

from sqlalchemy.orm import Session

from app.core.logging import get_logger
from app.models import Membership, Organization, Project, User, WorkflowRun, WorkflowStep
from app.services.content_service import ContentService
from app.services.rag_service import RagService
from app.workflow.engine import RunController

logger = get_logger("docuflow.mcp")

PROTOCOL_VERSION = "2024-11-05"


class McpError(Exception):
    """JSON-RPC error carrying a protocol error code."""

    def __init__(self, code: int, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


def _uuid(value: str) -> uuid.UUID:
    try:
        return uuid.UUID(str(value))
    except ValueError as exc:
        raise McpError(-32602, f"invalid uuid: {value}") from exc


def _require(args: dict, key: str) -> str:
    value = args.get(key)
    if value is None:
        raise McpError(-32602, f"missing required argument: {key}")
    return str(value)


def _default_org(db: Session, user: User) -> Organization:
    row = (
        db.query(Organization)
        .join(Membership, Membership.organization_id == Organization.id)
        .filter(
            Membership.user_id == user.id,
            Membership.status == "active",
        )
        .order_by(Organization.created_at.asc())
        .first()
    )
    if not row:
        raise McpError(-32001, "no active organization membership for this user")
    return row


def _resolve_org(db: Session, user: User, org_id: str | None) -> Organization:
    if not org_id:
        return _default_org(db, user)
    org = db.get(Organization, _uuid(org_id))
    if not org:
        raise McpError(-32002, f"organization not found: {org_id}")
    member = (
        db.query(Membership)
        .filter(
            Membership.organization_id == org.id,
            Membership.user_id == user.id,
            Membership.status == "active",
        )
        .first()
    )
    if not member:
        raise McpError(-32003, "not an active member of that organization")
    return org


ToolResult = tuple[dict, str]


def handle(db: Session, user: User, org_id: str | None, body: dict) -> dict:
    """JSON-RPC 2.0 dispatch. Raises McpError on protocol violations."""
    if body.get("jsonrpc") != "2.0":
        raise McpError(-32600, "invalid request: expected jsonrpc 2.0")
    method = body.get("method")
    mid = body.get("id")
    params = body.get("params") or {}

    if method == "initialize":
        return _reply(mid, {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {"tools": {"listChanged": False}},
            "serverInfo": {"name": "docuflow-mcp", "version": "0.1.0"},
        })
    if method == "ping":
        return _reply(mid, {})
    if method == "tools/list":
        return _reply(mid, {"tools": _tool_specs()})
    if method == "tools/call":
        name = params.get("name")
        args = params.get("arguments") or {}
        if name not in _TOOLS:
            raise McpError(-32602, f"tool not found: {name}")
        result = _TOOLS[name](db, user, _resolve_org(db, user, args.get("org_id")), args)
        return _reply(mid, {"content": [{"type": "text", "text": result}]})
    raise McpError(-32601, f"method not found: {method}")


def _reply(request_id, result: dict) -> dict:
    return {"jsonrpc": "2.0", "id": request_id, "result": result}


def error_json(error: McpError, request_id) -> dict:
    return {"jsonrpc": "2.0", "id": request_id, "error": {"code": error.code, "message": error.message}}


def _tool_specs() -> list[dict]:
    return [
        {
            "name": "docuflow_rag_search",
            "description": "Semantic search over a project's research snippets (RAG).",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "org_id": {"type": "string", "description": "optional; defaults to caller org"},
                    "project_id": {"type": "string"},
                    "query": {"type": "string"},
                    "k": {"type": "integer", "default": 8},
                },
                "required": ["project_id", "query"],
            },
        },
        {
            "name": "docuflow_run_status",
            "description": "Get state, current stage and step summary of a workflow run.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "org_id": {"type": "string", "description": "optional; defaults to caller org"},
                    "run_id": {"type": "string"},
                },
                "required": ["run_id"],
            },
        },
        {
            "name": "docuflow_script_list",
            "description": "List scripts for a project.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "org_id": {"type": "string", "description": "optional; defaults to caller org"},
                    "project_id": {"type": "string"},
                },
                "required": ["project_id"],
            },
        },
        {
            "name": "docuflow_run_start",
            "description": "Start a workflow run for a project (manual mode).",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "org_id": {"type": "string", "description": "optional; defaults to caller org"},
                    "project_id": {"type": "string"},
                    "automation_mode": {"type": "string", "enum": ["manual", "full_auto"], "default": "manual"},
                },
                "required": ["project_id"],
            },
        },
    ]


def _rag_search(db: Session, user: User, org: Organization, args: dict) -> str:
    project_uuid = _uuid(_require(args, "project_id"))
    hits = RagService(db).search_snippets(
        org_id=org.id, project_id=project_uuid,
        query=_require(args, "query"), k=int(args.get("k") or 8),
    )
    return json.dumps(hits, default=str)


def _run_status(db: Session, user: User, org: Organization, args: dict) -> str:
    run = db.get(WorkflowRun, _uuid(_require(args, "run_id")))
    if not run or run.organization_id != org.id:
        raise McpError(-32004, "run not found in this org")
    steps = (
        db.query(WorkflowStep)
        .filter(WorkflowStep.run_id == run.id)
        .order_by(WorkflowStep.created_at.asc())
        .all()
    )
    staged = (run.staged_state_json or {}).get("flow", {})
    return json.dumps({
        "run_id": str(run.id),
        "state": str(run.state),
        "current_stage": run.current_stage,
        "automation_mode": staged.get("automation_mode"),
        "steps": [{"stage": s.stage, "status": str(s.status), "attempts": s.retry_count or 0} for s in steps],
    }, default=str)


def _project(db: Session, org: Organization, project_id_raw: str) -> Project:
    project = db.get(Project, _uuid(project_id_raw))
    if not project or project.organization_id != org.id:
        raise McpError(-32004, "project not found in this org")
    return project


def _script_list(db: Session, user: User, org: Organization, args: dict) -> str:
    project = _project(db, org, _require(args, "project_id"))
    scripts = ContentService(db).list_scripts(
        org_id=org.id, user_id=user.id, project_id=project.id,
    )
    return json.dumps(
        [{"id": str(s.id), "title": s.title, "word_count": s.word_count} for s in scripts],
        default=str,
    )


def _run_start(db: Session, user: User, org: Organization, args: dict) -> str:
    project = _project(db, org, _require(args, "project_id"))
    run = RunController.create(
        db, org_id=org.id, project_id=project.id, user_id=user.id,
        automation_mode=args.get("automation_mode", "manual"),
    )
    RunController(db, run).start()
    db.refresh(run)
    return json.dumps({"run_id": str(run.id), "state": str(run.state),
                       "current_stage": run.current_stage}, default=str)


_TOOLS: dict[str, object] = {
    "docuflow_rag_search": lambda db, user, org, args: _rag_search(db, user, org, args),
    "docuflow_run_status": lambda db, user, org, args: _run_status(db, user, org, args),
    "docuflow_script_list": lambda db, user, org, args: _script_list(db, user, org, args),
    "docuflow_run_start": lambda db, user, org, args: _run_start(db, user, org, args),
}
