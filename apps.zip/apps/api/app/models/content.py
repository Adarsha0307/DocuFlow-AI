import uuid

from sqlalchemy import ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, TenantMixin, TimestampMixin, uuid_pk


class Script(Base, TenantMixin, TimestampMixin):
    __tablename__ = "scripts"

    id: Mapped[uuid.UUID] = uuid_pk()
    project_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    title: Mapped[str | None] = mapped_column(String(400), nullable=True)
    hook: Mapped[str | None] = mapped_column(Text, nullable=True)
    body: Mapped[str] = mapped_column(Text, nullable=False)
    word_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    language: Mapped[str] = mapped_column(String(24), default="en-US", nullable=False)
    status: Mapped[str] = mapped_column(String(24), default="draft", nullable=False)
    current_version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    created_by: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )


class ScriptVersion(Base, TimestampMixin):
    __tablename__ = "script_versions"
    __table_args__ = (
        Index("ix_script_versions_script", "script_id"),
    )

    id: Mapped[uuid.UUID] = uuid_pk()
    script_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("scripts.id", ondelete="CASCADE"), nullable=False
    )
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    body: Mapped[str] = mapped_column(Text, nullable=False)
    diff_json: Mapped[list | None] = mapped_column(nullable=True)  # [{op, section, before, after}]
    change_notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_by: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )


class Scene(Base, TenantMixin, TimestampMixin):
    __tablename__ = "scenes"
    __table_args__ = (Index("ix_scenes_script_order", "script_id", "scene_number"),)

    id: Mapped[uuid.UUID] = uuid_pk()
    project_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    script_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("scripts.id", ondelete="CASCADE"), nullable=True
    )
    scene_number: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    title: Mapped[str] = mapped_column(String(300), nullable=False)
    narration: Mapped[str] = mapped_column(Text, nullable=False)
    visual_direction: Mapped[str | None] = mapped_column(Text, nullable=True)
    duration_seconds: Mapped[float] = mapped_column(default=15.0, nullable=False)
    broll_keywords: Mapped[list | None] = mapped_column(nullable=True)
    status: Mapped[str] = mapped_column(String(24), default="planned", nullable=False)


class SceneVersion(Base, TimestampMixin):
    __tablename__ = "scene_versions"

    id: Mapped[uuid.UUID] = uuid_pk()
    scene_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("scenes.id", ondelete="CASCADE"), nullable=False, index=True
    )
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    narration: Mapped[str] = mapped_column(Text, nullable=False)
    visual_direction: Mapped[str | None] = mapped_column(Text, nullable=True)
    diff_count: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_by: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )


class CharacterProfile(Base, TenantMixin, TimestampMixin):
    __tablename__ = "character_profiles"

    id: Mapped[uuid.UUID] = uuid_pk()
    project_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    role: Mapped[str | None] = mapped_column(String(120), nullable=True)
    appearance_prompt: Mapped[str | None] = mapped_column(Text, nullable=True)
    voice_preference: Mapped[str | None] = mapped_column(String(120), nullable=True)
    consistency_key: Mapped[str | None] = mapped_column(String(120), nullable=True)
    meta_json: Mapped[dict | None] = mapped_column(nullable=True)


class Prompt(Base, TimestampMixin):
    __tablename__ = "prompts"

    id: Mapped[uuid.UUID] = uuid_pk()
    project_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    scene_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("scenes.id", ondelete="CASCADE"), nullable=True
    )
    target: Mapped[str] = mapped_column(String(32), nullable=False)  # image|voice|music|seo
    kind: Mapped[str] = mapped_column(String(32), default="text2image", nullable=False)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    negative_prompt: Mapped[str | None] = mapped_column(Text, nullable=True)
    params_json: Mapped[dict | None] = mapped_column(nullable=True)
    used_in_run_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True, index=True)
    used_by_snapshot: Mapped[str | None] = mapped_column(String(64), nullable=True)


class PromptVersion(TimestampMixin):
    __tablename__ = "prompt_versions"

    id: Mapped[uuid.UUID] = uuid_pk()
    prompt_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("prompts.id", ondelete="CASCADE"), nullable=False, index=True
    )
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    created_by: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
