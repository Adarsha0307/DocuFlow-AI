from enum import StrEnum


class Role(StrEnum):
    OWNER = "owner"
    ADMIN = "admin"
    EDITOR = "editor"
    REVIEWER = "reviewer"
    VIEWER = "viewer"
    BILLING_ADMIN = "billing_admin"
    OPERATOR = "operator"


# RBAC weights: higher = more privileged.
ROLE_WEIGHT = {
    Role.VIEWER: 1,
    Role.REVIEWER: 2,
    Role.EDITOR: 3,
    Role.BILLING_ADMIN: 3,
    Role.OPERATOR: 4,
    Role.ADMIN: 5,
    Role.OWNER: 6,
}


class MembershipStatus(StrEnum):
    ACTIVE = "active"
    INVITED = "invited"
    SUSPENDED = "suspended"
    LEFT = "left"


class InvitationStatus(StrEnum):
    PENDING = "pending"
    ACCEPTED = "accepted"
    DECLINED = "declined"
    EXPIRED = "expired"
    REVOKED = "revoked"


class PlanCode(StrEnum):
    STARTER = "starter"
    PRO = "pro"
    STUDIO = "studio"
    AGENCY = "agency"


class SubscriptionStatus(StrEnum):
    TRIALING = "trialing"
    ACTIVE = "active"
    PAST_DUE = "past_due"
    CANCELED = "canceled"
    UNPAID = "unpaid"


class ProjectStatus(StrEnum):
    DRAFT = "draft"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    ARCHIVED = "archived"


class AutomationMode(StrEnum):
    FULL = "full"
    MANUAL = "manual"
    HYBRID = "hybrid"


class ChannelKind(StrEnum):
    YOUTUBE = "youtube"


class ChannelStatus(StrEnum):
    CONNECTED = "connected"
    PENDING = "pending"
    REVOKED = "revoked"
    MOCK = "mock"


class JobStatus(StrEnum):
    QUEUED = "queued"
    RUNNING = "running"
    PAUSED = "paused"
    AWAITING_APPROVAL = "awaiting_approval"
    COMPLETED = "completed"
    FAILED = "failed"
    RETRYING = "retrying"
    CANCELED = "canceled"


class RunState(StrEnum):
    PENDING = "pending"
    RUNNING = "running"
    AWAITING_APPROVAL = "awaiting_approval"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELED = "canceled"


class StepStatus(StrEnum):
    PENDING = "pending"
    QUEUED = "queued"
    RUNNING = "running"
    AWAITING_APPROVAL = "awaiting_approval"
    APPROVED = "approved"
    COMPLETED = "completed"
    FAILED = "failed"
    RETRYING = "retrying"
    SKIPPED = "skipped"
    CANCELED = "canceled"


class ApprovalState(StrEnum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    REVISION_REQUESTED = "revision_requested"
    SKIPPED = "skipped"
    AUTO_APPROVED = "auto_approved"


class ApprovalKind(StrEnum):
    RESEARCH = "research"
    SCRIPT = "script"
    SCRIPT_REVISION = "script_revision"
    SCENE_BREAKDOWN = "scene_breakdown"
    IMAGE_SET = "image_set"
    VOICEOVER_SAMPLE = "voiceover_sample"
    THUMBNAIL = "thumbnail"
    METADATA = "metadata"
    FINAL_RENDER = "final_render"
    UPLOAD = "upload"


class StageCode(StrEnum):
    """Workflow pipeline stage identifiers (durable execution units)."""

    TOPIC_IDEATION = "topic_ideation"
    RESEARCH_COLLECTION = "research_collection"
    FACT_STRUCTURING = "fact_structuring"
    SCRIPT_GENERATION = "script_generation"
    SCRIPT_REVIEW = "script_review"
    SCENE_PLANNING = "scene_planning"
    PROMPT_GENERATION = "prompt_generation"
    IMAGE_GENERATION = "image_generation"
    IMAGE_QA = "image_qa"
    VOICEOVER_GENERATION = "voiceover_generation"
    SUBTITLE_GENERATION = "subtitle_generation"
    MUSIC_PREP = "music_prep"
    TIMELINE_ASSEMBLY = "timeline_assembly"
    RENDER = "render"
    THUMBNAIL_GENERATION = "thumbnail_generation"
    SEO_GENERATION = "seo_generation"
    UPLOAD_PREPARATION = "upload_preparation"
    UPLOAD = "upload"
    ANALYTICS_SYNC = "analytics_sync"
    RETENTION_FEEDBACK = "retention_feedback"


class NodeType(StrEnum):
    START = "start"
    TASK = "task"
    APPROVAL = "approval"
    CONDITION = "condition"
    RETRY = "retry"
    PROVIDER = "provider"
    MEMORY = "memory"
    RENDER = "render"
    UPLOAD = "upload"
    END = "end"


class AssetKind(StrEnum):
    IMAGE = "image"
    VIDEO = "video"
    AUDIO = "audio"
    MUSIC = "music"
    SFX = "sfx"
    FONT = "font"
    THUMBNAIL = "thumbnail"


class RenderStatus(StrEnum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELED = "canceled"


class UploadState(StrEnum):
    PENDING = "pending"
    PREPARING = "preparing"
    RESUME_INTERRUPTED = "resume_interrupted"
    UPLOADING = "uploading"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELED = "canceled"


class ScheduleState(StrEnum):
    ACTIVE = "active"
    PUBLISHED = "published"
    CANCELED = "canceled"
    FAILED = "failed"


class CreditCategory(StrEnum):
    LLM = "llm"
    EMBEDDINGS = "embeddings"
    IMAGE = "image"
    TTS = "tts"
    STT = "stt"
    VIDEO = "video"
    RENDER = "render"
    STORAGE = "storage"
    UPLOAD = "upload"


class CostStatus(StrEnum):
    ESTIMATED = "estimated"
    BILLED = "billed"


class NotificationType(StrEnum):
    INFO = "info"
    SUCCESS = "success"
    WARNING = "warning"
    ERROR = "error"


class FlagSeverity(StrEnum):
    INFO = "info"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    BLOCK = "block"


class AiGenerationKind(StrEnum):
    IMAGE = "image"
    TEXT = "text"
    AUDIO = "audio"
    VIDEO = "video"
