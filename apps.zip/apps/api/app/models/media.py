import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, TenantMixin, TimestampMixin, uuid_pk
from app.models.enums import AssetKind, RenderStatus, ScheduleState, UploadState


class Asset(Base, TenantMixin, TimestampMixin):
    __tablename__ = "assets"
    __table_args__ = (
        Index("ix_assets_project_kind", "project_id", "kind"),
        Index("ix_assets_org_created", "organization_id", "created_at"),
    )

    id: Mapped[uuid.UUID] = uuid_pk()
    project_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    scene_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("scenes.id", ondelete="SET NULL"), nullable=True, index=True
    )
    kind: Mapped[AssetKind] = mapped_column(String(24), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(300), nullable=False)
    storage_key: Mapped[str | None] = mapped_column(String(800), nullable=True)
    public_url: Mapped[str | None] = mapped_column(String(800), nullable=True)
    mime_type: Mapped[str | None] = mapped_column(String(120), nullable=True)
    size_bytes: Mapped[int | None] = mapped_column(Integer, nullable=True)
    width: Mapped[int | None] = mapped_column(Integer, nullable=True)
    height: Mapped[int | None] = mapped_column(Integer, nullable=True)
    duration_seconds: Mapped[float | None] = mapped_column(Float, nullable=True)
    provider: Mapped[str | None] = mapped_column(String(64), nullable=True)
    provenance_json: Mapped[dict | None] = mapped_column(nullable=True)  # {run_id, step, prompt_id}
    score: Mapped[float | None] = mapped_column(Float, nullable=True)  # image QA score
    status: Mapped[str] = mapped_column(String(24), default="ready", nullable=False)
    flags_json: Mapped[list | None] = mapped_column(nullable=True)


class AssetVariant(Base, TimestampMixin):
    __tablename__ = "asset_variants"

    id: Mapped[uuid.UUID] = uuid_pk()
    asset_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("assets.id", ondelete="CASCADE"), nullable=False, index=True
    )
    variant_name: Mapped[str] = mapped_column(String(64), nullable=False)  # original|preview|blur
    storage_key: Mapped[str | None] = mapped_column(String(800), nullable=True)
    public_url: Mapped[str | None] = mapped_column(String(800), nullable=True)
    width: Mapped[int | None] = mapped_column(Integer, nullable=True)
    height: Mapped[int | None] = mapped_column(Integer, nullable=True)
    size_bytes: Mapped[int | None] = mapped_column(Integer, nullable=True)


class Voiceover(Base, TenantMixin, TimestampMixin):
    __tablename__ = "voiceovers"

    id: Mapped[uuid.UUID] = uuid_pk()
    project_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    script_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("scripts.id", ondelete="SET NULL"), nullable=True
    )
    provider: Mapped[str] = mapped_column(String(64), default="mock", nullable=False)
    voice: Mapped[str] = mapped_column(String(120), nullable=False)
    language: Mapped[str] = mapped_column(String(24), default="en-US", nullable=False)
    status: Mapped[str] = mapped_column(String(24), default="generated", nullable=False)
    asset_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("assets.id", ondelete="SET NULL"), nullable=True
    )
    sample_url: Mapped[str | None] = mapped_column(String(800), nullable=True)
    character_count: Mapped[int | None] = mapped_column(Integer, nullable=True)
    duration_seconds: Mapped[float | None] = mapped_column(Float, nullable=True)


class Subtitle(Base, TenantMixin, TimestampMixin):
    __tablename__ = "subtitles"

    id: Mapped[uuid.UUID] = uuid_pk()
    project_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    voiceover_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("voiceovers.id", ondelete="SET NULL"), nullable=True
    )
    format: Mapped[str] = mapped_column(String(16), default="srt", nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    storage_key: Mapped[str | None] = mapped_column(String(800), nullable=True)


class Thumbnail(Base, TenantMixin, TimestampMixin):
    __tablename__ = "thumbnails"

    id: Mapped[uuid.UUID] = uuid_pk()
    project_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    asset_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("assets.id", ondelete="SET NULL"), nullable=True
    )
    title_text: Mapped[str | None] = mapped_column(String(200), nullable=True)
    style: Mapped[str | None] = mapped_column(String(120), nullable=True)
    status: Mapped[str] = mapped_column(String(24), default="generated", nullable=False)
    preview_url: Mapped[str | None] = mapped_column(String(800), nullable=True)
    score: Mapped[float | None] = mapped_column(Float, nullable=True)
    prompt_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("prompts.id", ondelete="SET NULL"), nullable=True
    )


class Render(Base, TenantMixin, TimestampMixin):
    __tablename__ = "renders"
    __table_args__ = (Index("ix_renders_project_status", "project_id", "status"),)

    id: Mapped[uuid.UUID] = uuid_pk()
    project_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("projects.id", ondelete="CASCADE"), nullable=False
    )
    run_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True, index=True)
    mode: Mapped[str] = mapped_column(String(16), default="final", nullable=False)  # final|preview
    preset: Mapped[str] = mapped_column(String(64), default="1080p", nullable=False)
    status: Mapped[RenderStatus] = mapped_column(
        String(24), default=RenderStatus.PENDING, nullable=False, index=True
    )
    output_key: Mapped[str | None] = mapped_column(String(800), nullable=True)
    output_url: Mapped[str | None] = mapped_column(String(800), nullable=True)
    duration_seconds: Mapped[int | None] = mapped_column(Integer, nullable=True)
    progress: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    meta_json: Mapped[dict | None] = mapped_column(nullable=True)  # resume checkpoint info


class RenderAttempt(Base, TimestampMixin):
    __tablename__ = "render_attempts"

    id: Mapped[uuid.UUID] = uuid_pk()
    render_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("renders.id", ondelete="CASCADE"), nullable=False, index=True
    )
    attempt: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    status: Mapped[RenderStatus] = mapped_column(String(24), default=RenderStatus.RUNNING)
    worker_id: Mapped[str | None] = mapped_column(String(120), nullable=True)
    log_path: Mapped[str | None] = mapped_column(String(500), nullable=True)
    progress: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class UploadJob(Base, TenantMixin, TimestampMixin):
    __tablename__ = "upload_jobs"
    __table_args__ = (Index("ix_upload_jobs_project_state", "project_id", "state"),)

    id: Mapped[uuid.UUID] = uuid_pk()
    project_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("projects.id", ondelete="CASCADE"), nullable=False
    )
    channel_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("channels.id", ondelete="SET NULL"), nullable=True
    )
    render_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("renders.id", ondelete="SET NULL"), nullable=True
    )
    provider: Mapped[str] = mapped_column(String(64), default="youtube", nullable=False)
    state: Mapped[UploadState] = mapped_column(String(24), default=UploadState.PENDING)
    title: Mapped[str | None] = mapped_column(String(200), nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    tags: Mapped[list | None] = mapped_column(nullable=True)
    category_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    made_for_kids: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    privacy_status: Mapped[str] = mapped_column(String(24), default="private", nullable=False)
    publish_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    external_video_id: Mapped[str | None] = mapped_column(String(160), nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    progress: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)


class UploadAttempt(Base, TimestampMixin):
    __tablename__ = "upload_attempts"

    id: Mapped[uuid.UUID] = uuid_pk()
    upload_job_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("upload_jobs.id", ondelete="CASCADE"), nullable=False, index=True
    )
    attempt: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    session_uri: Mapped[str | None] = mapped_column(String(800), nullable=True)  # resumable session
    bytes_uploaded: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    total_bytes: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    status: Mapped[UploadState] = mapped_column(String(24), default=UploadState.UPLOADING)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class Schedule(Base, TenantMixin, TimestampMixin):
    __tablename__ = "schedules"

    id: Mapped[uuid.UUID] = uuid_pk()
    project_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    upload_job_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("upload_jobs.id", ondelete="SET NULL"), nullable=True
    )
    cron_expression: Mapped[str | None] = mapped_column(String(64), nullable=True)
    publish_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    state: Mapped[ScheduleState] = mapped_column(String(24), default=ScheduleState.ACTIVE)
    timezone: Mapped[str] = mapped_column(String(64), default="UTC", nullable=False)
