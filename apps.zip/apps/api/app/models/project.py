import uuid

from sqlalchemy import Boolean, Float, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, SoftDeleteMixin, TenantMixin, TimestampMixin, uuid_pk
from app.db.pgvector import vector_column
from app.models.enums import AutomationMode, ChannelKind, ChannelStatus, ProjectStatus


class Channel(Base, TenantMixin, TimestampMixin):
    __tablename__ = "channels"

    id: Mapped[uuid.UUID] = uuid_pk()
    kind: Mapped[ChannelKind] = mapped_column(String(24), default=ChannelKind.YOUTUBE, nullable=False)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    handle: Mapped[str | None] = mapped_column(String(120), nullable=True)
    status: Mapped[ChannelStatus] = mapped_column(
        String(24), default=ChannelStatus.MOCK, nullable=False, index=True
    )
    provider_channel_id: Mapped[str | None] = mapped_column(String(160), nullable=True)
    thumbnail_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    default_settings_json: Mapped[dict | None] = mapped_column(nullable=True)
    connected_by: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )


class Project(Base, TenantMixin, SoftDeleteMixin, TimestampMixin):
    __tablename__ = "projects"
    __table_args__ = (Index("ix_projects_org_created", "organization_id", "created_at"),)

    id: Mapped[uuid.UUID] = uuid_pk()
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    topic: Mapped[str] = mapped_column(String(400), nullable=False)
    niche: Mapped[str | None] = mapped_column(String(200), nullable=True)
    tone: Mapped[str] = mapped_column(String(64), default="documentary", nullable=False)
    art_style: Mapped[str] = mapped_column(String(120), default="2d flat", nullable=False)
    duration_seconds: Mapped[int] = mapped_column(Integer, default=420, nullable=False)
    narration_language: Mapped[str] = mapped_column(String(24), default="en-US", nullable=False)
    voice_type: Mapped[str] = mapped_column(String(64), default="documentary-male", nullable=False)
    automation_mode: Mapped[AutomationMode] = mapped_column(
        String(24), default=AutomationMode.HYBRID, nullable=False
    )
    status: Mapped[ProjectStatus] = mapped_column(
        String(24), default=ProjectStatus.DRAFT, nullable=False, index=True
    )
    channel_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("channels.id", ondelete="SET NULL"), nullable=True
    )
    cover_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_by: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    meta_json: Mapped[dict | None] = mapped_column(nullable=True)


class ProjectSettings(Base, TimestampMixin):
    __tablename__ = "project_settings"

    id: Mapped[uuid.UUID] = uuid_pk()
    project_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("projects.id", ondelete="CASCADE"), unique=True, nullable=False
    )
    upload_preferences_json: Mapped[dict | None] = mapped_column(nullable=True)
    render_preset: Mapped[str] = mapped_column(String(64), default="1080p", nullable=False)
    provider_defaults_json: Mapped[dict | None] = mapped_column(nullable=True)
    auto_approve: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    auto_publish: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    watermark: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    brand_voice_json: Mapped[dict | None] = mapped_column(nullable=True)


class ProjectMemory(Base, TimestampMixin):
    """RAG memory rows: embeddings over facts, style notes and decisions."""

    __tablename__ = "project_memories"
    __table_args__ = (Index("ix_project_memories_org", "organization_id"),)

    id: Mapped[uuid.UUID] = uuid_pk()
    organization_id: Mapped[uuid.UUID] = mapped_column(nullable=False, index=True)
    project_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("projects.id", ondelete="CASCADE"), nullable=True, index=True
    )
    channel_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("channels.id", ondelete="CASCADE"), nullable=True
    )
    memory_type: Mapped[str] = mapped_column(String(32), nullable=False)  # style|fact|decision|note
    content: Mapped[str] = mapped_column(Text, nullable=False)
    source_step: Mapped[str | None] = mapped_column(String(64), nullable=True)
    provenance: Mapped[dict | None] = mapped_column(nullable=True)
    embedding: Mapped[list | None] = mapped_column(vector_column(), nullable=True)  # type: ignore[assignment]


class ResearchDocument(Base, TenantMixin, TimestampMixin):
    __tablename__ = "research_documents"

    id: Mapped[uuid.UUID] = uuid_pk()
    project_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    title: Mapped[str] = mapped_column(String(400), nullable=False)
    url: Mapped[str | None] = mapped_column(String(800), nullable=True)
    source: Mapped[str] = mapped_column(String(64), default="web", nullable=False)
    summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    content_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    meta_json: Mapped[dict | None] = mapped_column(nullable=True)


class ResearchSnippet(Base, TenantMixin, TimestampMixin):
    """Atomic factual chunks extracted from research; embedded for pgvector RAG."""

    __tablename__ = "research_snippets"
    __table_args__ = (Index("ix_research_snippets_project", "project_id"),)

    id: Mapped[uuid.UUID] = uuid_pk()
    project_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    document_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("research_documents.id", ondelete="CASCADE"), nullable=True
    )
    kind: Mapped[str] = mapped_column(String(32), default="fact", nullable=False)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    embedding: Mapped[list | None] = mapped_column(vector_column(), nullable=True)  # type: ignore[assignment]
    similarity: Mapped[float | None] = mapped_column(Float, nullable=True)
    meta_json: Mapped[dict | None] = mapped_column(nullable=True)
