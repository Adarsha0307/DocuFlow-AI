import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Index, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, TimestampMixin, uuid_pk
from app.models.enums import CreditCategory, SubscriptionStatus


class ApiKey(Base, TimestampMixin):
    __tablename__ = "api_keys"

    id: Mapped[uuid.UUID] = uuid_pk()
    organization_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True
    )
    created_by: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    key_hash: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    key_prefix: Mapped[str] = mapped_column(String(12), nullable=False)
    scopes: Mapped[list | None] = mapped_column(nullable=True)
    last_used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    revoked: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)


class ProviderCredential(Base, TimestampMixin):
    """Org-scoped encrypted credentials for external providers."""

    __tablename__ = "provider_credentials"
    __table_args__ = (
        Index("ix_provider_credentials_org_provider", "organization_id", "provider"),
    )

    id: Mapped[uuid.UUID] = uuid_pk()
    organization_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False
    )
    provider: Mapped[str] = mapped_column(String(64), nullable=False)
    capability: Mapped[str] = mapped_column(String(32), nullable=False)  # llm|tts|image|...
    label: Mapped[str] = mapped_column(String(120), nullable=True)
    encrypted_payload: Mapped[str] = mapped_column(Text, nullable=False)  # Fernet-encrypted JSON
    is_default: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    meta_json: Mapped[dict | None] = mapped_column(nullable=True)


class BillingCustomer(Base, TimestampMixin):
    __tablename__ = "billing_customers"

    id: Mapped[uuid.UUID] = uuid_pk()
    organization_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True
    )
    provider: Mapped[str] = mapped_column(String(32), default="mock", nullable=False)
    provider_customer_id: Mapped[str | None] = mapped_column(String(160), nullable=True)
    email: Mapped[str | None] = mapped_column(String(320), nullable=True)
    default_payment_method: Mapped[str | None] = mapped_column(String(160), nullable=True)


class BillingSubscription(Base, TimestampMixin):
    __tablename__ = "billing_subscriptions"

    id: Mapped[uuid.UUID] = uuid_pk()
    organization_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True
    )
    provider: Mapped[str] = mapped_column(String(32), default="mock", nullable=False)
    provider_subscription_id: Mapped[str | None] = mapped_column(String(160), nullable=True)
    plan_code: Mapped[str] = mapped_column(String(32), nullable=False)
    status: Mapped[SubscriptionStatus] = mapped_column(
        String(24), default=SubscriptionStatus.ACTIVE, nullable=False
    )
    current_period_start: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    current_period_end: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    cancel_at_period_end: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    meta_json: Mapped[dict | None] = mapped_column(nullable=True)


class QuotaCounter(Base, TimestampMixin):
    """Rolling usage counters per org, keyed by metric and period."""

    __tablename__ = "quota_counters"
    __table_args__ = (
        Index("ix_quota_counters_org_metric_period", "organization_id", "metric", "period"),
    )

    id: Mapped[uuid.UUID] = uuid_pk()
    organization_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False
    )
    metric: Mapped[str] = mapped_column(String(64), nullable=False)  # videos|render_seconds|...
    period: Mapped[str] = mapped_column(String(16), nullable=False)  # 2026-08
    value: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    limit: Mapped[float | None] = mapped_column(Float, nullable=True)
    soft_alert_at: Mapped[float | None] = mapped_column(Float, nullable=True)
    hard_stop_at: Mapped[float | None] = mapped_column(Float, nullable=True)


class UsageLog(Base, TimestampMixin):
    __tablename__ = "usage_logs"
    __table_args__ = (
        Index("ix_usage_logs_org_metric_period", "organization_id", "metric", "period"),
    )

    id: Mapped[uuid.UUID] = uuid_pk()
    organization_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False
    )
    project_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("projects.id", ondelete="CASCADE"), nullable=True, index=True
    )
    run_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True, index=True)
    user_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    metric: Mapped[str] = mapped_column(String(64), nullable=False)
    period: Mapped[str] = mapped_column(String(16), nullable=False)
    amount: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    unit: Mapped[str] = mapped_column(String(32), default="unit", nullable=False)
    category: Mapped[CreditCategory | None] = mapped_column(String(24), nullable=True)
    provider: Mapped[str | None] = mapped_column(String(64), nullable=True)
    meta_json: Mapped[dict | None] = mapped_column(nullable=True)
