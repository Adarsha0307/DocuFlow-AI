"""Prometheus-compatible metrics. Guarded so the app runs without prometheus_client."""

try:
    from prometheus_client import (
        CONTENT_TYPE_LATEST,
        Counter,
        Gauge,
        Histogram,
        generate_latest,
    )

    _AVAILABLE = True
except Exception:  # pragma: no cover
    _AVAILABLE = False

    class _Noop:
        def __getattr__(self, _):
            return self

        def __call__(self, *args, **kwargs):
            return self

        def labels(self, *args, **kwargs):
            return self

        def inc(self, *args, **kwargs):
            pass

        def observe(self, *args, **kwargs):
            pass

        def set(self, *args, **kwargs):
            pass

    def generate_latest(*args, **kwargs):  # type: ignore
        return b"# prometheus_client not installed\n"

    CONTENT_TYPE_LATEST = "text/plain"
    Counter = _Noop()
    Gauge = _Noop()
    Histogram = _Noop()


http_requests_total = Counter(
    "docuflow_http_requests_total", "HTTP requests", ["method", "path", "status"]
)
http_request_duration_seconds = Histogram(
    "docuflow_http_request_duration_seconds", "HTTP request latency", ["method", "path"]
)

workflow_runs_total = Counter("docuflow_workflow_runs_total", "Workflow runs", ["state"])
workflow_step_failures_total = Counter(
    "docuflow_workflow_step_failures_total", "Failed workflow steps", ["stage"]
)
workflow_step_retries_total = Counter(
    "docuflow_workflow_step_retries_total", "Step retries", ["stage"]
)
workflow_duration_seconds = Histogram(
    "docuflow_workflow_duration_seconds", "Workflow duration", ["stage"]
)

provider_latency_seconds = Histogram(
    "docuflow_provider_latency_seconds", "Provider call latency", ["provider", "capability", "status"]
)
provider_calls_total = Counter(
    "docuflow_provider_calls_total", "Provider calls", ["provider", "capability", "status"]
)
provider_errors_total = Counter(
    "docuflow_provider_errors_total", "Provider errors", ["provider", "capability"]
)

task_queue_depth = Gauge("docuflow_task_queue_depth", "Celery queue depth", ["queue"])
task_duration_seconds = Histogram(
    "docuflow_task_duration_seconds", "Task duration", ["task"]
)

render_seconds_total = Counter("docuflow_render_seconds_total", "Accumulated render seconds")
render_workers_active = Gauge("docuflow_render_workers_active", "Active render workers")
upload_attempts_total = Counter(
    "docuflow_upload_attempts_total", "Upload attempts", ["provider", "status"]
)

quota_exceeded_total = Counter("docuflow_quota_exceeded_total", "Quota breaches", ["org", "metric"])

COST_STORAGE: dict = {}


def record_cost(org_id: str, amount_usd: float) -> None:
    key = f"org:{org_id}"
    COST_STORAGE[key] = COST_STORAGE.get(key, 0.0) + amount_usd


def metrics_enabled() -> bool:
    return _AVAILABLE
