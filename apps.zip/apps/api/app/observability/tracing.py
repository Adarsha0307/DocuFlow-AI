"""OpenTelemetry setup helpers. All calls are no-ops when exporters are absent."""

import logging
from functools import wraps

from app.core.config import get_settings

logger = logging.getLogger(__name__)

_TRACER: object | None = None


def setup_tracing(service_name: str) -> None:
    global _TRACER
    settings = get_settings()
    if not settings.otel_exporter_endpoint:
        logger.info("OTLP exporter not configured — tracing disabled")
        return
    try:
        from opentelemetry import trace
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor

        resource = Resource.create({"service.name": service_name, "app.env": settings.app_env})
        provider = TracerProvider(resource=resource)
        exporter = OTLPSpanExporter(endpoint=settings.otel_exporter_endpoint)
        provider.add_span_processor(BatchSpanProcessor(exporter))
        trace.set_tracer_provider(provider)
        _TRACER = trace.get_tracer(service_name)
        logger.info("OpenTelemetry tracing enabled")
    except Exception as exc:  # pragma: no cover
        logger.warning("Failed to initialise OpenTelemetry: %s", exc)


def get_tracer(name: str):
    if _TRACER is not None:
        return _TRACER
    try:
        from opentelemetry import trace

        return trace.get_tracer(name)
    except Exception:  # pragma: no cover
        return None


def traced(name: str | None = None):
    """Decorator: start an OTEL span around a function when available, else no-op."""

    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            tracer = get_tracer("docuflow")
            span_name = name or fn.__qualname__
            if tracer is not None:
                with tracer.start_as_current_span(span_name):
                    return fn(*args, **kwargs)
            return fn(*args, **kwargs)

        return wrapper

    return decorator
