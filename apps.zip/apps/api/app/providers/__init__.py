"""Provider registry convenience exports + cost metadata."""

from app.providers.registry import ProviderRegistry, get_registry, registry  # noqa: F401

# Estimated per-unit prices (USD) for cost tracking when providers don't bill us
# directly. Keyed by (provider_id, capability) with fallback default prices.
UNIT_PRICES: dict[tuple[str, str], tuple[float, str]] = {
    ("openai", "llm"): (0.0000015, "token"),      # $1.50 / 1M tokens blended
    ("anthropic", "llm"): (0.000004, "token"),
    ("gemini", "llm"): (0.00000125, "token"),
    ("groq", "llm"): (0.0000005, "token"),
    ("mock", "llm"): (0.0000001, "token"),
    ("openai", "embeddings"): (0.0000001, "token"),
    ("mock", "embeddings"): (0.0, "texts"),
    ("elevenlabs", "tts"): (0.00018, "char"),
    ("cartesia", "tts"): (0.00003, "char"),
    ("mock", "tts"): (0.00001, "char"),
    ("stability", "image"): (0.04, "image"),
    ("flux", "image"): (0.04, "image"),
    ("mock", "image"): (0.002, "image"),
    ("runway", "video"): (0.05, "video_seconds"),
    ("mock", "video"): (0.001, "video_seconds"),
    ("mock", "upload"): (0.0, "uploads"),
    ("mock", "render"): (0.000001, "render_seconds"),
}

DEFAULT_PRICE = (0.000001, "unit")


def unit_price(provider: str, capability: str) -> tuple[float, str]:
    return UNIT_PRICES.get((provider, capability), DEFAULT_PRICE)
