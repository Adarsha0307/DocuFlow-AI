"""Provider abstraction contracts + shared result types.

Every external AI/media/upload integration implements one of these interfaces so
that orchestration code never touches a vendor SDK directly.
"""

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

CAPABILITY_LLM = "llm"
CAPABILITY_EMBEDDINGS = "embeddings"
CAPABILITY_TTS = "tts"
CAPABILITY_STT = "stt"
CAPABILITY_IMAGE = "image"
CAPABILITY_VIDEO = "video"
CAPABILITY_THUMBNAIL = "thumbnail"
CAPABILITY_SEO = "seo"
CAPABILITY_UPLOAD = "upload"
CAPABILITY_NOTIFY = "notify"
CAPABILITY_MEDIA = "media"

CAPABILITIES = {
    CAPABILITY_LLM,
    CAPABILITY_EMBEDDINGS,
    CAPABILITY_TTS,
    CAPABILITY_STT,
    CAPABILITY_IMAGE,
    CAPABILITY_VIDEO,
    CAPABILITY_THUMBNAIL,
    CAPABILITY_SEO,
    CAPABILITY_UPLOAD,
    CAPABILITY_NOTIFY,
    CAPABILITY_MEDIA,
}


@dataclass
class Usage:
    """Unit-based usage so cost tracking stays provider-agnostic."""

    quantity: float = 0.0
    unit: str = "unit"
    meta: dict[str, Any] = field(default_factory=dict)


@dataclass
class ProviderResult:
    ok: bool
    data: Any = None
    error: str | None = None
    provider: str = ""
    capability: str = ""
    usage: Usage | None = None
    latency_ms: float = 0.0
    meta: dict[str, Any] = field(default_factory=dict)
    started_at: float = field(default_factory=time.time)


class ProviderHealth:
    ok: bool
    latency_ms: float
    detail: str | None

    def __init__(self, ok: bool, latency_ms: float = 0.0, detail: str | None = None):
        self.ok = ok
        self.latency_ms = latency_ms
        self.detail = detail

    def as_dict(self) -> dict[str, Any]:
        return {"ok": self.ok, "latency_ms": self.latency_ms, "detail": self.detail}


class BaseProvider(ABC):
    """Common contract for every pluggable provider."""

    id: str = "base"
    display_name: str = "Base"
    capability: str = ""
    rate_limit_per_minute: int = 60

    @abstractmethod
    def check_health(self) -> ProviderHealth:
        """Lightweight liveness probe that won't hang."""

    def maybe_invalid(self) -> bool:  # pragma: no cover
        return True


class LLMProvider(BaseProvider):
    capability = CAPABILITY_LLM

    @abstractmethod
    def complete(
        self,
        messages: list[dict[str, str]],
        *,
        model: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 1024,
        system: str | None = None,
    ) -> ProviderResult:
        """Chat completion. Returns text in data, token usage in Usage."""


class EmbeddingsProvider(BaseProvider):
    capability = CAPABILITY_EMBEDDINGS

    @abstractmethod
    def embed(self, texts: list[str], *, model: str | None = None) -> ProviderResult:
        """Return list of embeddings aligned to input texts."""


class TTSProvider(BaseProvider):
    capability = CAPABILITY_TTS

    @abstractmethod
    def synthesize(self, text: str, *, voice: str, language: str = "en-US") -> ProviderResult:
        """Return audio bytes + metadata in ProviderResult.data."""


class STTProvider(BaseProvider):
    capability = CAPABILITY_STT

    @abstractmethod
    def transcribe(self, audio_bytes: bytes, *, language: str = "en-US") -> ProviderResult:
        """Return text transcript of the audio."""


class ImageProvider(BaseProvider):
    capability = CAPABILITY_IMAGE

    @abstractmethod
    def generate(self, prompt: str, *, negative_prompt: str | None = None, size: str = "16:9",
                 samples: int = 1) -> ProviderResult:
        """Return list of {bytes, mime_type, width, height} images."""


class VideoProvider(BaseProvider):
    capability = CAPABILITY_VIDEO

    @abstractmethod
    def generate(self, prompt: str, *, duration_seconds: int = 5) -> ProviderResult:
        """Return video bytes (mock returns a placeholder payload)."""


class ThumbnailProvider(LLMProvider):
    capability = CAPABILITY_THUMBNAIL

    def make_text(self, project_title: str, hooks: list[str]) -> ProviderResult:
        return self.complete(
            [
                {
                    "role": "user",
                    "content": (
                        f"Create 3 short engaging thumbnail text overlays for: {project_title}\n"
                        f"Hooks: {', '.join(hooks)}"
                    ),
                }
            ],
            temperature=0.8,
        )


class SEOProvider(LLMProvider):
    capability = CAPABILITY_SEO

    def generate_metadata(
        self, *, project: dict, script_preview: str, research_topics: list[str]
    ) -> ProviderResult:
        plan = {
            "topic": project.get("topic", ""),
            "niche": project.get("niche", ""),
            "hook_words": research_topics or [],
        }
        return self.complete(
            messages=[
                {
                    "role": "user",
                    "content": (
                        "Produce JSON with keys: title, description, tags, keywords, category_id "
                        f"for a documentary video. Return valid JSON only. Context {plan} "
                        f"Script preview: {script_preview[:1200]}"
                    ),
                }
            ],
            temperature=0.6,
            max_tokens=800,
        )


class UploadProvider(BaseProvider):
    capability = CAPABILITY_UPLOAD

    @abstractmethod
    def start_upload(self, *, title: str, description: str, tags: list[str] | None,
                     visibility: str, publish_at: str | None) -> ProviderResult:
        """Begin a resumable upload session; returns session metadata + upload URL."""

    @abstractmethod
    def upload_chunk(self, session_id: str, data: bytes, offset: int) -> ProviderResult:
        """Upload a chunk of file data at byte offset; returns bytes uploaded."""

    @abstractmethod
    def finish_upload(self, session_id: str, *, thumbnail_bytes: bytes | None = None) -> ProviderResult:
        """Commit the upload and set metadata; returns external_video_id."""


class NotificationProvider(BaseProvider):
    capability = CAPABILITY_NOTIFY

    @abstractmethod
    def send(self, *, to: str, subject: str, body: str) -> ProviderResult:
        ...


class MediaProvider(BaseProvider):
    """FFmpeg-based media pipeline (render, thumbnails, probes)."""

    capability = CAPABILITY_MEDIA

    @abstractmethod
    def probe(self, file_path: str) -> dict[str, Any]:
        ...

    @abstractmethod
    def render(self, *, scene_specs: list[dict], output_path: str, preset: dict,
                   on_progress) -> ProviderResult:
        ...
