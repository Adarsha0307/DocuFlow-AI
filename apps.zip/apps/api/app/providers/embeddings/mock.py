import hashlib

from app.providers.base import EmbeddingsProvider, ProviderHealth, ProviderResult, Usage

DIM = 64


def deterministic_embedding(text: str, dim: int = DIM) -> list[float]:
    """Stable pseudo-random embedding from text hashing (offline RAG support)."""
    vec: list[float] = []
    for i in range(dim):
        h = hashlib.sha256(f"{text}:{i}".encode()).digest()
        vec.append((h[0] / 255.0) * 2 - 1)
    norm = (sum(v * v for v in vec) ** 0.5) or 1.0
    return [v / norm for v in vec]


class MockEmbeddingsProvider(EmbeddingsProvider):
    id = "mock"
    display_name = "Mock embeddings"
    rate_limit_per_minute = 3000

    def check_health(self) -> ProviderHealth:
        return ProviderHealth(True, latency_ms=1)

    def embed(self, texts: list[str], *, model=None):
        vectors = [deterministic_embedding(t) for t in texts]
        return ProviderResult(
            ok=True,
            data=vectors,
            provider=self.id,
            usage=Usage(quantity=len(texts), unit="texts"),
            meta={"model": model or "mock-embedding", "dimension": DIM},
        )
