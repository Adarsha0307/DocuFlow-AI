import httpx

from app.core.config import get_settings
from app.providers.base import EmbeddingsProvider, ProviderHealth, ProviderResult, Usage


class OpenAIEmbeddingsProvider(EmbeddingsProvider):
    id = "openai"
    display_name = "OpenAI embeddings"
    rate_limit_per_minute = 900

    def __init__(self) -> None:
        self.api_key = get_settings().openai_api_key or None  # type: ignore[attr-defined]

    def check_health(self) -> ProviderHealth:
        if not self.api_key:
            return ProviderHealth(False, detail="OPENAI_API_KEY not configured")
        return ProviderHealth(True, latency_ms=0)

    def embed(self, texts, *, model=None):
        if not self.api_key:
            return ProviderResult(False, error="OPENAI_API_KEY not configured", provider=self.id)
        model = model or "text-embedding-3-small"
        payload = {"model": model, "input": texts}
        try:
            r = httpx.post(
                "https://api.openai.com/v1/embeddings",
                headers={"Authorization": f"Bearer {self.api_key}"},
                json=payload,
                timeout=60,
            )
            r.raise_for_status()
            data = r.json()
            vectors = [item["embedding"] for item in data["data"]]
            usage = data.get("usage", {})
            return ProviderResult(
                ok=True,
                data=vectors,
                provider=self.id,
                usage=Usage(
                    quantity=usage.get("total_tokens", 0), unit="tokens", meta=usage
                ),
                meta={"model": model, "dimension": len(vectors[0]) if vectors else 0},
            )
        except httpx.HTTPError as exc:
            return ProviderResult(False, error=str(exc), provider=self.id)
