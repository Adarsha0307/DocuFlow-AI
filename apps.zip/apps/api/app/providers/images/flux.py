import httpx

from app.core.config import get_settings
from app.providers.base import ImageProvider, ProviderHealth, ProviderResult, Usage


class FluxImageProvider(ImageProvider):
    """Flux via the bfl/cubey image-generation API shape (config-driven endpoint)."""

    id = "flux"
    display_name = "Flux (BFL)"
    rate_limit_per_minute = 90

    def __init__(self) -> None:
        self.api_key = get_settings().flux_api_key or None  # type: ignore[attr-defined]

    def check_health(self) -> ProviderHealth:
        if not self.api_key:
            return ProviderHealth(False, detail="FLUX_API_KEY not configured")
        return ProviderHealth(True, latency_ms=0)

    def generate(self, prompt, *, negative_prompt=None, size="16:9", samples=1):
        if not self.api_key:
            return ProviderResult(False, error="FLUX_API_KEY not configured", provider=self.id)
        try:
            r = httpx.post(
                "https://api.bfl.ai/v1/flux-pro-1.1-ultra",
                headers={"Authorization": f"Bearer {self.api_key}"},
                json={
                    "prompt": prompt,
                    "aspect_ratio": "16:9" if size == "16:9" else "9:16",
                    "output_format": "png",
                },
                timeout=300,
            )
            r.raise_for_status()
            result = r.json()
            image_url = result.get("result") or result.get("image_url")
            if not image_url:
                return ProviderResult(False, error="Flux returned no image URL", provider=self.id)
            img = httpx.get(image_url, timeout=120)
            img.raise_for_status()
            return ProviderResult(
                ok=True,
                data=[{"bytes": img.content, "mime_type": "image/png"}],
                provider=self.id,
                usage=Usage(quantity=1, unit="images"),
                meta={"model": "flux-pro-1.1-ultra"},
            )
        except Exception as exc:
            return ProviderResult(False, error=str(exc), provider=self.id)
