import struct
import zlib

from app.providers.base import ImageProvider, ProviderHealth, ProviderResult, Usage


def _png_from_text(text: str, width: int = 1280, height: int = 720, seed: int = 0x5EED) -> bytes:
    """Produce a deterministic 16:9 PNG where the prompt seeds the palette. Used for offline demos."""
    import hashlib

    h = hashlib.sha256(text.encode()).digest()
    r0, g0, b0 = h[0] % 180 + 20, h[1] % 180 + 20, h[2] % 180 + 20
    raw = bytearray()
    for _y in range(height):
        raw.append(0)  # filter type none
        for x in range(width):
            grad = (x * 255) // width
            raw.extend(
                bytes(
                    [
                        (r0 + grad // 6) % 256,
                        (g0 + grad // 4) % 256,
                        (b0 + grad // 3) % 256,
                    ]
                )
            )
    def chunk(tag: bytes, data: bytes) -> bytes:
        c = tag + data
        return struct.pack(">I", len(data)) + c + struct.pack(">I", zlib.crc32(c) & 0xFFFFFFFF)

    ihdr = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    return (
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", ihdr)
        + chunk(b"IDAT", zlib.compress(bytes(raw)))
        + chunk(b"IEND", b"")
    )


class MockImageProvider(ImageProvider):
    id = "mock"
    display_name = "Mock Images"
    rate_limit_per_minute = 2400

    def check_health(self) -> ProviderHealth:
        return ProviderHealth(True, latency_ms=2)

    def generate(self, prompt, *, negative_prompt=None, size="16:9", samples=1):
        width, height = (1280, 720) if size == "16:9" else (720, 1280)
        images = [
            {
                "bytes": _png_from_text(f"{prompt}#{i}", width, height),
                "mime_type": "image/png",
                "width": width,
                "height": height,
            }
            for i in range(samples)
        ]
        return ProviderResult(
            ok=True,
            data=images,
            provider=self.id,
            usage=Usage(quantity=samples, unit="images"),
            meta={"mock": True, "size": size},
        )
