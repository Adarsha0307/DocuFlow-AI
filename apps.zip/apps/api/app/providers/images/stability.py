import httpx

from app.core.config import get_settings
from app.providers.base import ImageProvider, ProviderHealth, ProviderResult, Usage


class StabilityImageProvider(ImageProvider):
    id = "stability"
    display_name = "Stability AI"
    rate_limit_per_minute = 60

    def __init__(self) -> None:
        self.api_key = get_settings().stability_api_key or None  # type: ignore[attr-defined]

    def check_health(self) -> ProviderHealth:
        if not self.api_key:
            return ProviderHealth(False, detail="STABILITY_API_KEY not configured")
        return ProviderHealth(True, latency_ms=0)

    def generate(self, prompt, *, negative_prompt=None, size="16:9", samples=1):
        if not self.api_key:
            return ProviderResult(False, error="STABILITY_API_KEY not configured", provider=self.id)
        aspect = "16:9" if size == "16:9" else "9:16" if size == "9:16" else size
        payload = {"prompt": prompt, "aspect_ratio": aspect, "negative_prompt": negative_prompt or ""}
        try:
            r = httpx.post(
                "https://api.stability.ai/v2beta/stable-image/generate/sd3",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Accept": "image/*",
                },
                data=payload,
                timeout=240,
            )
            r.raise_for_status()
            return ProviderResult(
                ok=True,
                data=[{"bytes": r.content, "mime_type": r.headers.get("content-type", "image/png")}],
                provider=self.id,
                usage=Usage(quantity=1, unit="images"),
                meta={"model": "sd3", "size": size},
            )
        except httpx.HTTPError as exc:
            return ProviderResult(False, error=str(exc), provider=self.id)
