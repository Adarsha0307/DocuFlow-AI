import httpx

from app.core.config import get_settings
from app.providers.base import LLMProvider, ProviderHealth, ProviderResult, Usage


class AnthropicProvider(LLMProvider):
    id = "anthropic"
    display_name = "Claude (Anthropic)"
    rate_limit_per_minute = 300

    def __init__(self) -> None:
        self.api_key = get_settings().anthropic_api_key or None  # type: ignore[attr-defined]
        self.base_url = "https://api.anthropic.com/v1"

    def check_health(self) -> ProviderHealth:
        if not self.api_key:
            return ProviderHealth(False, detail="ANTHROPIC_API_KEY not configured")
        return ProviderHealth(True, latency_ms=0)  # no cheap ping endpoint

    def _headers(self) -> dict:
        return {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        }

    def complete(self, messages, *, model=None, temperature=0.7, max_tokens=1024, system=None):
        if not self.api_key:
            return ProviderResult(False, error="ANTHROPIC_API_KEY not configured", provider=self.id)
        payload = {
            "model": model or "claude-3-5-sonnet-latest",
            "temperature": temperature,
            "max_tokens": max_tokens,
            "system": system or "",
            "messages": messages,
        }
        try:
            r = httpx.post(f"{self.base_url}/messages", headers=self._headers(), json=payload, timeout=120)
            r.raise_for_status()
            data = r.json()
            content = "".join(b.get("text", "") for b in data.get("content", []))
            usage = data.get("usage", {})
            return ProviderResult(
                ok=True,
                data={"content": content},
                provider=self.id,
                usage=Usage(
                    quantity=usage.get("input_tokens", 0) + usage.get("output_tokens", 0),
                    unit="tokens",
                    meta=usage,
                ),
                meta={"model": model or "claude-3-5-sonnet-latest"},
            )
        except httpx.HTTPError as exc:
            return ProviderResult(False, error=str(exc), provider=self.id)
