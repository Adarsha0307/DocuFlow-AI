import httpx

from app.core.config import get_settings
from app.providers.base import LLMProvider, ProviderHealth, ProviderResult, Usage


class GeminiProvider(LLMProvider):
    id = "gemini"
    display_name = "Gemini (Google)"
    rate_limit_per_minute = 400

    def __init__(self) -> None:
        self.api_key = get_settings().gemini_api_key or None  # type: ignore[attr-defined]

    def check_health(self) -> ProviderHealth:
        if not self.api_key:
            return ProviderHealth(False, detail="GEMINI_API_KEY not configured")
        return ProviderHealth(True, latency_ms=0)

    def _url(self, model: str) -> str:
        return (
            f"https://generativelanguage.googleapis.com/v1beta/models/{model}"
            f":generateContent?key={self.api_key}"
        )

    def complete(self, messages, *, model=None, temperature=0.7, max_tokens=1024, system=None):
        if not self.api_key:
            return ProviderResult(False, error="GEMINI_API_KEY not configured", provider=self.id)
        model = model or "gemini-1.5-flash"
        parts = [{"text": m["content"]} for m in messages]
        if system:
            parts.insert(0, {"text": system})
        payload = {
            "contents": [{"parts": parts}],
            "generationConfig": {"temperature": temperature, "maxOutputTokens": max_tokens},
        }
        try:
            r = httpx.post(self._url(model), json=payload, timeout=120)
            r.raise_for_status()
            data = r.json()
            candidates = data.get("candidates", [])
            content = candidates[0]["content"]["parts"][0]["text"] if candidates else ""
            usage = data.get("usageMetadata", {})
            return ProviderResult(
                ok=True,
                data={"content": content},
                provider=self.id,
                usage=Usage(
                    quantity=usage.get("totalTokenCount", 0), unit="tokens", meta=usage
                ),
                meta={"model": model},
            )
        except httpx.HTTPError as exc:
            return ProviderResult(False, error=str(exc), provider=self.id)
