import httpx

from app.core.config import get_settings
from app.providers.base import LLMProvider, ProviderHealth, ProviderResult, Usage


class GroqProvider(LLMProvider):
    """OpenAI-compatible endpoint via Groq (fast inference)."""

    id = "groq"
    display_name = "Groq"
    rate_limit_per_minute = 800

    def __init__(self) -> None:
        self.api_key = get_settings().groq_api_key or None  # type: ignore[attr-defined]
        self.base_url = "https://api.groq.com/openai/v1"

    def check_health(self) -> ProviderHealth:
        if not self.api_key:
            return ProviderHealth(False, detail="GROQ_API_KEY not configured")
        return ProviderHealth(True, latency_ms=0)

    def complete(self, messages, *, model=None, temperature=0.7, max_tokens=1024, system=None):
        if not self.api_key:
            return ProviderResult(False, error="GROQ_API_KEY not configured", provider=self.id)
        payload = {
            "model": model or "llama-3.3-70b-versatile",
            "temperature": temperature,
            "max_tokens": max_tokens,
            "messages": ([{"role": "system", "content": system}] if system else []) + messages,
        }
        try:
            r = httpx.post(
                f"{self.base_url}/chat/completions",
                headers={"Authorization": f"Bearer {self.api_key}"},
                json=payload,
                timeout=120,
            )
            r.raise_for_status()
            data = r.json()
            content = data["choices"][0]["message"]["content"]
            usage = data.get("usage", {})
            return ProviderResult(
                ok=True,
                data={"content": content},
                provider=self.id,
                usage=Usage(quantity=usage.get("total_tokens", 0), unit="tokens", meta=usage),
                meta={"model": payload["model"]},
            )
        except httpx.HTTPError as exc:
            return ProviderResult(False, error=str(exc), provider=self.id)
