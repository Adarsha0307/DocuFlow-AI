import json
import re

from app.providers.base import LLMProvider, ProviderHealth, ProviderResult, Usage


class MockLLMProvider(LLMProvider):
    """Deterministic offline LLM that produces realistic documentary payloads."""

    id = "mock"
    display_name = "Mock LLM"
    rate_limit_per_minute = 6000

    def check_health(self) -> ProviderHealth:
        return ProviderHealth(True, latency_ms=1.0)

    def complete(
        self,
        messages,
        *,
        model=None,
        temperature=0.7,
        max_tokens=1024,
        system=None,
    ) -> ProviderResult:
        last = messages[-1]["content"]
        joined = "\n".join(m["content"] for m in messages)

        if self._wants_json(last):
            content = self._json_response(last)
        elif "thumbnail text overlays" in last:
            content = self._thumbnail_texts(joined)
        elif "documentary" in last.lower() and ("topic" in last or "script" in last.lower()):
            content = self._script(joined)
        else:
            content = self._generic(joined)

        estimate_tokens = max(1, len(joined) // 4) + len(content) // 4
        return ProviderResult(
            ok=True,
            data={"content": content},
            provider=self.id,
            capability=self.capability,
            usage=Usage(quantity=estimate_tokens, unit="tokens"),
            latency_ms=12.0,
            meta={"model": model or "mock-text", "mock": True},
        )

    # --- helpers ---------------------------------------------------------
    @staticmethod
    def _wants_json(last: str) -> bool:
        lowered = last.lower()
        return "json" in lowered and ("keys" in lowered or "return" in lowered)

    def _json_response(self, last: str) -> str:
        topic = self._extract_topic(last)
        if "thumbnail" in last:
            payload = {
                "options": [
                    {"text": "THE HIDDEN TRUTH", "style": "bold serif, gold stroke"},
                    {"text": "NOBODY TELLS YOU", "style": "impact, red underline"},
                    {"text": "THE DARK SECRET", "style": "condensed, blue glow"},
                ]
            }
        elif "tags" in last or "description" in last:
            payload = {
                "title": f"{topic}: The Untold Story",
                "description": (
                    f"A 7-minute documentary exploring {topic}. "
                    "Backed by primary sources, edge fact-checking and cinematic pacing. "
                    "0:00 Hook | 0:45 The Beginning | 4:10 The Turning Point | 6:30 The Aftermath"
                ),
                "tags": ["documentary", "history", "mystery", topic.lower()],
                "keywords": ["documentary", "untold story", topic.lower()],
                "category_id": "27",
            }
        else:
            payload = self._echo_requested_keys(last, topic)
        return json.dumps(payload, indent=2)

    @staticmethod
    def _echo_requested_keys(last: str, topic: str) -> dict:
        """Build a JSON payload whose keys mirror the keys requested in the prompt."""
        match = re.search(r"keys:\s*([^\n\)\]]+)", last)
        raw = match.group(1) if match else "summary, facts"
        keys = [k.strip().lstrip("*") for k in re.split(r"[,\|]|\band\b", raw) if k.strip() and k.strip().isidentifier()]

        list_like = {
            "sources", "facts", "scenes", "prompts", "options", "lessons",
            "scores", "segments", "timeline", "tracks", "subtitle_segments", "images",
        }
        count_keys = {
            "source_count", "scene_count", "prompt_count", "image_count", "verified_count",
            "total_tracks", "segments_count", "sections", "total",
        }
        payload: dict = {"topic": topic}
        for k in keys:
            if k in payload:
                continue
            if k in list_like:
                payload[k] = []
            elif k in count_keys:
                payload[k] = max(1, (len(raw) // 40) + 1)
            elif k in ("word_count", "estimated_duration_s", "average_score", "duration_s"):
                payload[k] = 300 if k == "word_count" else 60
            else:
                payload[k] = f"{k.replace('_', ' ').capitalize()} for {topic}"
        return payload or {"summary": f"Research summary for {topic}.", "facts": 12}

    def _thumbnail_texts(self, joined: str) -> str:
        topic = self._extract_topic(joined)
        return (
            "1. THE HIDDEN TRUTH — bold serif, gold stroke\n"
            f"2. NOBODY TELLS YOU THIS — impact, red underline ({topic})\n"
            "3. THE DARK SECRET — condensed, blue glow"
        )

    def _script(self, joined: str) -> str:
        topic = self._extract_topic(joined)
        return (
            f"# {topic}\n\n"
            "## Hook\n"
            "Most people have never heard the true story behind this. "
            "In the next eight minutes, we uncover what really happened.\n\n"
            "## Section 1 — The Beginning\n"
            "It started quietly, long before the public ever noticed. "
            "The details were hidden in archives nobody opened for decades.\n\n"
            "## Section 2 — The Turning Point\n"
            "When the evidence surfaced, no one could ignore it any longer. "
            "Eyewitness accounts, letters, and records told one consistent story.\n\n"
            "## Section 3 — The Aftermath\n"
            "The consequences rewrote the rules for everyone involved. "
            "Today, the echoes of those events still shape the world we live in.\n\n"
            "## Closer\n"
            "What you just watched is only a slice of the full picture — "
            "and the picture keeps changing. Subscribe for the next chapter."
        )

    @staticmethod
    def _generic(joined: str) -> str:
        return (
            "Here is a structured output for your request.\n\n"
            f"Summary: {joined[:200]}"
        )

    @staticmethod
    def _extract_topic(text: str) -> str:
        for pattern in (r"topic\s*[:=]\s*([^\n,]+)", r"\*{0,2}\s*topic[^\n]*?:\s*([^\n]+)"):
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1).strip()
        return "The True Story"
