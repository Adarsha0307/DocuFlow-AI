import httpx

from app.core.config import get_settings
from app.providers.base import LLMProvider, ProviderHealth, ProviderResult, Usage


class OpenAIProvider(LLMProvider):
    id = "openai"
    display_name = "OpenAI"
    rate_limit_per_minute = 500

    def __init__(self) -> None:
        self.api_key = get_settings().openai_api_key or None  # type: ignore[attr-defined]
        self.base_url = "https://api.openai.com/v1"

    def check_health(self) -> ProviderHealth:
        if not self.api_key:
            return ProviderHealth(False, detail="OPENAI_API_KEY not configured")
        try:
            r = httpx.get(f"{self.base_url}/models", headers=self._headers(), timeout=4)
            return ProviderHealth(r.is_success, detail=str(r.status_code))
        except Exception as exc:
            return ProviderHealth(False, detail=str(exc))

    def _headers(self) -> dict:
        return {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}

    def complete(self, messages, *, model=None, temperature=0.7, max_tokens=1024, system=None):
        if not self.api_key:
            return ProviderResult(False, error="OPENAI_API_KEY not configured", provider=self.id)
        payload = {
            "model": model or "gpt-4o-mini",
            "temperature": temperature,
            "max_tokens": max_tokens,
            "messages": ([{"role": "system", "content": system}] if system else []) + messages,
        }
        try:
            r = httpx.post(
                f"{self.base_url}/chat/completions",
                headers=self._headers(),
                json=payload,
                timeout=120,
            )
            r.raise_for_status()
            data = r.json()
            content = data["choices"][0]["message"]["content"]
            usage = data.get("usage", {})
            return ProviderResult(
                ok=True,
                data={"content": content},
                provider=self.id,
                usage=Usage(
                    quantity=usage.get("total_tokens", 0),
                    unit="tokens",
                    meta={
                        "prompt": usage.get("prompt_tokens"),
                        "completion": usage.get("completion_tokens"),
                    },
                ),
                meta={"model": model or "gpt-4o-mini"},
            )
        except httpx.HTTPError as exc:
            return ProviderResult(False, error=str(exc), provider=self.id)
