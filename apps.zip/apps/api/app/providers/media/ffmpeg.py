"""FFmpeg-backed media provider: probe, render, thumbnail extraction.

Resumability: render() accepts `start_at_scene` so a partially-finished pipeline
can resume from the last completed scene (outputs are named per segment and
assembled at the end, so a crash only re-does the final concat).
"""

import json
import logging
import os
import shutil
import subprocess
import tempfile

from app.core.config import get_settings
from app.providers.base import MediaProvider, ProviderHealth, ProviderResult, Usage

logger = logging.getLogger(__name__)

EXPORT_PRESETS: dict[str, dict] = {
    "720p": {"w": 1280, "h": 720, "fps": 30, "crf": 21, "video_bitrate": "5M", "audio_bitrate": "160k"},
    "1080p": {"w": 1920, "h": 1080, "fps": 30, "crf": 18, "video_bitrate": "8M", "audio_bitrate": "192k"},
    "4k": {"w": 3840, "h": 2160, "fps": 30, "crf": 17, "video_bitrate": "24M", "audio_bitrate": "256k"},
}

ZOOM_STYLES = {
    "zoom-in": "zoompan=z='min(zoom+0.0015,1.5)':d={frames}:s={w}x{h}:fps={fps}",
    "zoom-out": "zoompan=z='if(lte(zoom,1.0),1.5,max(1.001,zoom-0.0015))':d={frames}:s={w}x{h}:fps={fps}",
    "pan-left": "zoompan=z=1.15:x='x-(iw-iw/zoom)*on/{frames}':y='(ih-ih/zoom)/2':d={frames}:s={w}x{h}:fps={fps}",
    "pan-right": "zoompan=z=1.15:x='(iw-iw/zoom)*on/{frames}':y='(ih-ih/zoom)/2':d={frames}:s={w}x{h}:fps={fps}",
    "static": "zoompan=z=1.0:d={frames}:s={w}x{h}:fps={fps}",
}


class FFmpegMediaProvider(MediaProvider):
    id = "ffmpeg"
    display_name = "FFmpeg"
    rate_limit_per_minute = 600

    def __init__(self) -> None:
        s = get_settings()
        self.ffmpeg = s.ffmpeg_path
        self.ffprobe = s.ffprobe_path

    def check_health(self) -> ProviderHealth:
        if shutil.which(self.ffmpeg) is None:
            return ProviderHealth(False, detail=f"ffmpeg not found on PATH ({self.ffmpeg})")
        try:
            r = subprocess.run(
                [self.ffmpeg, "-version"], capture_output=True, text=True, timeout=5
            )
            return ProviderHealth(r.returncode == 0, detail=r.stdout.splitlines()[0][:80])
        except Exception as exc:
            return ProviderHealth(False, detail=str(exc))

    def probe(self, file_path: str) -> dict[str, object]:
        if not os.path.exists(file_path):
            return {"ok": False, "error": "file not found"}
        cmd = [
            self.ffprobe, "-v", "quiet", "-print_format", "json",
            "-show_format", "-show_streams", file_path,
        ]
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            data = json.loads(r.stdout or "{}")
            streams = data.get("streams", [])
            video = next((s for s in streams if s.get("codec_type") == "video"), {})
            audio = next((s for s in streams if s.get("codec_type") == "audio"), {})
            return {
                "ok": True,
                "duration": float(data.get("format", {}).get("duration", 0)),
                "width": video.get("width"),
                "height": video.get("height"),
                "has_audio": bool(audio),
                "container": (data.get("format", {}).get("format_name", "") or "").split(",")[0],
            }
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    # --- rendering -------------------------------------------------------
    def render(self, *, scene_specs, output_path, preset, on_progress=None, start_at_scene=0):
        preset_cfg = EXPORT_PRESETS.get(preset, EXPORT_PRESETS["1080p"])
        total = len(scene_specs)
        if total == 0:
            return ProviderResult(False, error="no scenes to render", provider=self.id)

        # Pre-render each scene segment (independent => resumable)
        segment_paths = []
        workdir = tempfile.mkdtemp(prefix="docuflow_render_")
        try:
            for idx, spec in enumerate(scene_specs):
                if idx < start_at_scene:
                    continue
                seg = os.path.join(workdir, f"seg_{idx:03d}.mp4")
                ok = self._render_segment(spec, seg, preset_cfg)
                if not ok:
                    return ProviderResult(False, error=f"segment {idx} failed", provider=self.id)
                segment_paths.append((idx, seg))
                if on_progress:
                    on_progress((idx + 1) / total)
            # Concat segments
            if not segment_paths:
                return ProviderResult(False, error="nothing to assemble", provider=self.id)
            segment_paths.sort(key=lambda t: t[0])
            files = [p for _, p in segment_paths]
            final_ok = self._concat(files, output_path, preset_cfg)
            if not final_ok:
                return ProviderResult(False, error="concat step failed", provider=self.id)
            return ProviderResult(
                ok=True,
                data={"output": output_path, "scenes": total, "preset": preset},
                provider=self.id,
                usage=Usage(quantity=0, unit="render_seconds", meta={"scenes": total}),
                meta={"preset": preset, "segments": len(files)},
            )
        finally:
            shutil.rmtree(workdir, ignore_errors=True)

    def _render_segment(self, spec: dict, out_path: str, preset_cfg: dict) -> bool:
        img = spec["image_path"]
        dur = float(spec.get("duration", 8.0))
        fps = preset_cfg["fps"]
        w, h = preset_cfg["w"], preset_cfg["h"]
        frames = max(1, int(dur * fps))
        zoom = ZOOM_STYLES.get(spec.get("motion", "zoom-in"), ZOOM_STYLES["zoom-in"])
        zoom = zoom.format(frames=frames, w=w, h=h, fps=fps)
        audio_args: list[str] = []
        filter_chain = [
            f"[0:v]scale={w*2}:{h*2}:force_original_aspect_ratio=increase,crop={w*2}:{h*2},{zoom}[v0]",
        ]
        has_voice = False
        if spec.get("voice_path"):
            audio_args = ["-i", spec["voice_path"]]
            has_voice = True
        if spec.get("music_path"):
            audio_args += ["-i", spec["music_path"]]
            # duck music under voice with a sidechain compressor
            if has_voice:
                filter_chain.append(
                    "[1:a][2:a]sidechaincompress=threshold=0.05:ratio=8:attack=5:release=150[aout]"
                )
            else:
                filter_chain.append("[2:a]aformat=sample_rates=48000:channel_layouts=stereo[aout]")
        elif has_voice:
            filter_chain.append("[1:a]aformat=sample_rates=48000:channel_layouts=stereo[aout]")

        cmd = [
            self.ffmpeg, "-y", "-loglevel", "error",
            "-loop", "1", "-t", f"{dur}", "-i", img,
            *audio_args,
            "-filter_complex", ";".join(filter_chain),
            "-map", "[v0]",
            *(["-map", "[aout]", "-c:a", "aac", "-b:a", preset_cfg["audio_bitrate"]] if any("aout" in f for f in filter_chain) else []),
            "-c:v", "libx264", "-preset", "medium", "-crf", str(preset_cfg["crf"]),
            "-pix_fmt", "yuv420p", "-r", str(fps),
            "-movflags", "+faststart",
            out_path,
        ]
        return self._run(cmd)

    def _concat(self, inputs: list[str], out_path: str, preset_cfg: dict) -> bool:
        with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False) as f:
            for p in inputs:
                f.write(f"file '{p.replace(chr(39), chr(39)+chr(39)+chr(39))}'\n")
            list_path = f.name
        cmd = [
            self.ffmpeg, "-y", "-loglevel", "error",
            "-f", "concat", "-safe", "0", "-i", list_path,
            "-c", "copy",
            "-movflags", "+faststart",
            out_path,
        ]
        ok = self._run(cmd)
        os.unlink(list_path)
        return ok

    def _run(self, cmd: list[str]) -> bool:
        logger.info("ffmpeg %s", " ".join(cmd[:6]))
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
            if r.returncode != 0:
                logger.error("ffmpeg failed: %s", r.stderr[-800:])
            return r.returncode == 0
        except Exception as exc:
            logger.error("ffmpeg error: %s", exc)
            return False

    def extract_frame(self, video_path: str, out_path: str, at_seconds: float = 1.0) -> bool:
        cmd = [
            self.ffmpeg, "-y", "-loglevel", "error",
            "-ss", f"{at_seconds}", "-i", video_path,
            "-frames:v", "1", "-q:v", "2", out_path,
        ]
        return self._run(cmd)
