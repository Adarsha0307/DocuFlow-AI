"""Media provider that gracefully degrades: uses FFmpeg when present, else writes manifest."""

import json
import shutil

from app.providers.base import MediaProvider, ProviderHealth, ProviderResult, Usage
from app.providers.media.ffmpeg import FFmpegMediaProvider


class MockMediaProvider(MediaProvider):
    id = "mock"
    display_name = "Media (auto)"
    rate_limit_per_minute = 600

    def __init__(self) -> None:
        self._ffmpeg = FFmpegMediaProvider() if shutil.which("ffmpeg") else None

    def check_health(self) -> ProviderHealth:
        if self._ffmpeg:
            return self._ffmpeg.check_health()
        return ProviderHealth(True, detail="mock renderer (no ffmpeg)")

    def probe(self, file_path: str) -> dict[str, object]:
        if self._ffmpeg:
            return self._ffmpeg.probe(file_path)
        return {"ok": False, "error": "no ffmpeg", "mock": True}

    def render(self, *, scene_specs, output_path, preset, on_progress=None, start_at_scene=0):
        if self._ffmpeg:
            return self._ffmpeg.render(
                scene_specs=scene_specs,
                output_path=output_path,
                preset=preset,
                on_progress=on_progress,
                start_at_scene=start_at_scene,
            )
        # Offline fallback: write a small manifest artifact so pipelines complete.
        preview = scene_specs[0].get("image_path") if scene_specs else None
        result = {
            "mode": "mock",
            "preset": preset,
            "scenes": len(scene_specs),
            "preview_image": preview,
            "note": "ffmpeg not installed — real MP4 render required in workers",
        }
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2)
        if on_progress:
            on_progress(1.0)
        return ProviderResult(
            ok=True,
            data={"output": output_path, "mock_render": True, "scenes": len(scene_specs)},
            provider=self.id,
            usage=Usage(quantity=0, unit="render_seconds"),
            meta=result,
        )

    def extract_frame(self, video_path: str, out_path: str, at_seconds: float = 1.0) -> bool:
        if self._ffmpeg:
            return self._ffmpeg.extract_frame(video_path, out_path, at_seconds)
        return False
