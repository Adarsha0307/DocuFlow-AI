import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from app.core.config import get_settings
from app.providers.base import NotificationProvider, ProviderHealth, ProviderResult, Usage


class EmailNotificationProvider(NotificationProvider):
    """SMTP-backed email notifications. Unconfigured => graceful degradation."""

    id = "smtp"
    display_name = "Email (SMTP)"
    rate_limit_per_minute = 60

    def __init__(self) -> None:
        s = get_settings()
        self.host = getattr(s, "smtp_host", "") or ""
        self.port = int(getattr(s, "smtp_port", 587) or 587)
        self.username = getattr(s, "smtp_username", "") or ""
        self.password = getattr(s, "smtp_password", "") or ""
        self.from_addr = getattr(s, "smtp_from", "") or ""

    def check_health(self) -> ProviderHealth:
        if not (self.host and self.from_addr):
            return ProviderHealth(False, detail="SMTP not configured")
        return ProviderHealth(True, latency_ms=0)

    def send(self, *, to, subject, body):
        if not (self.host and self.from_addr):
            return ProviderResult(False, error="SMTP not configured", provider=self.id)
        msg = MIMEMultipart("alternative")
        msg["From"] = self.from_addr
        msg["To"] = to
        msg["Subject"] = subject
        msg.attach(MIMEText(body, "plain"))
        try:
            with smtplib.SMTP(self.host, self.port, timeout=10) as server:
                if self.username:
                    server.starttls()
                    server.login(self.username, self.password)
                server.send_message(msg)
            return ProviderResult(
                ok=True,
                data={"message_id": f"<{to}>", "to": to},
                provider=self.id,
                usage=Usage(quantity=1, unit="emails"),
            )
        except Exception as exc:
            return ProviderResult(False, error=str(exc), provider=self.id)
