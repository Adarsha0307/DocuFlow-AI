from app.providers.base import NotificationProvider, ProviderHealth, ProviderResult, Usage


class MockNotificationProvider(NotificationProvider):
    id = "mock"
    display_name = "Mock Notifications"
    rate_limit_per_minute = 5000

    def check_health(self) -> ProviderHealth:
        return ProviderHealth(True, latency_ms=1)

    def send(self, *, to, subject, body):
        return ProviderResult(
            ok=True,
            data={"delivered": True, "to": to, "subject": subject[:80]},
            provider=self.id,
            usage=Usage(quantity=1, unit="notifications"),
            meta={"mock": True},
        )
