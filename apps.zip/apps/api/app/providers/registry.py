import logging
from collections import defaultdict
from typing import TypeVar

from app.providers.base import (
    BaseProvider,
    ProviderHealth,
)

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseProvider)

DEFAULT_FALLBACKS: dict[str, list[str]] = {
    "llm": ["openai"],
    "embeddings": ["openai"],
    "tts": ["mock"],
    "stt": ["mock"],
    "image": ["mock"],
    "video": ["mock"],
    "thumbnail": ["openai"],
    "seo": ["openai"],
    "upload": ["mock"],
    "notify": ["mock"],
    "media": ["ffmpeg"],
}


class ProviderRegistry:
    """Registry of provider implementations + capability matrix + fallbacks."""

    def __init__(self) -> None:
        self._providers: dict[str, dict[str, BaseProvider]] = defaultdict(dict)
        self._health_cache: dict[str, ProviderHealth] = {}
        self._fallbacks: dict[str, list[str]] = dict(DEFAULT_FALLBACKS)
        self._register_builtins()

    def _register_builtins(self) -> None:
        # Imported lazily to keep module import cheap and avoid hard failures.
        from app.providers.embeddings.mock import MockEmbeddingsProvider
        from app.providers.embeddings.openai import OpenAIEmbeddingsProvider
        from app.providers.images.flux import FluxImageProvider
        from app.providers.images.mock import MockImageProvider
        from app.providers.images.stability import StabilityImageProvider
        from app.providers.llm.anthropic import AnthropicProvider
        from app.providers.llm.gemini import GeminiProvider
        from app.providers.llm.groq import GroqProvider
        from app.providers.llm.mock import MockLLMProvider
        from app.providers.llm.openai import OpenAIProvider
        from app.providers.media.ffmpeg import FFmpegMediaProvider
        from app.providers.media.mock import MockMediaProvider
        from app.providers.notifications.email import EmailNotificationProvider
        from app.providers.notifications.mock import MockNotificationProvider
        from app.providers.stt.mock import MockSTTProvider
        from app.providers.stt.openai import OpenAISTTProvider
        from app.providers.tts.cartesia import CartesiaTTSProvider
        from app.providers.tts.elevenlabs import ElevenLabsTTSProvider
        from app.providers.tts.mock import MockTTSProvider
        from app.providers.upload.mock import MockUploadProvider
        from app.providers.upload.youtube import YouTubeUploadProvider
        from app.providers.video.mock import MockVideoProvider
        from app.providers.video.runway import RunwayVideoProvider

        for cls in [
            OpenAIProvider,
            GeminiProvider,
            AnthropicProvider,
            GroqProvider,
            MockLLMProvider,
            OpenAIEmbeddingsProvider,
            MockEmbeddingsProvider,
            ElevenLabsTTSProvider,
            CartesiaTTSProvider,
            MockTTSProvider,
            OpenAISTTProvider,
            MockSTTProvider,
            StabilityImageProvider,
            FluxImageProvider,
            MockImageProvider,
            RunwayVideoProvider,
            MockVideoProvider,
            YouTubeUploadProvider,
            MockUploadProvider,
            EmailNotificationProvider,
            MockNotificationProvider,
            FFmpegMediaProvider,
            MockMediaProvider,
        ]:
            self.register(cls())

    def register(self, provider: BaseProvider) -> None:
        self._providers[provider.capability][provider.id] = provider

    def list(self, capability: str | None = None) -> list[dict]:
        items = []
        for cap, by_id in self._providers.items():
            if capability and cap != capability:
                continue
            for pid, inst in by_id.items():
                items.append(
                    {
                        "id": pid,
                        "name": inst.display_name,
                        "capability": cap,
                        "rate_limit_per_minute": inst.rate_limit_per_minute,
                    }
                )
        return items

    def available(self, capability: str) -> list[str]:
        if capability not in self._providers:
            return []
        return sorted(self._providers[capability].keys())

    def resolve(
        self,
        capability: str,
        *,
        preferred: str | None = None,
        org_defaults: dict | None = None,
        fallback_ok: bool = True,
    ) -> BaseProvider:
        """Resolve the best provider for a capability with org-level overrides.

        org_defaults expected shape: {"llm": "openai", "image": "flux", ...}
        """
        pick = preferred or (org_defaults or {}).get(capability)
        pool = self._providers.get(capability, {})
        if pick and pick in pool:
            return pool[pick]
        if pool:
            return next(iter(pool.values()))
        # fallback chain
        if fallback_ok:
            for fb in self._fallbacks.get(capability, []):
                if fb in pool:
                    return pool[fb]
        raise ValueError(f"no provider available for capability {capability}")

    def get(self, capability: str, provider_id: str) -> BaseProvider:
        return self._providers[capability][provider_id]

    def check_health(self, capability: str | None = None) -> dict:
        result = {}
        for cap, by_id in self._providers.items():
            if capability and cap != capability:
                continue
            for pid, inst in by_id.items():
                try:
                    health = inst.check_health()
                except Exception as exc:
                    health = ProviderHealth(False, detail=str(exc))
                result.setdefault(cap, {})[pid] = health.as_dict()
        return result

    def set_fallbacks(self, capability: str, providers: list[str]) -> None:
        self._fallbacks[capability] = providers


registry = ProviderRegistry()


def get_registry() -> ProviderRegistry:
    return registry
