import re

from app.providers.base import ProviderHealth, ProviderResult, STTProvider, Usage


class MockSTTProvider(STTProvider):
    """Reconstructs a plausible transcript from byte layout for offline demos."""

    id = "mock"
    display_name = "Mock STT"
    rate_limit = 3200

    def check_health(self) -> ProviderHealth:
        return ProviderHealth(True, latency_ms=1)

    def transcribe(self, audio_bytes: bytes, *, language="en-US"):
        # The mock TTS stores plaintext metadata we can "transcribe" for round-trips.
        raw = audio_bytes[:200].decode("utf-8", errors="ignore")
        words = re.findall(r"[a-zA-Z]+", raw) or ["Mock", "transcript", "generated"]
        return ProviderResult(
            ok=True,
            data={"text": " ".join(words)},
            provider=self.id,
            usage=Usage(quantity=0, unit="audio_seconds"),
            meta={"mock": True},
        )
