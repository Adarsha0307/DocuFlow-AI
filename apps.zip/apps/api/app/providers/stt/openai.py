import httpx

from app.core.config import get_settings
from app.providers.base import ProviderHealth, ProviderResult, STTProvider, Usage


class OpenAISTTProvider(STTProvider):
    id = "openai"
    display_name = "OpenAI Whisper"
    rate_limit_per_minute = 120

    def __init__(self) -> None:
        self.api_key = get_settings().openai_api_key or None  # type: ignore[attr-defined]

    def check_health(self) -> ProviderHealth:
        if not self.api_key:
            return ProviderHealth(False, detail="OPENAI_API_KEY not configured")
        return ProviderHealth(True, latency_ms=0)

    def transcribe(self, audio_bytes: bytes, *, language="en-US"):
        if not self.api_key:
            return ProviderResult(False, error="OPENAI_API_KEY not configured", provider=self.id)
        try:
            r = httpx.post(
                "https://api.openai.com/v1/audio/transcriptions",
                headers={"Authorization": f"Bearer {self.api_key}"},
                data={"model": "whisper-1", "language": language.split("-")[0]},
                files={"file": ("voice.wav", audio_bytes, "audio/wav")},
                timeout=120,
            )
            r.raise_for_status()
            text = r.json().get("text", "")
            return ProviderResult(
                ok=True,
                data={"text": text},
                provider=self.id,
                usage=Usage(quantity=0, unit="audio_seconds", meta={"text_len": len(text)}),
            )
        except httpx.HTTPError as exc:
            return ProviderResult(False, error=str(exc), provider=self.id)
