import httpx

from app.core.config import get_settings
from app.providers.base import ProviderHealth, ProviderResult, TTSProvider, Usage


class CartesiaTTSProvider(TTSProvider):
    id = "cartesia"
    display_name = "Cartesia"
    rate_limit_per_minute = 150

    def __init__(self) -> None:
        self.api_key = get_settings().cartesia_api_key or None  # type: ignore[attr-defined]
        self.base_url = "https://api.cartesia.ai"

    def check_health(self) -> ProviderHealth:
        if not self.api_key:
            return ProviderHealth(False, detail="CARTESIA_API_KEY not configured")
        return ProviderHealth(True, latency_ms=0)

    def synthesize(self, text, *, voice, language="en-US"):
        if not self.api_key:
            return ProviderResult(False, error="CARTESIA_API_KEY not configured", provider=self.id)
        try:
            r = httpx.post(
                f"{self.base_url}/v1/tts",
                headers={"X-API-Key": self.api_key},
                json={
                    "model_id": "sonic-english",
                    "transcript": text,
                    "voice": {"mode": "id", "id": voice},
                    "output_format": {"container": "mp3", "sample_rate": 44100},
                },
                timeout=120,
            )
            r.raise_for_status()
            return ProviderResult(
                ok=True,
                data={"bytes": r.content, "mime_type": "audio/mpeg", "chars": len(text)},
                provider=self.id,
                usage=Usage(quantity=len(text), unit="chars"),
                meta={"voice": voice},
            )
        except httpx.HTTPError as exc:
            return ProviderResult(False, error=str(exc), provider=self.id)
