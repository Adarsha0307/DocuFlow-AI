import httpx

from app.core.config import get_settings
from app.providers.base import ProviderHealth, ProviderResult, TTSProvider, Usage


class ElevenLabsTTSProvider(TTSProvider):
    id = "elevenlabs"
    display_name = "ElevenLabs"
    rate_limit_per_minute = 120

    def __init__(self) -> None:
        self.api_key = get_settings().elevenlabs_api_key or None  # type: ignore[attr-defined]
        self.base_url = "https://api.elevenlabs.io/v1"

    def check_health(self) -> ProviderHealth:
        if not self.api_key:
            return ProviderHealth(False, detail="ELEVENLABS_API_KEY not configured")
        return ProviderHealth(True, latency_ms=0)

    def synthesize(self, text, *, voice, language="en-US"):
        if not self.api_key:
            return ProviderResult(False, error="ELEVENLABS_API_KEY not configured", provider=self.id)
        url = f"{self.base_url}/text-to-speech/{voice}"
        payload = {
            "text": text,
            "model_id": "eleven_multilingual_v2",
            "voice_settings": {"stability": 0.5, "similarity_boost": 0.7},
        }
        try:
            r = httpx.post(
                url,
                headers={"xi-api-key": self.api_key, "Content-Type": "application/json"},
                json=payload,
                timeout=120,
            )
            r.raise_for_status()
            return ProviderResult(
                ok=True,
                data={"bytes": r.content, "mime_type": "audio/mpeg", "chars": len(text)},
                provider=self.id,
                usage=Usage(quantity=len(text), unit="chars"),
                meta={"voice": voice},
            )
        except httpx.HTTPError as exc:
            return ProviderResult(False, error=str(exc), provider=self.id)
