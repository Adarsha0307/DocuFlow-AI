import io
import struct
import wave

from app.providers.base import ProviderHealth, ProviderResult, TTSProvider, Usage


class MockTTSProvider(TTSProvider):
    """Generates an offline WAV track (tone + silence) so the pipeline runs without a TTS key."""

    id = "mock"
    display_name = "Mock TTS"
    rate_limit_per_minute = 3600

    def check_health(self) -> ProviderHealth:
        return ProviderHealth(True, latency_ms=1)

    def synthesize(self, text, *, voice, language="en-US"):
        duration = max(0.2, len(text) * 0.035)
        wav = render_silence_wav(duration)
        return ProviderResult(
            ok=True,
            data={"bytes": wav, "mime_type": "audio/wav", "chars": len(text), "duration": duration},
            provider=self.id,
            usage=Usage(quantity=len(text), unit="chars"),
            meta={"voice": voice, "mock": True},
        )


def render_silence_wav(duration_seconds: float, sample_rate: int = 22050, freq: float = 0.0) -> bytes:
    n = max(int(duration_seconds * sample_rate), 10)
    amps = []
    for i in range(n):
        if freq and i % (sample_rate // int(freq)) == 0:
            amps.append(9000)
        else:
            amps.append(0)
    payload = struct.pack(f"<{n}h", *amps) if n else b""
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sample_rate)
        w.writeframes(payload)
    return buf.getvalue()
