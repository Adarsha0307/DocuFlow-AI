import uuid

from app.providers.base import ProviderHealth, ProviderResult, UploadProvider, Usage


class MockUploadProvider(UploadProvider):
    """Full resumable-upload lifecycle simulation with byte accounting."""

    id = "mock"
    display_name = "Mock YouTube"
    rate_limit_per_minute = 300

    def __init__(self) -> None:
        self._sessions: dict[str, dict] = {}

    def check_health(self) -> ProviderHealth:
        return ProviderHealth(True, latency_ms=1)

    def start_upload(self, *, title, description, tags=None, visibility="private", publish_at=None,
                     meta=None):
        session_id = str(uuid.uuid4())
        self._sessions[session_id] = {
            "title": title,
            "bytes": 0,
            "expected": int((meta or {}).get("content_length", 0)),
            "visibility": visibility,
            "publish_at": publish_at,
            "chunks": 0,
        }
        return ProviderResult(
            ok=True,
            data={"session_id": session_id, "upload_url": f"mock://resumable/{session_id}"},
            provider=self.id,
            usage=Usage(quantity=0, unit="uploads"),
            meta={"attempt": (meta or {}).get("attempt", 1)},
        )

    def upload_chunk(self, session_id, data, offset, meta=None):
        session = self._sessions.get(session_id)
        if session is None:
            return ProviderResult(False, error="unknown mock session", provider=self.id)
        session["bytes"] += len(data)
        session["chunks"] += 1
        return ProviderResult(
            ok=True,
            data={"bytes": len(data), "received": session["bytes"], "chunks": session["chunks"]},
            provider=self.id,
        )

    def finish_upload(self, session_id, *, thumbnail_bytes=None, meta=None):
        session = self._sessions.get(session_id)
        if session is None:
            return ProviderResult(False, error="unknown mock session", provider=self.id)
        if session["expected"] and session["bytes"] < session["expected"]:
            return ProviderResult(
                False,
                error=f"incomplete upload {session['bytes']}/{session['expected']}",
                provider=self.id,
            )
        video_id = f"mockvideo_{uuid.uuid4().hex[:10]}"
        return ProviderResult(
            ok=True,
            data={
                "external_video_id": video_id,
                "title": session["title"],
                "thumbnail_uploaded": bool(thumbnail_bytes),
                "bytes": session["bytes"],
                "chunks": session["chunks"],
            },
            provider=self.id,
            usage=Usage(quantity=1, unit="uploads"),
            meta={"mock_video_id": video_id},
        )

    def simulate_failure(self, session_id: str) -> None:
        if session_id in self._sessions:
            self._sessions[session_id]["expected"] = 10**12  # never "complete"
