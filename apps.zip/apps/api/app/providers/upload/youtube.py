import logging

import httpx

from app.core.config import get_settings
from app.providers.base import ProviderHealth, ProviderResult, UploadProvider, Usage

logger = logging.getLogger(__name__)


class YouTubeUploadProvider(UploadProvider):
    """Resumable YouTube Data API upload adapter.

    OAuth tokens are stored per-channel via the token store (encrypted at rest);
    this adapter receives them through `meta` on each call. Without configured
    OAuth credentials the provider reports unhealthy and fails gracefully —
    the MockUploadProvider covers offline development.
    """

    id = "youtube"
    display_name = "YouTube"
    rate_limit_per_minute = 10
    API_BASE = "https://www.googleapis.com/youtube/v3"

    def __init__(self) -> None:
        s = get_settings()
        self.client_id = s.youtube_oauth_client_id
        self.client_secret = s.youtube_oauth_client_secret
        self.redirect_uri = s.youtube_oauth_redirect_uri

    def check_health(self) -> ProviderHealth:
        if not (self.client_id and self.client_secret):
            return ProviderHealth(False, detail="YouTube OAuth credentials not configured")
        return ProviderHealth(True, latency_ms=0)

    def _access_token(self, meta: dict | None) -> str | None:
        token = (meta or {}).get("access_token")
        if token:
            return token
        return None

    def start_upload(self, *, title, description, tags=None, visibility="private", publish_at=None,
                     meta=None):
        token = self._access_token(meta)
        if not token:
            return ProviderResult(False, error="No YouTube access token", provider=self.id)
        snippet: dict = {"title": title, "description": description or ""}
        if tags:
            snippet["tags"] = tags[:500]
        body = {"snippet": snippet, "status": {"privacyStatus": visibility}}
        headers = {
            "Authorization": f"Bearer {token}",
            "X-Upload-Content-Type": "video/mp4",
            "X-Upload-Content-Length": str((meta or {}).get("content_length", 0)),
        }
        try:
            r = httpx.post(
                f"{self.API_BASE}/videos?uploadType=resumable&part=snippet,status",
                headers=headers,
                json=body,
                timeout=30,
            )
            r.raise_for_status()
            upload_url = r.headers.get("Location", "")
            return ProviderResult(
                ok=bool(upload_url),
                data={"session_id": upload_url, "upload_url": upload_url},
                provider=self.id,
                meta={"attempt": (meta or {}).get("attempt", 1)},
            )
        except Exception as exc:
            return ProviderResult(False, error=str(exc), provider=self.id)

    def upload_chunk(self, session_id, data, offset, meta=None):
        token = self._access_token(meta)
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/octet-stream",
            "Content-Length": str(len(data)),
            "Content-Range": f"bytes {offset}-{offset + len(data) - 1}/{meta.get('total', '*') if meta else '*'}",
        }
        try:
            r = httpx.put(session_id, headers=headers, content=data, timeout=300)
            if r.status_code in (200, 201, 308):
                return ProviderResult(
                    ok=True,
                    data={"bytes": len(data), "range": r.headers.get("Range")},
                    provider=self.id,
                )
            return ProviderResult(False, error=f"YouTube chunk status {r.status_code}: {r.text[:200]}", provider=self.id)
        except Exception as exc:
            return ProviderResult(False, error=str(exc), provider=self.id)

    def finish_upload(self, session_id, *, thumbnail_bytes=None, meta=None):
        token = self._access_token(meta)
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/octet-stream",
            "Content-Length": "0",
        }
        try:
            r = httpx.put(session_id, headers=headers, content=b"", timeout=60)
            r.raise_for_status()
            video_id = r.json().get("id", "")
            if thumbnail_bytes and video_id:
                self._set_thumbnail(token, video_id, thumbnail_bytes)
            return ProviderResult(
                ok=True,
                data={"external_video_id": video_id},
                provider=self.id,
                usage=Usage(quantity=1, unit="uploads"),
            )
        except Exception as exc:
            return ProviderResult(False, error=str(exc), provider=self.id)

    def _set_thumbnail(self, token: str, video_id: str, thumbnail_bytes: bytes) -> None:
        try:
            httpx.post(
                f"{self.API_BASE}/thumbnails/set?videoId={video_id}&uploadType=media",
                headers={"Authorization": f"Bearer {token}", "Content-Type": "image/png"},
                content=thumbnail_bytes,
                timeout=60,
            )
        except Exception:  # pragma: no cover
            logger.warning("thumbnail set failed for video %s", video_id)
