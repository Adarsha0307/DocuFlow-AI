from app.providers.base import ProviderHealth, ProviderResult, Usage, VideoProvider


class MockVideoProvider(VideoProvider):
    id = "mock"
    display_name = "Mock Video"
    rate_limit_per_minute = 1200

    def check_health(self) -> ProviderHealth:
        return ProviderHealth(True, latency_ms=1)

    def generate(self, prompt, *, duration_seconds=5):
        return ProviderResult(
            ok=True,
            data={"task_id": "mock-task", "note": "placeholder video payload"},
            provider=self.id,
            usage=Usage(quantity=duration_seconds, unit="video_seconds"),
            meta={"mock": True, "prompt": prompt[:120]},
        )
