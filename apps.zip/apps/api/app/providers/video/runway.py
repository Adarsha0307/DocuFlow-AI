import httpx

from app.core.config import get_settings
from app.providers.base import ProviderHealth, ProviderResult, Usage, VideoProvider


class RunwayVideoProvider(VideoProvider):
    id = "runway"
    display_name = "Runway"
    rate_limit_per_minute = 30

    def __init__(self) -> None:
        self.api_key = get_settings().runway_api_key or None  # type: ignore[attr-defined]

    def check_health(self) -> ProviderHealth:
        if not self.api_key:
            return ProviderHealth(False, detail="RUNWAY_API_KEY not configured")
        return ProviderHealth(True, latency_ms=0)

    def generate(self, prompt, *, duration_seconds=5):
        if not self.api_key:
            return ProviderResult(False, error="RUNWAY_API_KEY not configured", provider=self.id)
        try:
            r = httpx.post(
                "https://api.dev.runwayml.com/v1/text_to_video",
                headers={"Authorization": f"Bearer {self.api_key}"},
                json={
                    "model": "gen3a_turbo",
                    "promptText": prompt,
                    "ratio": "1280:720",
                    "duration": duration_seconds,
                },
                timeout=300,
            )
            r.raise_for_status()
            task = r.json()
            return ProviderResult(
                ok=True,
                data={"task_id": task.get("id")},
                provider=self.id,
                usage=Usage(quantity=duration_seconds, unit="video_seconds"),
                meta={"model": "runway-gen3"},
            )
        except httpx.HTTPError as exc:
            return ProviderResult(False, error=str(exc), provider=self.id)
