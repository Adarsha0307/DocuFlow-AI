﻿"""Generic repository: thin, typed query objects over SQLAlchemy sessions."""

import uuid
from typing import TypeVar

from sqlalchemy import Select, delete, func, select
from sqlalchemy.orm import Session

from app.core.errors import NotFoundError
from app.db.base import Base

T = TypeVar("T", bound=Base)


class Repo[T: Base]:
    model: type[T]

    def __init__(self, db: Session):
        self.db = db

    # --- reads -------------------------------------------------------------
    def get(self, entity_id: uuid.UUID) -> T:
        obj = self.db.get(self.model, entity_id)
        if obj is None:
            raise NotFoundError(f"{self.model.__name__} {entity_id} not found")
        return obj

    def get_or_none(self, entity_id: uuid.UUID) -> T | None:
        return self.db.get(self.model, entity_id)

    def _filter(self, **kwargs) -> Select:
        stmt = select(self.model)
        for key, value in kwargs.items():
            if value is not None:
                col = getattr(self.model, key)
                stmt = stmt.where(col == value)
        return stmt

    def list(self, *, page: int = 1, page_size: int = 20, sort_field: str | None = None,
            sort_dir: str = "desc", **filters) -> tuple[list[T], int]:
        stmt = self._filter(**filters)
        total = self.db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
        if sort_field:
            col = getattr(self.model, sort_field, None)
            if col is not None:
                stmt = stmt.order_by(col.desc() if sort_dir == "desc" else col.asc())
        rows = self.db.execute(stmt.offset((page - 1) * page_size).limit(page_size)).scalars().all()
        return list(rows), int(total)

    # --- writes ------------------------------------------------------------
    def add(self, obj: T, flush: bool = False) -> T:
        self.db.add(obj)
        if obj.id is None and hasattr(obj, "id"):
            obj.id = uuid.uuid4()
        if flush:
            self.db.flush()
        return obj

    def save(self, obj: T) -> T:
        self.db.add(obj)
        return obj

    def flush(self) -> None:
        self.db.flush()

    def delete(self, entity_id: uuid.UUID) -> None:
        self.db.execute(delete(self.model).where(self.model.id == entity_id))  # type: ignore[attr-defined]

    def commit(self) -> None:
        self.db.commit()
