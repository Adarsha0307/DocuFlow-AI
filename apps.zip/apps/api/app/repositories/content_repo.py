import uuid

from sqlalchemy import select

from app.models import (
    Channel,
    CharacterProfile,
    Project,
    Prompt,
    Scene,
    SceneVersion,
    Script,
    ScriptVersion,
    Thumbnail,
    UploadJob,
    Voiceover,
)
from app.repositories.base import Repo


class ProjectRepo(Repo[Project]):
    model = Project

    def by_org(self, org_id: uuid.UUID) -> list[Project]:
        return list(
            self.db.execute(
                select(Project)
                .where(Project.organization_id == org_id, Project.deleted_at.is_(None))
                .order_by(Project.created_at.desc())
            ).scalars()
        )

    def totals(self, org_id: uuid.UUID) -> dict:
        projects = self.by_org(org_id)
        return {
            "count": len(projects),
            "in_progress": sum(1 for p in projects if p.status == "in_progress"),
            "completed": sum(1 for p in projects if p.status == "completed"),
        }


class ChannelRepo(Repo[Channel]):
    model = Channel


class ScriptRepo(Repo[Script]):
    model = Script

    def latest_for_project(self, project_id: uuid.UUID) -> Script | None:
        return self.db.scalar(
            select(Script)
            .where(Script.project_id == project_id)
            .order_by(Script.created_at.desc())
        )


class ScriptVersionRepo(Repo[ScriptVersion]):
    model = ScriptVersion


class SceneRepo(Repo[Scene]):
    model = Scene

    def for_project(self, project_id: uuid.UUID) -> list[Scene]:
        return list(
            self.db.execute(
                select(Scene)
                .where(Scene.project_id == project_id)
                .order_by(Scene.scene_number.asc())
            ).scalars()
        )


class SceneVersionRepo(Repo[SceneVersion]):
    model = SceneVersion


class CharacterRepo(Repo[CharacterProfile]):
    model = CharacterProfile


class PromptRepo(Repo[Prompt]):
    model = Prompt


class VoiceoverRepo(Repo[Voiceover]):
    model = Voiceover


class ThumbnailRepo(Repo[Thumbnail]):
    model = Thumbnail


class UploadJobRepo(Repo[UploadJob]):
    model = UploadJob
