import uuid

from sqlalchemy import func, or_, select

from app.models.identity import Invitation, Membership, Organization, User
from app.repositories.base import Repo


class UserRepo(Repo[User]):
    model = User

    def by_email(self, email: str) -> User | None:
        return self.db.scalar(select(User).where(User.email == email.lower().strip()))

    def get_id(self, user_id: uuid.UUID) -> User | None:
        return self.db.get(User, user_id)


class OrganizationRepo(Repo[Organization]):
    model = Organization

    def by_slug(self, slug: str) -> Organization | None:
        return self.db.scalar(select(Organization).where(Organization.slug == slug))

    def ensure_unique_slug(self, base: str) -> str:
        slug = base.strip().lower().replace(" ", "-")[:60] or "studio"
        candidate, i = slug, 1
        while self.by_slug(candidate):
            i += 1
            candidate = f"{slug}-{i}"
        return candidate


class MembershipRepo(Repo[Membership]):
    model = Membership

    def get_membership(self, org_id: uuid.UUID, user_id: uuid.UUID) -> Membership | None:
        return self.db.scalar(
            select(Membership).where(
                Membership.organization_id == org_id,
                Membership.user_id == user_id,
                Membership.status == "active",
            )
        )

    def member_count(self, org_id: uuid.UUID) -> int:
        return self.db.scalar(
            select(func.count()).where(Membership.organization_id == org_id)
        ) or 0

    def list_members(self, org_id: uuid.UUID) -> list[dict]:
        rows = self.db.execute(
            select(Membership, User)
            .join(User, User.id == Membership.user_id)
            .where(Membership.organization_id == org_id)
        ).all()
        return [
            {
                "id": m.id,
                "organization_id": m.organization_id,
                "user_id": u.id,
                "email": u.email,
                "name": u.name,
                "role": m.role,
                "status": m.status,
                "avatar_url": u.avatar_url,
                "created_at": m.created_at,
            }
            for m, u in rows
        ]

    def my_orgs(self, user_id: uuid.UUID) -> list[Organization]:
        rows = self.db.execute(
            select(Organization)
            .join(Membership, Membership.organization_id == Organization.id)
            .where(
                Membership.user_id == user_id,
                Membership.status == "active",
            )
            .order_by(Organization.created_at.desc())
        ).scalars().all()
        return list(rows)


class InvitationRepo(Repo[Invitation]):
    model = Invitation

    def find_pending_by_email(self, org_id: uuid.UUID, email: str) -> Invitation | None:
        return self.db.scalar(
            select(Invitation).where(
                Invitation.organization_id == org_id,
                or_(Invitation.email == email, Invitation.email == email.lower()),
                Invitation.status == "pending",
            )
        )

    def by_token_hash(self, token_hash: str) -> Invitation | None:
        return self.db.scalar(
            select(Invitation).where(Invitation.token_hash == token_hash)
        )
