import uuid

from sqlalchemy import func, select

from app.models import (
    Approval,
    AuditLog,
    CostRecord,
    QuotaCounter,
    UsageLog,
    WorkflowDefinition,
    WorkflowEvent,
    WorkflowRun,
    WorkflowStep,
)
from app.repositories.base import Repo


class WorkflowDefinitionRepo(Repo[WorkflowDefinition]):
    model = WorkflowDefinition

    def by_slug(self, slug: str) -> WorkflowDefinition | None:
        return self.db.scalar(
            select(WorkflowDefinition).where(WorkflowDefinition.slug == slug)
        )

    def system_locked(self, slug: str) -> WorkflowDefinition | None:
        return self.db.scalar(
            select(WorkflowDefinition).where(
                WorkflowDefinition.slug == slug,
                WorkflowDefinition.is_system.is_(True),
            )
        )

    def for_org(self, org_id: uuid.UUID) -> list[WorkflowDefinition]:
        rows = self.db.execute(
            select(WorkflowDefinition).where(
                (WorkflowDefinition.organization_id == org_id)
                | (WorkflowDefinition.is_system.is_(True))
            ).order_by(WorkflowDefinition.created_at.desc())
        ).scalars().all()
        return list(rows)


class WorkflowRunRepo(Repo[WorkflowRun]):
    model = WorkflowRun

    def for_project(self, project_id: uuid.UUID) -> list[WorkflowRun]:
        return list(
            self.db.execute(
                select(WorkflowRun)
                .where(WorkflowRun.project_id == project_id)
                .order_by(WorkflowRun.created_at.desc())
            ).scalars()
        )

    def latest_for_project(self, project_id: uuid.UUID) -> WorkflowRun | None:
        return self.db.scalar(
            select(WorkflowRun)
            .where(WorkflowRun.project_id == project_id)
            .order_by(WorkflowRun.created_at.desc())
            .limit(1)
        )


class WorkflowStepRepo(Repo[WorkflowStep]):
    model = WorkflowStep

    def for_run(self, run_id: uuid.UUID) -> list[WorkflowStep]:
        return list(
            self.db.execute(
                select(WorkflowStep)
                .where(WorkflowStep.run_id == run_id)
                .order_by(WorkflowStep.created_at.asc())
            ).scalars()
        )

    def by_stage(self, run_id: uuid.UUID, stage: str) -> WorkflowStep | None:
        return self.db.scalar(
            select(WorkflowStep).where(
                WorkflowStep.run_id == run_id, WorkflowStep.stage == stage
            )
        )


class WorkflowEventRepo(Repo[WorkflowEvent]):
    model = WorkflowEvent


class ApprovalRepo(Repo[Approval]):
    model = Approval

    def pending_for_org(self, org_id: uuid.UUID, limit: int = 20) -> list[Approval]:
        return list(
            self.db.execute(
                select(Approval)
                .where(Approval.organization_id == org_id, Approval.state == "pending")
                .order_by(Approval.created_at.asc())
                .limit(limit)
            ).scalars()
        )

    def for_project(self, project_id: uuid.UUID) -> list[Approval]:
        return list(
            self.db.execute(
                select(Approval)
                .where(Approval.project_id == project_id)
                .order_by(Approval.created_at.desc())
            ).scalars()
        )


class CostRecordRepo(Repo[CostRecord]):
    model = CostRecord

    def totals_for_org(self, org_id: uuid.UUID) -> dict:
        total = self.db.scalar(
            select(func.coalesce(func.sum(CostRecord.amount_usd), 0.0)).where(
                CostRecord.organization_id == org_id
            )
        ) or 0.0
        return {"total_usd": round(float(total), 4)}

    def breakdown(self, org_id: uuid.UUID, project_id: uuid.UUID | None = None) -> dict:
        where = [CostRecord.organization_id == org_id]
        if project_id:
            where.append(CostRecord.project_id == project_id)
        q = select(CostRecord.category, CostRecord.provider, CostRecord.amount_usd).where(*where)
        by_category: dict[str, float] = {}
        by_provider: dict[str, float] = {}
        for cat, prov, amt in self.db.execute(q):
            by_category[str(cat)] = by_category.get(str(cat), 0.0) + float(amt)
            by_provider[str(prov)] = by_provider.get(str(prov), 0.0) + float(amt)
        return {
            "total": round(sum(by_category.values()), 2),
            "by_category": {k: round(v, 2) for k, v in by_category.items()},
            "by_provider": {k: round(v, 2) for k, v in by_provider.items()},
        }


class UsageRepo(Repo[UsageLog]):
    model = UsageLog


class QuotaRepo(Repo[QuotaCounter]):
    model = QuotaCounter

    def get(self, org_id: uuid.UUID, metric: str, period: str) -> QuotaCounter | None:
        return self.db.scalar(
            select(QuotaCounter).where(
                QuotaCounter.organization_id == org_id,
                QuotaCounter.metric == metric,
                QuotaCounter.period == period,
            )
        )


class AuditRepo(Repo[AuditLog]):
    model = AuditLog

    def for_org(self, org_id: uuid.UUID, limit: int = 50) -> list[AuditLog]:
        return list(
            self.db.execute(
                select(AuditLog)
                .where(AuditLog.organization_id == org_id)
                .order_by(AuditLog.created_at.desc())
                .limit(limit)
            ).scalars()
        )
