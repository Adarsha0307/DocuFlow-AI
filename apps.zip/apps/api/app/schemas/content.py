"""Pydantic schemas for project content (scripts, scenes, assets, prompts, media)."""

import uuid
from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict


class ORMModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# --- scripts --------------------------------------------------------------
class ScriptCreate(BaseModel):
    title: str | None = None
    body: str
    language: str = "en-US"


class ScriptRead(ORMModel):
    id: uuid.UUID
    project_id: uuid.UUID
    title: str | None
    body: str
    word_count: int
    language: str
    status: str
    current_version: int
    created_at: Any


class ScriptRevise(BaseModel):
    body: str
    notes: str | None = None


class ScriptVersionRead(ORMModel):
    id: uuid.UUID
    script_id: uuid.UUID
    version: int
    body: str
    change_notes: str | None
    created_at: Any


# --- scenes ---------------------------------------------------------------
class SceneCreate(BaseModel):
    scene_number: int = 1
    title: str
    narration: str
    visual_direction: str | None = None
    duration_seconds: float = 15.0


class SceneRead(ORMModel):
    id: uuid.UUID
    project_id: uuid.UUID
    script_id: uuid.UUID | None
    scene_number: int
    title: str
    narration: str
    visual_direction: str | None
    duration_seconds: float
    status: str
    created_at: Any


class SceneRevise(BaseModel):
    narration: str
    visual_direction: str | None = None


class SceneVersionRead(ORMModel):
    id: uuid.UUID
    scene_id: uuid.UUID
    version: int
    narration: str
    visual_direction: str | None
    created_at: Any


# --- assets / characters -----------------------------------------------------
class AssetCreate(BaseModel):
    kind: str
    name: str
    storage_key: str | None = None
    public_url: str | None = None
    mime_type: str | None = None
    scene_id: uuid.UUID | None = None
    provider: str | None = None
    provenance: dict | None = None


class AssetRead(ORMModel):
    id: uuid.UUID
    kind: str
    name: str
    storage_key: str | None
    public_url: str | None
    mime_type: str | None
    score: int | None
    provider: str | None
    status: str
    created_at: Any


class AssetScoreUpdate(BaseModel):
    score: int


class CharacterCreate(BaseModel):
    name: str
    role: str | None = None
    appearance_prompt: str | None = None


class CharacterRead(ORMModel):
    id: uuid.UUID
    project_id: uuid.UUID
    name: str
    role: str | None
    appearance_prompt: str | None
    voice_preference: str | None
    created_at: Any


# --- prompts --------------------------------------------------------------
class PromptCreate(BaseModel):
    target: str = "image"
    kind: str = "text2image"
    text: str
    scene_id: uuid.UUID | None = None
    negative_prompt: str | None = None


class PromptRead(ORMModel):
    id: uuid.UUID
    project_id: uuid.UUID
    scene_id: uuid.UUID | None
    target: str
    kind: str
    text: str
    negative_prompt: str | None
    created_at: Any


class PromptVersionizeRequest(BaseModel):
    text: str


# --- voice / thumbnails -------------------------------------------------------
class VoiceoverCreate(BaseModel):
    voice: str = "documentary-male"
    language: str = "en-US"
    sample_url: str | None = None
    character_count: int = 0
    duration_seconds: float | None = None


class VoiceoverRead(ORMModel):
    id: uuid.UUID
    project_id: uuid.UUID
    provider: str
    voice: str
    language: str
    sample_url: str | None
    character_count: int
    duration_seconds: float | None
    status: str
    created_at: Any


class ThumbnailCreate(BaseModel):
    title_text: str | None = None
    style: str | None = None
    preview_url: str | None = None
    prompt_id: uuid.UUID | None = None


class ThumbnailRead(ORMModel):
    id: uuid.UUID
    project_id: uuid.UUID
    title_text: str | None
    style: str | None
    preview_url: str | None
    status: str
    created_at: Any


# --- billing ----------------------------------------------------------------
class PlanRead(BaseModel):
    code: str
    name: str
    monthly_price_usd: int
    status: str
    period_end: Any = None
    cancel_at_period_end: bool = False


class CheckoutRequest(BaseModel):
    plan_code: str


class CheckoutResponse(BaseModel):
    provider: str
    checkout_url: str
    plan_code: str
    price_usd: int
    mode: str


class SubscriptionRead(ORMModel):
    id: uuid.UUID
    organization_id: uuid.UUID
    provider: str
    plan_code: str
    status: str
    current_period_start: datetime | None
    current_period_end: datetime | None
    cancel_at_period_end: bool = False


class WebhookEvent(BaseModel):
    type: str
    data: dict | None = None


class WebhookResponse(BaseModel):
    handled: bool
    event: str


# --- uploads ---------------------------------------------------------------
class UploadJobCreate(BaseModel):
    project_id: uuid.UUID
    render_id: uuid.UUID
    channel_id: uuid.UUID | None = None
    title: str | None = None
    description: str | None = None
    tags: list[str] = []
    privacy_status: str = "private"
    publish_at: datetime | None = None


class UploadJobRead(ORMModel):
    id: uuid.UUID
    project_id: uuid.UUID
    channel_id: uuid.UUID | None
    render_id: uuid.UUID | None
    provider: str
    state: str
    title: str | None
    description: str | None
    tags: list
    privacy_status: str
    publish_at: datetime | None
    progress: float
    external_video_id: str | None
    error: str | None
    created_at: Any


# --- RAG ---------------------------------------------------------------------
class RAGIngestRequest(BaseModel):
    texts: list[str]
    kinds: list[str] | None = None


class RAGIngestResponse(BaseModel):
    stored: int


class MemoryCreate(BaseModel):
    memory_type: str
    content: str
    source_step: str | None = None
    provenance: dict | None = None


class MemoryRead(ORMModel):
    id: uuid.UUID
    project_id: uuid.UUID
    memory_type: str
    content: str
    source_step: str | None
    created_at: Any


class RAGSearchRequest(BaseModel):
    query: str
    k: int = 8
    kinds: list[str] | None = None


class RAGContextResponse(BaseModel):
    context: str
