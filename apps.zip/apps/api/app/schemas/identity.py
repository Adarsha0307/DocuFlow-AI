"""Pydantic schemas for identity: auth, organizations, teams, projects."""

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field


class SignupRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    name: str | None = None
    org_name: str | None = None


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class OrganizationRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    slug: str
    plan_code: str | None = None
    member_count: int | None = None
    created_at: datetime | None = None


class UserRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    email: str
    name: str | None
    avatar_url: str | None
    email_verified: bool


class TokenResponse(BaseModel):
    token: str
    user: UserRead
    organization: OrganizationRead | None = None


class SignupResponse(BaseModel):
    token: str
    user: UserRead
    organization: OrganizationRead


class OrgCreate(BaseModel):
    name: str = Field(min_length=1, max_length=160)
    slug: str | None = None


class OrgUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=160)
    slug: str | None = None


class MemberRead(BaseModel):
    user_id: uuid.UUID
    email: str | None = None
    name: str | None = None
    role: str
    status: str


class RoleUpdate(BaseModel):
    role: str = Field(pattern="^(owner|admin|editor|viewer)$")


class InviteCreate(BaseModel):
    email: EmailStr
    role: str = Field(default="editor", pattern="^(admin|editor|viewer)$")


class InviteRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    email: str
    role: str
    status: str
    expires_at: datetime | None
    created_at: datetime | None


class AcceptInvite(BaseModel):
    token: str


class ProjectCreate(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    topic: str = Field(min_length=1, max_length=200)
    niche: str | None = None
    tone: str = "documentary"
    art_style: str = "2d flat"
    duration_seconds: int = 420
    narration_language: str = "en-US"
    voice_type: str = "documentary-male"
    automation_mode: str = "manual"
    channel_id: uuid.UUID | None = None
    auto_approve: bool = False
    auto_publish: bool = False


class ProjectUpdate(BaseModel):
    name: str | None = None
    topic: str | None = None
    niche: str | None = None
    tone: str | None = None
    art_style: str | None = None
    duration_seconds: int | None = None
    narration_language: str | None = None
    voice_type: str | None = None
    automation_mode: str | None = None
    status: str | None = None
    channel_id: uuid.UUID | None = None


class ProjectRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    organization_id: uuid.UUID
    name: str
    topic: str
    niche: str | None
    tone: str
    art_style: str
    automation_mode: str
    status: str
    cover_url: str | None
    created_at: datetime | None
    updated_at: datetime | None


class MeResponse(BaseModel):
    user: UserRead
    organizations: list[OrganizationRead]
