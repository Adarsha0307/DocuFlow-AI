"""Pydantic schemas for the workflow engine API surface."""

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class AutomationModeRead(BaseModel):
    automation_mode: str = Field(default="manual", pattern="^(manual|hybrid|full)$")


class RunCreate(AutomationModeRead):
    definition_id: uuid.UUID | None = None


class StepRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    stage: str
    node_id: str | None
    status: str
    input_json: dict | None
    output_json: dict | None
    retry_count: int
    error: str | None
    started_at: datetime | None
    finished_at: datetime | None
    created_at: datetime | None


class WorkflowStepRead(StepRead):
    run_id: uuid.UUID



class RunRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    project_id: uuid.UUID
    definition_id: uuid.UUID | None
    definitions_version: str
    state: str
    current_stage: str | None
    staged_state_json: dict | None
    total_cost_usd: float
    error: str | None
    started_at: datetime | None
    finished_at: datetime | None
    created_at: datetime | None


class RunDetail(RunRead):
    steps: list[WorkflowStepRead] = []


class ApprovalDecision(BaseModel):
    decision: str = Field(pattern="^(approved|rejected|revision_requested)$")
    comment: str | None = None


class ApprovalRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    project_id: uuid.UUID
    run_id: uuid.UUID | None
    stage: str
    kind: str
    state: str
    requested_by: uuid.UUID | None
    decided_by: uuid.UUID | None
    decided_at: datetime | None
    reason: str | None
    payload_json: dict | None
    created_at: datetime | None
