"""Human-in-the-loop approval lifecycle."""

from datetime import UTC, datetime

from sqlalchemy.orm import Session

from app.core.errors import ConflictError, NotFoundError, ValidationFailedError
from app.core.logging import get_logger
from app.events.bus import DomainEvent, get_bus
from app.models import Approval, ApprovalComment, WorkflowStep
from app.models.enums import ApprovalKind, ApprovalState, StepStatus
from app.repositories.workflow_repo import ApprovalRepo
from app.services.audit_service import AuditService
from app.services.rbac import RBAC

logger = get_logger("docuflow.approvals")

VALID_DECISIONS = {"approved", "rejected", "revision_requested"}

KIND_BY_STAGE = {
    "research_collection": ApprovalKind.RESEARCH,
    "script_review": ApprovalKind.SCRIPT,
    "image_qa": ApprovalKind.IMAGE_SET,
    "voiceover_generation": ApprovalKind.VOICEOVER_SAMPLE,
    "render": ApprovalKind.FINAL_RENDER,
    "thumbnail_generation": ApprovalKind.THUMBNAIL,
    "seo_generation": ApprovalKind.METADATA,
    "upload": ApprovalKind.UPLOAD,
}


class ApprovalService:
    def __init__(self, db: Session):
        self.db = db

    def request(self, *, org_id, project_id, user_id, stage: str, payload: dict | None = None,
                run_id=None, auto_approve: bool = False) -> Approval:
        """Create an approval request; auto-approves when the project runs in full-auto mode."""
        kind = KIND_BY_STAGE.get(stage, ApprovalKind.SCRIPT)
        approval = Approval(
            organization_id=org_id,
            project_id=project_id,
            run_id=run_id,
            stage=stage,
            kind=kind,
            requested_by=user_id,
            state=ApprovalState.AUTO_APPROVED if auto_approve else ApprovalState.PENDING,
            auto_approved=auto_approve,
            payload_json=payload,
        )
        self.db.add(approval)
        self.db.flush()
        if not auto_approve:
            get_bus().publish(
                DomainEvent(
                    "approval_requested",
                    organization_id=str(org_id),
                    project_id=str(project_id),
                    run_id=str(run_id) if run_id else None,
                    payload={"approval_id": str(approval.id), "kind": str(kind)},
                )
            )
        self.db.commit()
        self.db.refresh(approval)
        return approval

    def decide(self, *, approval_id, org_id, user_id, decision: str, comment: str | None = None) -> Approval:
        if decision not in VALID_DECISIONS:
            raise ValidationFailedError(
                f"decision must be one of {sorted(VALID_DECISIONS)}"
            )
        RBAC(self.db, org_id, user_id).require("approve")
        approval = ApprovalRepo(self.db).get(approval_id)
        if approval.organization_id != org_id:
            raise NotFoundError("Approval not found")
        if approval.state != ApprovalState.PENDING:
            raise ConflictError(f"Approval already decided ({approval.state})")

        approval.state = ApprovalState(decision)
        approval.decided_by = user_id
        approval.decided_at = datetime.now(UTC)
        approval.reason = comment

        if decision == "revision_requested":
            approval.revision_of = None  # a fresh request will be created by the workflow
            step = self._step_for(approval)
            if step:
                step.status = StepStatus.AWAITING_APPROVAL
                step.error = comment or "Revision requested"

        self.db.add(ApprovalComment(
            approval_id=approval.id, author_id=user_id,
            body=comment or f"Decision: {decision}",
            meta_json={"decision": decision},
        ))
        AuditService(self.db).record(
            org_id=org_id, actor_id=user_id, action=f"approval.{decision}",
            resource_type="approval", resource_id=str(approval.id),
            after={"kind": str(approval.kind), "comment": comment},
        )
        self.db.commit()
        self.db.refresh(approval)

        get_bus().publish(
            DomainEvent(
                "approval_completed",
                organization_id=str(org_id),
                project_id=str(approval.project_id),
                run_id=str(approval.run_id) if approval.run_id else None,
                payload={
                    "approval_id": str(approval.id),
                    "decision": decision,
                    "stage": approval.stage,
                    "comment": comment,
                },
            )
        )
        return approval

    def add_comment(self, *, approval_id, org_id, user_id, body: str) -> ApprovalComment:
        approval = ApprovalRepo(self.db).get(approval_id)
        if approval.organization_id != org_id:
            raise NotFoundError("Approval not found")
        comment = ApprovalComment(approval_id=approval.id, author_id=user_id, body=body)
        self.db.add(comment)
        self.db.commit()
        self.db.refresh(comment)
        return comment

    def list_pending(self, org_id, limit: int = 30) -> list[Approval]:
        return ApprovalRepo(self.db).pending_for_org(org_id, limit)

    def list_for_project(self, project_id) -> list[Approval]:
        return ApprovalRepo(self.db).for_project(project_id)

    def auto_approve_overdue(self, org_id, older_than_seconds: int = 0) -> list[Approval]:
        """Timeout rule: approvals older than N seconds become auto-approved."""
        pending = self.list_pending(org_id, 500)
        now = datetime.now(UTC)
        resolved = []
        for approval in pending:
            age = (now - approval.created_at).total_seconds()
            if age >= older_than_seconds:
                approval.state = ApprovalState.AUTO_APPROVED
                approval.auto_approved = True
                approval.decided_at = now
                resolved.append(approval)
                get_bus().publish(
                    DomainEvent(
                        "approval_completed",
                        organization_id=str(org_id),
                        project_id=str(approval.project_id),
                        run_id=str(approval.run_id) if approval.run_id else None,
                        payload={"approval_id": str(approval.id), "decision": "auto_approved",
                                 "stage": approval.stage},
                    )
                )
        if resolved:
            self.db.commit()
        return resolved

    @staticmethod
    def _step_for(approval: Approval) -> WorkflowStep | None:
        return None
