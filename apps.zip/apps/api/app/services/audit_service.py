"""Cross-cutting services: audit logging, activity stream, notifications."""

import uuid

from sqlalchemy.orm import Session

from app.models import ActivityLog, AuditLog, Notification
from app.models.enums import NotificationType
from app.repositories.identity_repo import MembershipRepo


class AuditService:
    def __init__(self, db: Session):
        self.db = db

    def record(self, *, org_id: uuid.UUID, actor_id: uuid.UUID | None, action: str,
               resource_type: str, resource_id: str | None = None,
               before: dict | None = None, after: dict | None = None,
               request_id: str | None = None, ip: str | None = None) -> None:
        role = None
        if actor_id:
            membership = MembershipRepo(self.db).get_membership(org_id, actor_id)
            role = membership.role if membership else None
        self.db.add(
            AuditLog(
                organization_id=org_id,
                actor_id=actor_id,
                actor_role=str(role) if role else None,
                action=action,
                resource_type=resource_type,
                resource_id=resource_id,
                before_json=before,
                after_json=after,
                request_id=request_id,
                ip_address=ip,
            )
        )

    def activity(self, *, org_id: uuid.UUID, actor_id: uuid.UUID | None,
                 action: str, entity_type: str | None = None, entity_id: str | None = None,
                 detail: dict | None = None) -> ActivityLog:
        item = ActivityLog(
            organization_id=org_id,
            project_id=(detail or {}).get("project_id"),
            actor_id=actor_id,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            detail_json=detail,
        )
        self.db.add(item)
        return item


class NotificationService:
    def __init__(self, db: Session):
        self.db = db

    def notify(self, *, org_id: uuid.UUID, user_id: uuid.UUID, title: str, body: str | None = None,
               kind: NotificationType = NotificationType.INFO, link: str | None = None) -> Notification:
        n = Notification(
            organization_id=org_id,
            user_id=user_id,
            kind=kind,
            title=title,
            body=body,
            link=link,
        )
        self.db.add(n)
        return n
