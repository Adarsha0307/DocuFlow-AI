"""Authentication service: local credentials, sessions, and API keys."""

import uuid
from datetime import UTC, datetime, timedelta

from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.errors import ConflictError, UnauthorizedError
from app.core.security import (
    decode_access_token,
    encode_access_token,
    generate_secure_token,
    hash_api_key,
    hash_password,
    verify_password,
)
from app.models import ApiKey, Membership, Organization, User
from app.models.enums import Role
from app.repositories.identity_repo import (
    MembershipRepo,
    OrganizationRepo,
    UserRepo,
)


class AuthService:
    def __init__(self, db: Session):
        self.db = db

    def signup(self, *, email: str, password: str, name: str | None = None,
               org_name: str | None = None) -> dict:
        settings = get_settings()
        email = email.strip().lower()
        existing = UserRepo(self.db).by_email(email)
        if existing:
            raise ConflictError("An account with this email already exists")

        user = User(
            email=email,
            password_hash=hash_password(password),
            name=name or email.split("@")[0],
            auth_provider="local",
        )
        self.db.add(user)
        self.db.flush()

        org_repo = OrganizationRepo(self.db)
        org = Organization(
            name=org_name or settings.default_org_name,
            slug=org_repo.ensure_unique_slug(org_name or settings.default_org_name),
            plan_code="starter",
            created_by=user.id,
        )
        self.db.add(org)
        self.db.flush()
        self.db.add(
            Membership(organization_id=org.id, user_id=user.id, role=Role.OWNER, status="active")
        )
        self.db.commit()
        self.db.refresh(user)
        self.db.refresh(org)
        return {"user": user, "organization": org, "token": self._issue_token(user)}

    def login(self, *, email: str, password: str) -> dict:
        user = UserRepo(self.db).by_email(email)
        if not user or not user.password_hash or not verify_password(password, user.password_hash):
            raise UnauthorizedError("Invalid email or password")
        user.last_login_at = datetime.now(UTC)
        self.db.commit()
        return {"user": user, "token": self._issue_token(user)}

    def me(self, user_id: uuid.UUID) -> dict:
        user = UserRepo(self.db).get(user_id)
        memberships = MembershipRepo(self.db).my_orgs(user_id)
        return {"user": user, "organizations": memberships}

    def issue_api_key(self, *, org_id: uuid.UUID, user_id: uuid.UUID, name: str) -> dict:
        raw = f"{get_settings().api_key_prefix}{generate_secure_token(32)}"
        key = ApiKey(
            organization_id=org_id,
            created_by=user_id,
            name=name,
            key_hash=hash_api_key(raw),
            key_prefix=raw[:12],
            scopes=["projects:read", "projects:write"],
        )
        self.db.add(key)
        self.db.commit()
        return {"key": raw, "id": str(key.id), "name": name}

    def resolve_api_key(self, raw_key: str) -> ApiKey | None:
        # Constant-time hash compare over candidate records (fast path: prefix index)
        prefix = raw_key[:12]
        from sqlalchemy import select

        candidates = self.db.execute(
            select(ApiKey).where(ApiKey.key_prefix == prefix, ApiKey.revoked.is_(False))
        ).scalars().all()
        for candidate in candidates:
            if hash_api_key(raw_key) == candidate.key_hash:
                candidate.last_used_at = datetime.now(UTC)
                self.db.commit()
                return candidate
        return None

    def _issue_token(self, user: User) -> str:
        settings = get_settings()
        return encode_access_token(
            user.id,
            extra={"exp": datetime.now(UTC) + timedelta(hours=settings.auth_token_ttl_hours)},
        )


def get_token_user(db: Session, token: str) -> User:
    try:
        payload = decode_access_token(token)
        return UserRepo(db).get(uuid.UUID(payload["sub"]))
    except Exception as exc:
        raise UnauthorizedError("Invalid or expired token") from exc
