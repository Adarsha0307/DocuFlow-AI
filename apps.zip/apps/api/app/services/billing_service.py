"""Billing abstraction: plans, subscriptions, checkout, Stripe webhook handoff.

Primary provider is mock (no external calls); swapping to Stripe is config-driven.
"""

import uuid
from datetime import UTC, datetime, timedelta

import httpx
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.logging import get_logger
from app.models import BillingCustomer, BillingSubscription, Organization
from app.models.enums import PlanCode, SubscriptionStatus
from app.services.rbac import RBAC

logger = get_logger("docuflow.billing")

PLANS = {
    PlanCode.STARTER: {"name": "Starter", "price": 29, "videos": 4},
    PlanCode.PRO: {"name": "Pro", "price": 79, "videos": 15},
    PlanCode.STUDIO: {"name": "Studio", "price": 199, "videos": 60},
    PlanCode.AGENCY: {"name": "Agency", "price": 499, "videos": 250},
}


class BillingService:
    def __init__(self, db: Session):
        self.db = db
        self.settings = get_settings()

    def ensure_customer(self, org_id: uuid.UUID, email: str | None = None) -> BillingCustomer:
        customer = self.db.query(BillingCustomer).filter(BillingCustomer.organization_id == org_id).first()
        if not customer:
            customer = BillingCustomer(organization_id=org_id, provider="mock", email=email)
            self.db.add(customer)
            self.db.commit()
            self.db.refresh(customer)
        return customer

    def subscription(self, org_id: uuid.UUID) -> BillingSubscription | None:
        return self.db.query(BillingSubscription).filter(BillingSubscription.organization_id == org_id).first()

    def current_plan(self, org_id: uuid.UUID) -> dict:
        org = self.db.get(Organization, org_id)
        sub = self.subscription(org_id)
        code = (sub.plan_code if sub else org.plan_code) or "starter"
        plan = PLANS.get(code, PLANS["starter"])
        return {
            "code": code,
            "name": plan["name"],
            "monthly_price_usd": plan["price"],
            "status": sub.status.value if sub else "active",
            "period_end": sub.current_period_end if sub else None,
            "cancel_at_period_end": bool(sub and sub.cancel_at_period_end),
        }

    def checkout_session(self, *, org_id: uuid.UUID, user_id: uuid.UUID, plan_code: str) -> dict:
        RBAC(self.db, org_id, user_id).require("billing.manage")
        org = self.db.get(Organization, org_id)
        customer = self.ensure_customer(org_id, email=None)
        if self.settings.billing_provider == "stripe" and self.settings.stripe_secret_key:
            return self._stripe_checkout(org, customer, plan_code)
        return {
            "provider": "mock",
            "checkout_url": f"https://billing.docuflow.local/checkout/{org.id}/{plan_code}",
            "plan_code": plan_code,
            "price_usd": PLANS.get(plan_code, PLANS["starter"])["price"],
            "mode": self.settings.billing_provider,
        }

    def _stripe_checkout(self, org: Organization, customer: BillingCustomer, plan_code: str) -> dict:
        price_ids = {"pro": "price_pro_monthly", "studio": "price_studio_monthly", "agency": "price_agency_monthly"}
        price = price_ids.get(plan_code)
        if not price:
            raise ValueError(f"unknown plan {plan_code}")
        r = httpx.post(
            "https://api.stripe.com/v1/checkout/sessions",
            auth=(self.settings.stripe_secret_key, ""),
            data={
                "mode": "subscription",
                "line_items[0][price]": price,
                "line_items[0][quantity]": "1",
                "success_url": f"{self.settings.frontend_url}/billing?status=success",
                "cancel_url": f"{self.settings.frontend_url}/billing?status=canceled",
                "client_reference_id": str(org.id),
                "customer": customer.provider_customer_id or "",
            },
            timeout=30,
        )
        r.raise_for_status()
        return {"url": r.json()["url"], "provider": "stripe", "plan_code": plan_code}

    def apply_subscription(self, *, org_id: uuid.UUID, plan_code: str) -> BillingSubscription:
        sub = self.subscription(org_id)
        now = datetime.now(UTC)
        if sub:
            sub.plan_code = plan_code
            sub.status = SubscriptionStatus.ACTIVE
            sub.current_period_end = now + timedelta(days=30)
        else:
            sub = BillingSubscription(
                organization_id=org_id, provider="mock", plan_code=plan_code,
                status=SubscriptionStatus.ACTIVE,
                current_period_start=now,
                current_period_end=now + timedelta(days=30),
            )
            self.db.add(sub)
        org = self.db.get(Organization, org_id)
        org.plan_code = plan_code
        self.db.commit()
        self.db.refresh(sub)
        return sub

    def handle_webhook(self, payload: dict) -> dict:
        """Stripe webhook handoff (mock passthrough). Returns processed summary."""
        event_type = payload.get("type", "")
        data = payload.get("data", {}).get("object", {})
        handled = False
        if event_type in {"checkout.session.completed", "invoice.paid"}:
            org_id = data.get("metadata", {}).get("org_id") or (data.get("client_reference_id"))
            plan_code = data.get("metadata", {}).get("plan_code") or "pro"
            if org_id:
                self.apply_subscription(org_id=uuid.UUID(org_id), plan_code=plan_code)
                handled = True
        return {"handled": handled, "event": event_type}
