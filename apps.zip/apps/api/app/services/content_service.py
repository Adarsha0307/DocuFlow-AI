"""Content services: scripts, scenes, assets, characters, prompts, voiceovers, thumbnails."""


from sqlalchemy.orm import Session

from app.core.errors import NotFoundError
from app.models import (
    Asset,
    CharacterProfile,
    Prompt,
    PromptVersion,
    Scene,
    SceneVersion,
    Script,
    ScriptVersion,
    Thumbnail,
    Voiceover,
)
from app.repositories.content_repo import (
    SceneRepo,
    ScriptRepo,
)
from app.services.project_service import ProjectService


class ContentService:
    def __init__(self, db: Session):
        self.db = db
        self.projects = ProjectService(db)

    # --- scripts ---------------------------------------------------------
    def create_script(self, *, org_id, user_id, project_id, title=None, body, language="en-US") -> Script:
        self.projects.rbac(org_id, user_id).require("script.write")
        self.projects.get_for_org(project_id, org_id)
        script = Script(
            organization_id=org_id,
            project_id=project_id,
            title=title or "Untitled script",
            body=body,
            language=language,
            word_count=len(body.split()),
            created_by=user_id,
        )
        self.db.add(script)
        self.db.flush()
        self.db.add(ScriptVersion(script_id=script.id, version=1, body=body, created_by=user_id))
        self.db.commit()
        self.db.refresh(script)
        return script

    def get_script(self, script_id, *, org_id, user_id) -> Script:
        self.projects.rbac(org_id, user_id).require("project.view")
        script = ScriptRepo(self.db).get(script_id)
        self.projects.get_for_org(script.project_id, org_id)
        return script

    def list_scripts(self, *, org_id, user_id, project_id) -> list[Script]:
        self.projects.rbac(org_id, user_id).require("project.view")
        return list(self.db.query(Script).filter(Script.project_id == project_id).order_by(Script.created_at.desc()))

    def revise_script(self, *, org_id, user_id, script_id, body, notes=None) -> ScriptVersion:
        self.projects.rbac(org_id, user_id).require("script.write")
        script = ScriptRepo(self.db).get(script_id)
        self.projects.get_for_org(script.project_id, org_id)
        existing_versions = list(self.db.query(ScriptVersion).filter(ScriptVersion.script_id == script.id))
        version_no = max((v.version for v in existing_versions), default=0) + 1
        version = ScriptVersion(
            script_id=script.id, version=version_no, body=body,
            diff_json=[{"op": "full_replace", "similarity": _compute_diff_count(script.body, body)}],
            change_notes=notes, created_by=user_id,
        )
        self.db.add(version)
        script.version = version_no
        script.body = body
        script.word_count = len(body.split())
        self.db.commit()
        self.db.refresh(version)
        return version

    # --- scenes -----------------------------------------------------------
    def create_scene(self, *, org_id, user_id, project_id, scene_number, title, narration,
                     visual_direction=None, duration_seconds=15.0) -> Scene:
        self.projects.rbac(org_id, user_id).require("scene.write")
        self.projects.get_for_org(project_id, org_id)
        scene = Scene(
            project_id=project_id, scene_number=scene_number, title=title,
            narration=narration, visual_direction=visual_direction,
            duration_seconds=duration_seconds, status="planned",
        )
        self.db.add(scene)
        self.db.flush()
        self.db.add(SceneVersion(scene_id=scene.id, version=1, narration=narration,
                                 visual_direction=visual_direction))
        self.db.commit()
        self.db.refresh(scene)
        return scene

    def list_scenes(self, *, org_id, user_id, project_id) -> list[Scene]:
        self.projects.rbac(org_id, user_id).require("project.view")
        return SceneRepo(self.db).for_project(project_id)

    def get_scene(self, scene_id, *, org_id, user_id) -> Scene:
        scene = SceneRepo(self.db).get(scene_id)
        self.projects.get_for_org(scene.project_id, org_id)
        return scene

    def revise_scene(self, *, org_id, user_id, scene_id, narration, visual_direction=None) -> SceneVersion:
        self.projects.rbac(org_id, user_id).require("scene.write")
        scene = self.get_scene(scene_id, org_id=org_id, user_id=user_id)
        version = max((v.version for v in self.db.query(SceneVersion).filter(SceneVersion.scene_id == scene_id)), default=0) + 1
        sv = SceneVersion(scene_id=scene_id, version=version, narration=narration,
                          visual_direction=visual_direction)
        self.db.add(sv)
        scene.narration = narration
        scene.visual_direction = visual_direction
        self.db.commit()
        self.db.refresh(sv)
        return sv


def _compute_diff_count(before: str, after: str) -> int:
    from difflib import SequenceMatcher

    return int(SequenceMatcher(None, before.split(), after.split()).quick_ratio() * 100)


# ---------------------------------------------------------------------------
class AssetService:
    def __init__(self, db: Session):
        self.db = db
        self.projects = ProjectService(db)

    def create(self, *, org_id, user_id, project_id, kind, name, storage_key=None,
               public_url=None, mime_type=None, scene_id=None, provider=None,
               provenance=None) -> Asset:
        self.projects.rbac(org_id, user_id).require("asset.write")
        self.projects.get_for_org(project_id, org_id)
        asset = Asset(
            organization_id=org_id, project_id=project_id, scene_id=scene_id, kind=kind,
            name=name, storage_key=storage_key, public_url=public_url, mime_type=mime_type,
            provider=provider, provenance_json=provenance, status="ready",
        )
        self.db.add(asset)
        self.db.commit()
        self.db.refresh(asset)
        return asset

    def list(self, *, org_id, user_id, project_id, kind=None) -> list[Asset]:
        self.projects.rbac(org_id, user_id).require("project.view")
        q = self.db.query(Asset).filter(Asset.project_id == project_id)
        if kind:
            q = q.filter(Asset.kind == kind)
        return list(q.order_by(Asset.created_at.desc()))

    def get(self, asset_id, *, org_id) -> Asset:
        asset = self.db.get(Asset, asset_id)
        if not asset or asset.organization_id != org_id:
            raise NotFoundError("Asset not found")
        return asset

    def score(self, asset_id, *, org_id, user_id, score) -> Asset:
        self.projects.rbac(org_id, user_id).require("asset.write")
        asset = self.get(asset_id, org_id=org_id)
        asset.score = score
        self.db.commit()
        self.db.refresh(asset)
        return asset


class CharacterService:
    def __init__(self, db: Session):
        self.db = db
        self.projects = ProjectService(db)

    def create(self, *, org_id, user_id, project_id, name, role=None, appearance_prompt=None) -> CharacterProfile:
        self.projects.rbac(org_id, user_id).require("asset.write")
        self.projects.get_for_org(project_id, org_id)
        character = CharacterProfile(
            organization_id=org_id, project_id=project_id, name=name, role=role,
            appearance_prompt=appearance_prompt,
        )
        self.db.add(character)
        self.db.commit()
        self.db.refresh(character)
        return character

    def list(self, *, org_id, project_id) -> list[CharacterProfile]:
        return list(self.db.query(CharacterProfile).filter(CharacterProfile.project_id == project_id))


class PromptService:
    def __init__(self, db: Session):
        self.db = db

    def create(self, *, project_id, scene_id, target, kind, text, negative_prompt=None) -> Prompt:
        prompt = Prompt(
            project_id=project_id, scene_id=scene_id, target=target, kind=kind,
            text=text, negative_prompt=negative_prompt,
        )
        self.db.add(prompt)
        self.db.flush()
        self.db.add(PromptVersion(prompt_id=prompt.id, version=1, text=text))
        self.db.commit()
        self.db.refresh(prompt)
        return prompt

    def list_for_project(self, project_id) -> list[Prompt]:
        return list(self.db.query(Prompt).filter(Prompt.project_id == project_id).order_by(Prompt.created_at.desc()))

    def versionize(self, prompt_id, text) -> PromptVersion:
        versions = list(
            self.db.query(PromptVersion).filter(PromptVersion.prompt_id == prompt_id)
        )
        next_no = max((v.version for v in versions), default=0) + 1
        pv = PromptVersion(prompt_id=prompt_id, version=next_no, text=text)
        self.db.add(pv)
        self.db.commit()
        self.db.refresh(pv)
        return pv


class VoiceoverService:
    def __init__(self, db: Session):
        self.db = db

    def create(self, *, organization_id, project_id, provider="mock", voice="documentary-male",
              language="en-US", sample_url=None, character_count=0, duration_seconds=None) -> Voiceover:
        vo = Voiceover(
            organization_id=organization_id, project_id=project_id, provider=provider,
            voice=voice, language=language, sample_url=sample_url,
            character_count=character_count, duration_seconds=duration_seconds,
            status="generated",
        )
        self.db.add(vo)
        self.db.commit()
        self.db.refresh(vo)
        return vo


class ThumbnailService:
    def __init__(self, db: Session):
        self.db = db

    def create(self, *, organization_id, project_id, title_text=None, style=None,
               preview_url=None, prompt_id=None) -> Thumbnail:
        t = Thumbnail(
            organization_id=organization_id, project_id=project_id, title_text=title_text,
            style=style, preview_url=preview_url, prompt_id=prompt_id, status="generated",
        )
        self.db.add(t)
        self.db.commit()
        self.db.refresh(t)
        return t

    def list(self, project_id) -> list[Thumbnail]:
        return list(self.db.query(Thumbnail).filter(Thumbnail.project_id == project_id))
