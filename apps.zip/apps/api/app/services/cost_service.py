"""FinOps: cost recording per provider/step with soft and hard budget enforcement."""

from datetime import UTC, datetime

from sqlalchemy.orm import Session

from app.core.errors import QuotaExceededError
from app.core.logging import get_logger
from app.models import CostRecord, WorkflowRun
from app.models.enums import CreditCategory
from app.observability import metrics
from app.providers import unit_price
from app.providers.base import ProviderResult
from app.services.audit_service import AuditService

logger = get_logger("docuflow.costs")

# Monthly spend budget by plan (USD). Soft = alert, hard = halt.
PLAN_BUDGET_USD = {
    "starter": 50.0,
    "pro": 200.0,
    "studio": 600.0,
    "agency": 2500.0,
}


class CostService:
    def __init__(self, db: Session):
        self.db = db

    def record(self, *, org_id, provider: str, category: str | CreditCategory,
               quantity: float = 0.0, unit: str = "unit", project_id=None, run_id=None,
               step_id=None, job_id=None, meta=None, estimated: bool = False) -> CostRecord:
        price_per, price_unit = unit_price(provider, str(category))
        amount = round(quantity * price_per, 6)
        self._enforce_budget(org_id, amount)
        record = CostRecord(
            organization_id=org_id,
            project_id=project_id,
            run_id=run_id,
            step_id=step_id,
            job_id=job_id,
            provider=provider,
            category=str(category) if isinstance(category, CreditCategory) else category,
            usage_quantity=quantity,
            unit=unit,
            unit_price=price_per,
            amount_usd=amount,
            estimated=estimated,
        )
        self.db.add(record)
        if run_id:
            run = self.db.get(WorkflowRun, run_id)
            if run:
                run.total_cost_usd = float(run.total_cost_usd or 0.0) + amount
        self.db.commit()
        metrics.record_cost(org_id, amount)
        return record

    def record_provider_result(self, *, org_id, project_id, run_id, step_id, provider_name,
                               result: ProviderResult, category: CreditCategory) -> CostRecord | None:
        if not result.usage:
            return None
        return self.record(
            org_id=org_id, provider=provider_name, category=category,
            quantity=result.usage.quantity, unit=result.usage.unit,
            project_id=project_id, run_id=run_id, step_id=step_id,
            estimated=not result.ok,
        )

    def totals(self, org_id) -> float:
        from app.repositories.workflow_repo import CostRecordRepo

        return CostRecordRepo(self.db).totals_for_org(org_id)["total_usd"]

    def breakdown(self, org_id, project_id=None) -> dict:
        from app.repositories.workflow_repo import CostRecordRepo

        return CostRecordRepo(self.db).breakdown(org_id, project_id)

    def _enforce_budget(self, org_id, added: float) -> None:
        from app.models import Organization

        org = self.db.get(Organization, org_id)
        budget = PLAN_BUDGET_USD.get(org.plan_code if org else "starter", 50.0)
        spent = self.totals(org_id)
        if spent >= budget:
            AuditService(self.db).record(
                org_id=org_id, actor_id=None, action="budget.hard_hit",
                resource_type="billing", resource_id=str(org_id),
                after={"spent": spent, "budget": budget},
            )
            raise QuotaExceededError(
                f"Organization budget of ${budget:,.0f} exhausted (spent ${spent:,.2f})",
            )


def record_provider_cost(db, org_id, project_id, run_id, step_id, result, category) -> None:
    CostService(db).record_provider_result(
        org_id=org_id, project_id=project_id, run_id=run_id, step_id=step_id,
        provider_name=result.provider, result=result, category=category,
    )


def timestamp() -> str:
    return datetime.now(UTC).isoformat()
