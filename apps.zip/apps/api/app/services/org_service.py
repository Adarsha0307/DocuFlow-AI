"""Organization / team / invitation service."""

import uuid
from datetime import UTC, datetime, timedelta

from sqlalchemy.orm import Session

from app.core.errors import ConflictError, ForbiddenError, NotFoundError, ValidationFailedError
from app.core.security import generate_secure_token, sign_string
from app.models import Invitation, Membership, Organization
from app.models.enums import InvitationStatus, MembershipStatus, PlanCode, Role
from app.repositories.identity_repo import (
    InvitationRepo,
    MembershipRepo,
    OrganizationRepo,
    UserRepo,
)
from app.services.audit_service import AuditService
from app.services.rbac import RBAC


class OrgService:
    def __init__(self, db: Session):
        self.db = db

    def create(self, *, user_id: uuid.UUID, name: str, slug: str | None = None) -> Organization:
        org_repo = OrganizationRepo(self.db)
        org = Organization(
            name=name,
            slug=org_repo.ensure_unique_slug(slug or name),
            plan_code=PlanCode.STARTER,
            created_by=user_id,
        )
        self.db.add(org)
        self.db.flush()
        self.db.add(
            Membership(
                organization_id=org.id,
                user_id=user_id,
                role=Role.OWNER,
                status=MembershipStatus.ACTIVE,
            )
        )
        AuditService(self.db).record(
            org_id=org.id, actor_id=user_id, action="org.created",
            resource_type="organization", resource_id=str(org.id), after={"name": name},
        )
        self.db.commit()
        self.db.refresh(org)
        return org

    def list_for_user(self, user_id: uuid.UUID) -> list[Organization]:
        return MembershipRepo(self.db).my_orgs(user_id)

    def get(self, org_id: uuid.UUID, user_id: uuid.UUID) -> Organization:
        RBAC(self.db, org_id, user_id).require("project.view")
        org = OrganizationRepo(self.db).get(org_id)
        org.member_count = MembershipRepo(self.db).member_count(org_id)
        return org

    def update(self, org_id: uuid.UUID, user_id: uuid.UUID, *, name: str | None = None,
               slug: str | None = None) -> Organization:
        RBAC(self.db, org_id, user_id).require("project.edit")
        org = OrganizationRepo(self.db).get(org_id)
        if name:
            org.name = name
        if slug:
            org.slug = OrganizationRepo(self.db).ensure_unique_slug(slug)
        self.db.commit()
        self.db.refresh(org)
        return org

    def members(self, org_id: uuid.UUID, user_id: uuid.UUID) -> list[dict]:
        RBAC(self.db, org_id, user_id).require("project.view")
        return MembershipRepo(self.db).list_members(org_id)

    def invite(self, *, org_id: uuid.UUID, inviter_id: uuid.UUID, email: str,
               role: Role = Role.EDITOR) -> Invitation:
        RBAC(self.db, org_id, inviter_id).require("team.manage")
        repo = InvitationRepo(self.db)
        if repo.find_pending(org_id, email):
            raise ConflictError("An invitation for this email already exists")
        raw_token = generate_secure_token(24)
        invite = Invitation(
            organization_id=org_id,
            invited_by=inviter_id,
            email=email.strip().lower(),
            role=role,
            token_hash=sign_string(raw_token),
            status=InvitationStatus.PENDING,
            expires_at=datetime.now(UTC) + timedelta(days=7),
        )
        self.db.add(invite)
        AuditService(self.db).record(
            org_id=org_id, actor_id=inviter_id, action="team.invite",
            resource_type="invitation", resource_id=str(invite.id),
            after={"email": email, "role": str(role)},
        )
        self.db.commit()
        self.db.refresh(invite)
        invite.meta_token = raw_token  # returned once; never persisted
        return invite

    def accept_invite(self, *, token: str, user_id: uuid.UUID) -> Organization:
        invite = InvitationRepo(self.db).by_token_hash(sign_string(token))
        if not invite:
            raise NotFoundError("Invitation not found")
        if invite.status != InvitationStatus.PENDING:
            raise ConflictError("Invitation is no longer pending")
        if invite.email.lower() != UserRepo(self.db).get(user_id).email.lower():
            raise ValidationFailedError("Invitation email does not match your account")
        if invite.expires_at and invite.expires_at < datetime.now(UTC):
            raise ConflictError("Invitation expired")
        if MembershipRepo(self.db).get_membership(invite.organization_id, user_id):
            raise ConflictError("Already a member")
        self.db.add(
            Membership(
                organization_id=invite.organization_id,
                user_id=user_id,
                role=invite.role,
                status=MembershipStatus.ACTIVE,
            )
        )
        invite.status = InvitationStatus.ACCEPTED
        invite.accepted_at = datetime.now(UTC)
        self.db.commit()
        return OrganizationRepo(self.db).get(invite.organization_id)

    def set_role(self, *, org_id: uuid.UUID, admin_id: uuid.UUID, member_id: uuid.UUID,
                 role: Role) -> Membership:
        RBAC(self.db, org_id, admin_id).require("team.manage")
        membership = MembershipRepo(self.db).get_membership(org_id, member_id)
        if not membership:
            raise NotFoundError("Member not found")
        if membership.role == Role.OWNER:
            raise ForbiddenError("The owner role cannot be changed")
        membership.role = role
        self.db.commit()
        self.db.refresh(membership)
        return membership

    def remove_member(self, *, org_id: uuid.UUID, admin_id: uuid.UUID, member_id: uuid.UUID) -> None:
        RBAC(self.db, org_id, admin_id).require("team.manage")
        membership = MembershipRepo(self.db).get_membership(org_id, member_id)
        if not membership:
            raise NotFoundError("Member not found")
        if membership.role == Role.OWNER:
            raise ForbiddenError("The owner cannot be removed")
        membership.status = MembershipStatus.LEFT
        self.db.commit()
