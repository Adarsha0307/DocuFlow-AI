"""Project lifecycle and project-level settings."""

import uuid
from datetime import UTC, datetime

from sqlalchemy.orm import Session

from app.core.errors import ValidationFailedError
from app.models import Project, ProjectSettings
from app.models.enums import AutomationMode, ProjectStatus
from app.repositories.content_repo import ProjectRepo
from app.services.audit_service import AuditService
from app.services.rbac import RBAC


class ProjectService:
    def __init__(self, db: Session):
        self.db = db

    def rbac(self, org_id: uuid.UUID, user_id: uuid.UUID) -> RBAC:
        return RBAC(self.db, org_id, user_id)

    def create(self, *, org_id: uuid.UUID, user_id: uuid.UUID, data: dict) -> Project:
        self.rbac(org_id, user_id).require("project.create")
        name = data.get("name")
        topic = data.get("topic")
        if not name or not topic:
            raise ValidationFailedError("name and topic are required")

        project = Project(
            organization_id=org_id,
            created_by=user_id,
            name=name,
            topic=topic,
            niche=data.get("niche"),
            tone=data.get("tone", "documentary"),
            art_style=data.get("art_style") or data.get("artStyle") or "2d flat",
            duration_seconds=data.get("duration_seconds") or data.get("durationSeconds") or 420,
            narration_language=(
                data.get("narration_language") or data.get("narrationLanguage") or "en-US"
            ),
            voice_type=data.get("voice_type") or data.get("voiceType") or "documentary-male",
            automation_mode=data.get("automation_mode")
            or data.get("automationMode")
            or AutomationMode.MANUAL,
            channel_id=data.get("channel_id") or data.get("channelId"),
            status=ProjectStatus.DRAFT,
        )
        self.db.add(project)
        self.db.flush()
        self.db.add(
            ProjectSettings(
                project_id=project.id,
                render_preset="1080p",
                auto_approve=bool(
                    data.get("auto_approve")
                    or project.automation_mode == AutomationMode.FULL
                ),
                auto_publish=bool(data.get("auto_publish")),
            )
        )
        AuditService(self.db).record(
            org_id=org_id, actor_id=user_id, action="project.created",
            resource_type="project", resource_id=str(project.id), after={"name": name},
        )
        self.db.commit()
        self.db.refresh(project)
        return project

    def get_for_org(self, project_id: uuid.UUID, org_id: uuid.UUID) -> Project:
        project = self.db.get(Project, project_id)
        if not project or project.deleted_at is not None or project.organization_id != org_id:
            from app.core.errors import NotFoundError

            raise NotFoundError("Project not found")
        return project

    def list(self, org_id: uuid.UUID, user_id: uuid.UUID) -> list[Project]:
        self.rbac(org_id, user_id).require("project.view")
        return ProjectRepo(self.db).by_org(org_id)

    def update(self, project_id: uuid.UUID, *, org_id: uuid.UUID, user_id: uuid.UUID,
               data: dict) -> Project:
        self.rbac(org_id, user_id).require("project.edit")
        project = self.get_for_org(project_id, org_id)
        allowed = {
            "name", "topic", "niche", "tone", "art_style", "duration_seconds",
            "narration_language", "voice_type", "automation_mode", "status",
            "channel_id", "cover_url",
        }
        for field in allowed:
            if field in data:
                setattr(project, field, data[field])
        self.db.commit()
        self.db.refresh(project)
        return project

    def delete(self, project_id: uuid.UUID, *, org_id: uuid.UUID, user_id: uuid.UUID) -> None:
        self.rbac(org_id, user_id).require("project.delete")
        project = self.get_for_org(project_id, org_id)
        project.deleted_at = datetime.now(UTC)
        self.db.commit()

    def mark_status(self, project_id: uuid.UUID, status: str) -> None:
        project = self.db.get(Project, project_id)
        if project:
            project.status = status
            self.db.commit()
