"""RAG layer: embedding storage (pgvector) + org/project-scoped semantic retrieval."""

import math

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.logging import get_logger
from app.db.pgvector import PG_VECTOR_AVAILABLE
from app.models import ProjectMemory, ResearchSnippet
from app.providers.base import EmbeddingsProvider
from app.providers.registry import get_registry
from app.services.usage_service import UsageService

logger = get_logger("docuflow.rag")


def _cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b, strict=False))
    na = math.sqrt(sum(x * x for x in a)) or 1.0
    nb = math.sqrt(sum(x * x for x in b)) or 1.0
    return dot / (na * nb)


class RagService:
    def __init__(self, db: Session):
        self.db = db

    def embedder(self, org_id) -> EmbeddingsProvider:
        # Org-level default can come from provider_credentials later
        return get_registry().resolve("embeddings", org_defaults={"embeddings": "openai" if _has_keys() else "mock"})

    def embed_texts(self, org_id, texts: list[str]) -> list[list[float]]:
        provider = self.embedder(org_id)
        result = provider.embed(texts)
        if not result.ok or not result.data:
            logger.warning("embedding failed: %s", result.error)
            return []
        UsageService(self.db).consume(
            org_id=org_id, metric="tokens", amount=(result.usage.quantity if result.usage else 0),
            unit="tokens", category="embeddings", provider=result.provider,
            raise_on_hard=False,
        )
        return result.data

    # --- writes -----------------------------------------------------------
    def store_snippets(self, *, org_id, project_id, texts: list[str], kinds: list[str] | None = None) -> int:
        if not texts:
            return 0
        vectors = self.embed_texts(org_id, texts)
        count = 0
        for i, text in enumerate(texts):
            snippet = ResearchSnippet(
                organization_id=org_id,
                project_id=project_id,
                kind=(kinds[i] if kinds and i < len(kinds) else "fact"),
                text=text,
                embedding=vectors[i] if i < len(vectors) else None,
            )
            self.db.add(snippet)
            count += 1
        self.db.commit()
        return count

    def store_memory(self, *, org_id, project_id, memory_type: str, content: str,
                     source_step: str | None = None, provenance: dict | None = None) -> ProjectMemory:
        vectors = self.embed_texts(org_id, [content])
        memory = ProjectMemory(
            organization_id=org_id,
            project_id=project_id,
            memory_type=memory_type,
            content=content,
            source_step=source_step,
            provenance=provenance,
            embedding=vectors[0] if vectors else None,
        )
        self.db.add(memory)
        self.db.commit()
        self.db.refresh(memory)
        return memory

    # --- reads ------------------------------------------------------------
    def search_snippets(self, *, org_id, project_id, query: str, k: int = 8,
                        kinds: list[str] | None = None) -> list[dict]:
        query_vec = self.embed_texts(org_id, [query])
        if not query_vec:
            return self._keyword_fallback(self.db, project_id, query, k)
        qv = query_vec[0]
        if PG_VECTOR_AVAILABLE:
            try:

                rows = self.db.execute(
                    select(ResearchSnippet)
                    .where(ResearchSnippet.project_id == project_id)
                    .order_by(ResearchSnippet.embedding.cosine_distance(qv))  # type: ignore[attr-defined]
                    .limit(k)
                ).scalars().all()
                return [self._snippet_dict(s, None) for s in rows]
            except Exception as exc:  # pragma: no cover
                logger.warning("pgvector query failed, using cosine fallback: %s", exc)
        # JSON fallback: brute-force cosine
        candidates = self.db.execute(
            select(ResearchSnippet).where(ResearchSnippet.project_id == project_id)
        ).scalars().all()
        scored = []
        for s in candidates:
            if not s.embedding:
                continue
            sim = _cosine(qv, s.embedding)
            if kinds and s.kind not in kinds:
                continue
            scored.append((sim, s))
        scored.sort(key=lambda t: t[0], reverse=True)
        return [self._snippet_dict(s, sim) for sim, s in scored[:k]]

    def retrieve_context(self, *, org_id, project_id, query: str, k: int = 6) -> str:
        hits = self.search_snippets(org_id=org_id, project_id=project_id, query=query, k=k)
        if not hits:
            return ""
        lines = [f"- {h['text']}" for h in hits]
        return "\n".join(lines)

    def list_memories(self, *, org_id, project_id, memory_type: str | None = None) -> list[ProjectMemory]:
        q = select(ProjectMemory).where(ProjectMemory.project_id == project_id)
        if memory_type:
            q = q.where(ProjectMemory.memory_type == memory_type)
        return list(self.db.execute(q.order_by(ProjectMemory.created_at.desc())).scalars())

    @staticmethod
    def _snippet_dict(s: ResearchSnippet, similarity: float | None) -> dict:
        return {
            "id": str(s.id),
            "kind": s.kind,
            "text": s.text,
            "similarity": round(similarity, 4) if similarity is not None else None,
            "document_id": str(s.document_id) if s.document_id else None,
            "created_at": s.created_at,
        }

    @staticmethod
    def _keyword_fallback(db, project_id, query: str, k: int) -> list[dict]:
        from sqlalchemy import or_

        tokens = [t for t in query.lower().replace(",", " ").split() if len(t) > 2]
        if not tokens:
            return []
        filters = [ResearchSnippet.text.ilike(f"%{t}%") for t in tokens]
        rows = db.execute(
            select(ResearchSnippet)
            .where(ResearchSnippet.project_id == project_id, or_(*filters))
            .limit(k)
        ).scalars().all()
        return [RagService._snippet_dict(s, None) for s in rows]


def _has_keys() -> bool:
    from app.core.config import get_settings

    return bool(get_settings().openai_api_key)
