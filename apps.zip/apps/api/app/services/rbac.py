"""Role-based access control primitives.

Permission model: each capability maps to a minimum role weight. A user's role
must meet the weight OR the user must own the resource. Organization lookup is
resolved from the request context that the API dependency provides.
"""

import uuid

from app.core.errors import ForbiddenError
from app.models import Membership
from app.models.enums import ROLE_WEIGHT, Role
from app.repositories.identity_repo import MembershipRepo


class RBAC:
    def __init__(self, db, org_id: uuid.UUID | None, user_id: uuid.UUID | None):
        self.db = db
        self.org_id = org_id
        self.user_id = user_id
        self._membership: Membership | None = None

    def role(self) -> Role:
        if self._membership is None and self.user_id and self.org_id:
            self._membership = MembershipRepo(self.db).get_membership(self.org_id, self.user_id)
        if not self._membership:
            raise ForbiddenError("Not a member of this organization")
        return Role(self._membership.role.value if hasattr(self._membership.role, "value") else self._membership.role)

    def require(self, permission: str) -> None:
        role = self.role()
        min_weight = _PERM_WEIGHTS[permission]
        if ROLE_WEIGHT[role] < min_weight:
            raise ForbiddenError(f"Missing permission: {permission}")

    def can(self, permission: str) -> bool:
        try:
            self.require(permission)
            return True
        except ForbiddenError:
            return False


_PERM_WEIGHTS: dict[str, int] = {
    "project.view": ROLE_WEIGHT[Role.VIEWER],
    "project.create": ROLE_WEIGHT[Role.EDITOR],
    "project.edit": ROLE_WEIGHT[Role.EDITOR],
    "project.delete": ROLE_WEIGHT[Role.ADMIN],
    "script.write": ROLE_WEIGHT[Role.EDITOR],
    "scene.write": ROLE_WEIGHT[Role.EDITOR],
    "asset.write": ROLE_WEIGHT[Role.EDITOR],
    "approve": ROLE_WEIGHT[Role.EDITOR],
    "workflow.edit": ROLE_WEIGHT[Role.ADMIN],
    "workflow.run": ROLE_WEIGHT[Role.EDITOR],
    "provider.manage": ROLE_WEIGHT[Role.ADMIN],
    "billing.view": ROLE_WEIGHT[Role.BILLING_ADMIN],
    "billing.manage": ROLE_WEIGHT[Role.ADMIN],
    "upload": ROLE_WEIGHT[Role.EDITOR],
    "team.manage": ROLE_WEIGHT[Role.ADMIN],
    "audit.view": ROLE_WEIGHT[Role.ADMIN],
    "admin": ROLE_WEIGHT[Role.ADMIN],
    "owner": ROLE_WEIGHT[Role.OWNER],
}


def require_membership(db, org_id: uuid.UUID, user_id: uuid.UUID) -> Membership:
    membership = MembershipRepo(db).get_membership(org_id, user_id)
    if not membership:
        raise ForbiddenError("Not a member of this organization")
    return membership


def has_role(membership: Membership | None, *roles: Role) -> bool:
    if not membership:
        return False
    return Role(membership.role) in roles
