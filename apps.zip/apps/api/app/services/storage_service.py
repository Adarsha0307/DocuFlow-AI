"""S3-compatible object storage abstraction (local filesystem fallback)."""

import logging
import os
import uuid

from app.core.config import get_settings

logger = logging.getLogger(__name__)


class StorageDriver:
    def put_bytes(self, key: str, data: bytes, content_type: str = "application/octet-stream") -> str: ...
    def get_bytes(self, key: str) -> bytes | None: ...
    def exists(self, key: str) -> bool: ...
    def delete(self, key: str) -> None: ...
    def signed_url(self, key: str, expires_seconds: int = 900) -> str | None: ...
    def public_url(self, key: str) -> str | None: ...


class LocalStorageDriver(StorageDriver):
    """Development driver: files under STORAGE_LOCAL_ROOT (default ./media/storage)."""

    def __init__(self) -> None:
        root = get_settings().storage_local_root if hasattr(get_settings(), "storage_local_root") else "media/storage"
        self.root = os.path.abspath(root)
        os.makedirs(self.root, exist_ok=True)

    def _path(self, key: str) -> str:
        safe = key.lstrip("/").replace("..", "")
        return os.path.join(self.root, safe)

    def put_bytes(self, key, data, content_type="application/octet-stream") -> str:
        path = self._path(key)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "wb") as f:
            f.write(data)
        return self.public_url(key) or f"local://{key}"

    def get_bytes(self, key) -> bytes | None:
        path = self._path(key)
        if not os.path.exists(path):
            return None
        with open(path, "rb") as f:
            return f.read()

    def exists(self, key) -> bool:
        return os.path.exists(self._path(key))

    def delete(self, key) -> None:
        path = self._path(key)
        if os.path.exists(path):
            os.remove(path)

    def signed_url(self, key, expires_seconds=900) -> str | None:
        base = get_settings().api_base_url.rstrip("/")
        return f"{base}/api/v1/assets/file/{key}?token=dev-only"

    def public_url(self, key) -> str | None:
        base = get_settings().api_base_url.rstrip("/")
        return f"{base}/api/v1/assets/file/{key}"


class S3StorageDriver(StorageDriver):
    """boto3 S3 driver; guarded so missing boto3/creds degrade to local storage."""

    def __init__(self) -> None:
        settings = get_settings()
        self.bucket = settings.storage_bucket
        self._client = None
        try:
            import boto3
            from botocore.config import Config

            self._client = boto3.client(
                "s3",
                region_name=settings.storage_region or None,
                endpoint_url=settings.storage_endpoint or None,
                aws_access_key_id=settings.storage_access_key or None,
                aws_secret_access_key=settings.storage_secret_key or None,
                config=Config(s3={"addressing_style": "path"}) if settings.storage_force_path_style else None,
            )
            self._client.head_bucket(Bucket=self.bucket)
        except Exception as exc:  # pragma: no cover
            logger.warning("S3 unavailable (%s) — using local storage", exc)

    def _ready(self) -> bool:
        return self._client is not None

    def put_bytes(self, key, data, content_type="application/octet-stream") -> str:
        if not self._ready():
            return LocalStorageDriver().put_bytes(key, data, content_type)
        self._client.put_object(Bucket=self.bucket, Key=key, Body=data, ContentType=content_type)
        return self.public_url(key) or f"s3://{self.bucket}/{key}"

    def get_bytes(self, key) -> bytes | None:
        if not self._ready():
            return LocalStorageDriver().get_bytes(key)
        try:
            obj = self._client.get_object(Bucket=self.bucket, Key=key)
            return obj["Body"].read()
        except Exception:
            return None

    def exists(self, key) -> bool:
        if not self._ready():
            return LocalStorageDriver().exists(key)
        try:
            self._client.head_object(Bucket=self.bucket, Key=key)
            return True
        except Exception:
            return False

    def delete(self, key) -> None:
        if not self._ready():
            return LocalStorageDriver().delete(key)
        try:
            self._client.delete_object(Bucket=self.bucket, Key=key)
        except Exception as exc:  # pragma: no cover
            logger.warning("S3 delete failed: %s", exc)

    def signed_url(self, key, expires_seconds=900) -> str | None:
        if not self._ready():
            return LocalStorageDriver().signed_url(key, expires_seconds)
        return self._client.generate_presigned_url(
            "get_object",
            Params={"Bucket": self.bucket, "Key": key},
            ExpiresIn=expires_seconds,
        )

    def public_url(self, key) -> str | None:
        base = get_settings().storage_public_base_url or get_settings().api_base_url.rstrip("/")
        return f"{base}/api/v1/assets/file/{key}"


_driver: StorageDriver | None = None


def get_storage() -> StorageDriver:
    global _driver
    if _driver is None:
        driver_name = get_settings().storage_driver
        _driver = S3StorageDriver() if driver_name in ("s3", "minio") else LocalStorageDriver()
    return _driver


def asset_key(*, org_id, project_id, kind: str, name: str) -> str:
    ext = os.path.splitext(name)[1]
    return f"org/{org_id}/project/{project_id}/{kind}/{uuid.uuid4().hex}{ext}"
