"""YouTube upload orchestration with resumable sessions and attempts."""

from datetime import UTC, datetime

from sqlalchemy.orm import Session

from app.core.logging import get_logger
from app.events.bus import DomainEvent, get_bus
from app.models import UploadAttempt, UploadJob
from app.models.enums import UploadState
from app.providers.base import UploadProvider
from app.providers.registry import get_registry
from app.services.audit_service import AuditService
from app.services.storage_service import get_storage

logger = get_logger("docuflow.uploads")

CHUNK_SIZE = 8 * 1024 * 1024  # 8 MiB


class UploadService:
    def __init__(self, db: Session):
        self.db = db

    def create_job(self, *, org_id, user_id, project_id, channel_id=None, render_id=None,
                   title=None, description=None, tags=None, privacy_status="private",
                   publish_at=None, provider="youtube") -> UploadJob:
        job = UploadJob(
            organization_id=org_id,
            project_id=project_id,
            channel_id=channel_id,
            render_id=render_id,
            provider=provider,
            state=UploadState.PENDING,
            title=title,
            description=description,
            tags=tags or [],
            privacy_status=privacy_status,
            publish_at=publish_at,
        )
        self.db.add(job)
        AuditService(self.db).record(
            org_id=org_id, actor_id=user_id, action="upload.job_created",
            resource_type="upload_job", resource_id=str(job.id),
        )
        self.db.commit()
        self.db.refresh(job)
        return job

    def get_job(self, job_id, *, org_id) -> UploadJob:
        job = self.db.get(UploadJob, job_id)
        if not job or job.organization_id != org_id:
            from app.core.errors import NotFoundError

            raise NotFoundError("Upload job not found")
        return job

    def execute(self, *, org_id, job_id, access_token: str | None = None) -> UploadJob:
        """Run a resumable upload; safe to call repeatedly (attempts + resume)."""
        job = self.get_job(job_id, org_id=org_id)
        if job.state in (UploadState.COMPLETED, UploadState.CANCELED):
            return job

        render_key = None
        if job.render_id:
            from app.models import Render

            render = self.db.get(Render, job.render_id)
            render_key = render.output_key if render else None
        if not render_key:
            job.state = UploadState.FAILED
            job.error = "render output missing"
            self.db.commit()
            return job

        storage = get_storage()
        data = storage.get_bytes(render_key)
        if not data:
            job.state = UploadState.FAILED
            job.error = f"render file not found in storage ({render_key})"
            self.db.commit()
            return job

        provider: UploadProvider = get_registry().resolve("upload", preferred=job.provider)
        attempt = self._next_attempt(job)
        attempt.status = UploadState.UPLOADING
        job.state = UploadState.UPLOADING

        # --- resume-aware session creation ---------------------------------
        session_id = attempt.session_uri
        meta = {"access_token": access_token, "content_length": len(data),
                "attempt": attempt.attempt}
        if not session_id:
            started = provider.start_upload(
                title=job.title or "Untitled video",
                description=job.description or "",
                tags=job.tags,
                visibility=job.privacy_status,
                publish_at=job.publish_at.isoformat() if job.publish_at else None,
                meta=meta,
            )
            if not started.ok:
                attempt.status = UploadState.FAILED
                attempt.error = started.error
                job.state = UploadState.FAILED
                job.error = started.error
                self.db.commit()
                return job
            session_id = started.data["session_id"]
            attempt.session_uri = session_id
            attempt.total_bytes = len(data)
            self.db.commit()

        # --- chunked upload with byte offsets (resumable) -------------------
        offset = attempt.bytes_uploaded
        failed = False
        while offset < len(data):
            chunk = data[offset:offset + CHUNK_SIZE]
            result = provider.upload_chunk(session_id, chunk, offset, meta={"total": len(data)})
            if not result.ok:
                logger.error("upload chunk failed at %s: %s", offset, result.error)
                failed = True
                break
            attempt.bytes_uploaded = offset + len(chunk)
            job.progress = round((attempt.bytes_uploaded / len(data)) * 100, 1)
            self.db.commit()
            offset += len(chunk)

        if failed:
            attempt.status = UploadState.RESUME_INTERRUPTED
            job.state = UploadState.RESUME_INTERRUPTED
            job.error = "chunk upload interrupted; job can be retried"
            get_bus().publish(
                DomainEvent("upload_failed", organization_id=str(org_id),
                            project_id=str(job.project_id),
                            payload={"job_id": str(job.id), "reason": "chunk_failure"})
            )
            self.db.commit()
            return job

        finished = provider.finish_upload(session_id, meta={"access_token": access_token})
        if not finished.ok:
            attempt.status = UploadState.FAILED
            attempt.error = finished.error
            job.state = UploadState.FAILED
            job.error = finished.error
            self.db.commit()
            return job

        attempt.status = UploadState.COMPLETED
        attempt.completed_at = datetime.now(UTC)
        job.state = UploadState.COMPLETED
        job.external_video_id = finished.data.get("external_video_id")
        job.progress = 100.0
        AuditService(self.db).record(
            org_id=org_id, actor_id=None, action="upload.completed",
            resource_type="upload_job", resource_id=str(job.id),
            after={"video_id": job.external_video_id},
        )
        self.db.commit()
        self.db.refresh(job)

        get_bus().publish(
            DomainEvent("upload_completed", organization_id=str(org_id),
                        project_id=str(job.project_id),
                        payload={"job_id": str(job.id), "video_id": job.external_video_id})
        )
        return job

    def _next_attempt(self, job: UploadJob) -> UploadAttempt:
        existing = [a for a in self.db.query(UploadAttempt).filter(UploadAttempt.upload_job_id == job.id)]
        number = max((a.attempt for a in existing), default=0) + 1
        attempt = UploadAttempt(upload_job_id=job.id, attempt=number, status=UploadState.UPLOADING)
        self.db.add(attempt)
        self.db.flush()
        return attempt

    def resume(self, *, org_id, job_id, access_token=None) -> UploadJob:
        return self.execute(org_id=org_id, job_id=job_id, access_token=access_token)
