"""Usage metering + plan quota enforcement."""

import uuid
from datetime import UTC, datetime

from sqlalchemy.orm import Session

from app.core.errors import QuotaExceededError
from app.core.logging import get_logger
from app.events.bus import DomainEvent, get_bus
from app.models import QuotaCounter, UsageLog
from app.repositories.workflow_repo import QuotaRepo

logger = get_logger("docuflow.usage")

# Plan quotas per org per month. Source of truth in packages/shared (PLANS).
PLAN_LIMITS = {
    "starter": {"videos": 4, "renders": 8, "tokens": 2_000_000, "images": 240, "storage_bytes": 10 * (1 << 30)},
    "pro": {"videos": 15, "renders": 40, "tokens": 10_000_000, "images": 1200, "storage_bytes": 50 * (1 << 30)},
    "studio": {"videos": 60, "renders": 200, "tokens": 40_000_000, "images": 5000, "storage_bytes": 250 * (1 << 30)},
    "agency": {"videos": 250, "renders": 1000, "tokens": 200_000_000, "images": 20000, "storage_bytes": 1000 * (1 << 30)},
}

SOFT_RATIO = 0.8


class UsageService:
    def __init__(self, db: Session):
        self.db = db

    def current_period(self) -> str:
        return datetime.now(UTC).strftime("%Y-%m")

    def consume(self, *, org_id, metric: str, amount: float, period: str | None = None,
                project_id: uuid.UUID | None = None, run_id: uuid.UUID | None = None,
                user_id: uuid.UUID | None = None, unit: str = "unit", category: str | None = None,
                provider: str | None = None, raise_on_hard: bool = True) -> UsageLog:
        period = period or self.current_period()
        usage = UsageLog(
            organization_id=org_id, project_id=project_id, run_id=run_id, user_id=user_id,
            metric=metric, period=period, amount=amount, unit=unit, category=category, provider=provider,
        )
        self.db.add(usage)
        counter = QuotaRepo(self.db).get(org_id, metric, period)
        if not counter:
            counter = QuotaCounter(organization_id=org_id, metric=metric, period=period, value=0.0)
            self.db.add(counter)
        counter.value = float(counter.value or 0.0) + amount
        self.db.flush()
        self._evaluate(org_id, counter, metric, raise_on_hard=raise_on_hard)
        return usage

    def check(self, *, org_id: uuid.UUID, metric: str, amount: float = 0.0,
              period: str | None = None) -> dict:
        period = period or self.current_period()
        limit = self._get_limit(org_id, metric)
        counter = QuotaRepo(self.db).get(org_id, metric, period)
        used = float(counter.value) if counter else 0.0
        remaining = max(0.0, limit - used - amount)
        return {
            "metric": metric,
            "period": period,
            "used": round(used, 2),
            "limit": limit if limit != float("inf") else None,
            "remaining": round(remaining, 2) if limit != float("inf") else None,
            "percent": round(used / limit * 100, 1) if limit and limit != float("inf") else 0.0,
            "soft_percent": SOFT_RATIO * 100,
        }

    def _get_limit(self, org_id: uuid.UUID, metric: str) -> float:
        from app.models import Organization

        org = self.db.get(Organization, org_id)
        plan = org.plan_code if org else "starter"
        return float(PLAN_LIMITS.get(plan, PLAN_LIMITS["starter"]).get(metric, float("inf")))

    def _evaluate(self, org_id: uuid.UUID, counter: QuotaCounter, metric: str, raise_on_hard: bool) -> None:
        limit = self._get_limit(org_id, metric)
        if limit in (0.0, float("inf")):
            return
        ratio = float(counter.value or 0.0) / limit
        if ratio >= 1.0:
            if raise_on_hard:
                get_bus().publish(
                    DomainEvent(
                        "quota_exceeded",
                        organization_id=str(org_id),
                        payload={"metric": metric, "used": counter.value, "limit": limit},
                    )
                )
                raise QuotaExceededError(
                    f"Plan quota exceeded: '{metric}' ({counter.value}/{limit})"
                )
        elif ratio >= SOFT_RATIO:
            logger.warning(
                "org %s near quota '%s' at %.0f%%",
                org_id, metric, ratio * 100,
            )


def current_period() -> str:
    return datetime.now(UTC).strftime("%Y-%m")
