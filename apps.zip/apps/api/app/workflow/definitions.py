"""Workflow definitions: default documentary flow graph + system seeding."""


from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.models import WorkflowDefinition, WorkflowVersion
from app.models.enums import NodeType
from app.workflow.stages import STAGES, stage_def


def stage_to_node(stage: str) -> dict:
    spec = stage_def(stage)
    node_type = (
        NodeType.APPROVAL
        if spec.approval
        else (
            NodeType.CONDITION
            if stage == "topic_ideation"
            else NodeType.TASK
        )
    )
    return {
        "id": stage,
        "type": NodeType(node_type).value,
        "stage": stage,
        "label": spec.label,
        "queue": spec.queue,
        "capability": spec.capability,
        "approval": spec.approval,
    }


def build_default_flow() -> dict:
    """Linear documentary flow: every stage as a node + approval nodes."""
    nodes = [
        {"id": "start", "type": NodeType.START.value, "label": "Start", "next": DEFAULT_ORDER_0[0]},
    ]
    edges: list[dict] = []
    prev = "start"
    for stage in DEFAULT_ORDER_0:
        nodes.append(stage_to_node(stage))
        edges.append({"from": prev, "to": stage})
        prev = stage
    nodes.append({"id": "end", "type": NodeType.END.value, "label": "End"})
    edges.append({"from": prev, "to": "end"})
    return {"nodes": nodes, "edges": edges, "meta": {"version": 1}}


DEFAULT_ORDER_0 = [s.stage.value for s in STAGES]


def seed_system_definitions(db: Session) -> WorkflowDefinition | None:
    slug = get_settings().default_workflow_id
    existing = db.query(WorkflowDefinition).filter(WorkflowDefinition.slug == slug,
                                                   WorkflowDefinition.is_system.is_(True)).first()
    if existing:
        return existing
    flow = build_default_flow()
    definition = WorkflowDefinition(
        name="2D Documentary — Default Pipeline",
        slug=slug,
        description="Idea to YouTube upload for faceless 2D documentary videos.",
        version=1,
        is_system=True,
        is_locked=True,
        owner_type="system",
        flow_json=flow,
    )
    db.add(definition)
    db.flush()
    db.add(WorkflowVersion(definition_id=definition.id, version=1, flow_json=flow,
                           changelog="Initial system pipeline"))
    db.commit()
    db.refresh(definition)
    return definition
