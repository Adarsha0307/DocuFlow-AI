﻿"""Durable workflow engine â€” deterministic orchestration state machine.

Design notes (Temporal migration path):
- Every stage is a durable `WorkflowStep` row; `WorkflowRun.staged_state_json`
  holds checkpoints for pause/resume/replay.
- `executor.dispatch` is the only place that touches the broker: it either
  sends a Celery task (returns ``None`` = queued) or executes the activity
  inline (returns the outcome dict) for local dev / tests.
- Human approvals gate stages; the engine advances after `approval_completed`
  events. Revising a stage re-queues the producing stage through retry.
"""

import uuid
from datetime import UTC, datetime

from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.errors import ConflictError, NotFoundError
from app.core.logging import get_logger
from app.events.bus import DomainEvent, get_bus
from app.models import WorkflowRun, WorkflowStep
from app.models.enums import RunState, StepStatus
from app.repositories.workflow_repo import WorkflowRunRepo, WorkflowStepRepo
from app.services.approval_service import ApprovalService
from app.workflow.definitions import build_default_flow
from app.workflow.handlers import CATEGORY_BY_STAGE
from app.workflow.stages import stage_def

logger = get_logger("docuflow.engine")

_ADVANCE_CAP = 100  # per-advance work cap; protects against pathological loops


class RunController:
    """Operates on a single durable run."""

    def __init__(self, db: Session, run: WorkflowRun):
        self.db = db
        self.run = run

    # --- creation ----------------------------------------------------------

    @staticmethod
    def create(db: Session, *, org_id, project_id, definition_id=None, user_id=None,
               automation_mode: str = "manual") -> WorkflowRun:
        from app.models import WorkflowDefinition

        definition = None
        if definition_id:
            definition = db.get(WorkflowDefinition, definition_id)
        if not definition:
            slug = get_settings().default_workflow_id
            definition = (
                db.query(WorkflowDefinition)
                .filter(WorkflowDefinition.slug == slug, WorkflowDefinition.is_system.is_(True))
                .first()
            )
        flow = definition.flow_json if definition else build_default_flow()
        run = WorkflowRun(
            organization_id=org_id,
            project_id=project_id,
            definition_id=definition.id if definition else None,
            definitions_version=str(definition.version) if definition else "1",
            state=RunState.PENDING,
            staged_state_json={
                "flow": flow,
                "automation_mode": automation_mode,
                "applied_steps": [],
                "gates": {},
            },
            started_by=user_id,
        )
        db.add(run)
        db.flush()

        for node in flow.get("nodes", []):
            if node.get("id") in ("start", "end") or not node.get("stage"):
                continue
            db.add(
                WorkflowStep(
                    run_id=run.id,
                    stage=node["stage"],
                    node_id=node["id"],
                    status=StepStatus.PENDING,
                    input_json={"node": node},
                )
            )
        db.commit()
        db.refresh(run)
        get_bus().publish(
            DomainEvent("workflow_started", organization_id=str(org_id),
                        project_id=str(project_id), run_id=str(run.id),
                        payload={"definition_version": run.definitions_version})
        )
        return run

    # --- lifecycle ----------------------------------------------------------

    def start(self) -> WorkflowRun:
        if self.run.state != RunState.PENDING:
            raise ConflictError(f"Run already started ({self.run.state})")
        self.run.state = RunState.RUNNING
        self.run.started_at = datetime.now(UTC)
        self.db.commit()
        self.advance()
        return self.run

    def pause(self) -> WorkflowRun:
        self.run.state = RunState.PAUSED
        self.db.commit()
        return self.run

    def resume(self) -> WorkflowRun:
        if self.run.state not in (RunState.PAUSED, RunState.AWAITING_APPROVAL):
            raise ConflictError(f"Cannot resume run in state {self.run.state}")
        self.run.state = RunState.RUNNING
        self.db.commit()
        self.advance()
        return self.run

    def cancel(self) -> WorkflowRun:
        self.run.state = RunState.CANCELED
        self.run.finished_at = datetime.now(UTC)
        for step in self.steps():
            if step.status in (StepStatus.PENDING, StepStatus.QUEUED, StepStatus.RUNNING,
                               StepStatus.AWAITING_APPROVAL):
                step.status = StepStatus.CANCELED
        self.db.commit()
        self._publish("workflow_canceled", {"reason": "user"})
        return self.run

    def steps(self) -> list[WorkflowStep]:
        return list(WorkflowStepRepo(self.db).for_run(self.run.id))

    # --- stepping --------------------------------------------------------------

    def advance(self) -> WorkflowRun:
        """Advance as far as possible. Idempotent; safe to call after any event."""
        if self.run.state not in (RunState.RUNNING, RunState.AWAITING_APPROVAL):
            return self.run

        for _ in range(_ADVANCE_CAP):
            if self.run.state not in (RunState.RUNNING, RunState.AWAITING_APPROVAL):
                return self.run
            steps = self.steps()
            sequence = self._sequence()
            step = self._next_pending(steps, sequence)
            if step is None:
                return self._finish()
            if step.status == StepStatus.AWAITING_APPROVAL:
                return self._run_approval(step)
            if step.status in (StepStatus.PENDING, StepStatus.FAILED, StepStatus.RETRYING):
                outcome = self._dispatch(step)
                if outcome is None:  # queued — worker will call back
                    return self._mark_queued(step)
                if "_error" in outcome:  # failure already settled by inline path
                    continue
                self._settle_completed(step, outcome)
                if self._must_gate(step):
                    self.request_approval(step, kind=self._gate_kind(step))
                continue
            return self.run  # RUNNING (async mid-flight) â€” wait for worker

        logger.warning("advance cap reached for run %s", self.run.id)
        return self.run

    def _sequence(self) -> list[str]:
        flow = (self.run.staged_state_json or {}).get("flow", {})
        nodes = flow.get("nodes", [])
        return [n["stage"] for n in nodes if n.get("stage")]

    def _next_pending(self, steps, sequence) -> WorkflowStep | None:
        by_stage = {s.stage: s for s in steps}
        settled = (StepStatus.COMPLETED, StepStatus.SKIPPED, StepStatus.CANCELED, StepStatus.FAILED)
        for stage in sequence:
            step = by_stage.get(stage)
            if not step:
                continue
            if step.status not in settled:
                return step
        return None

    def _mark_queued(self, step: WorkflowStep) -> WorkflowRun:
        step.status = StepStatus.QUEUED
        self.run.state = RunState.RUNNING
        self.run.current_stage = step.stage
        self._record_applied(step, "queued")
        self.db.commit()
        return self.run

    def _run_approval(self, step: WorkflowStep) -> WorkflowRun:
        self.run.state = RunState.AWAITING_APPROVAL
        self.run.current_stage = step.stage
        self.db.commit()
        return self.run

    def _finish(self) -> WorkflowRun:
        if self.run.state == RunState.COMPLETED:
            return self.run  # idempotent — no double quota bumps
        self.run.state = RunState.COMPLETED
        self.run.current_stage = None
        self.run.finished_at = datetime.now(UTC)
        self.db.commit()
        self.bump_video_quota()
        self._publish("workflow_completed", {"run_id": str(self.run.id)})
        return self.run

    def bump_video_quota(self) -> None:
        from app.services.usage_service import UsageService

        try:
            UsageService(self.db).consume(
                org_id=self.run.organization_id, metric="videos", amount=1.0,
                project_id=self.run.project_id, run_id=self.run.id, raise_on_hard=True,
            )
        except Exception as exc:  # pragma: no cover
            logger.warning("quota bump failed: %s", exc)

    # --- worker-facing outcomes ---------------------------------------------

    def mark_step_completed(self, step_id: uuid.UUID, output: dict | None = None,
                            duration_ms: int = 0) -> WorkflowRun:
        step = self.db.get(WorkflowStep, step_id)
        if not step:
            raise NotFoundError("step not found")
        if step.status == StepStatus.COMPLETED:
            return self.run  # idempotent
        self._settle_completed(step, {"output": output or {}, "results": []})
        if self._must_gate(step):
            self.request_approval(step, kind=self._gate_kind(step))
        return self.advance()

    def revise(self, step: WorkflowStep, comment: str | None = None) -> WorkflowRun:
        """Human requested a revision: re-queue the producing stage, re-gate after."""
        state = self.run.staged_state_json or {}
        gates: dict = state.setdefault("gates", {})
        gates[step.stage] = False  # allow a fresh approval request after repro
        producer = self._revision_producer(step.stage)
        producer_step = next((s for s in self.steps() if s.stage == producer), None)
        if producer_step:
            producer_step.status = StepStatus.RETRYING
            producer_step.error = comment or "Revision requested"
        step.status = StepStatus.PENDING
        step.error = comment or "Revision requested"
        self.run.staged_state_json = state
        self.db.commit()
        return self.advance()

    def reject(self, step: WorkflowStep, comment: str | None = None) -> WorkflowRun:
        step.status = StepStatus.FAILED
        self.run.state = RunState.FAILED
        self.run.error = comment or f"Approval rejected for {step.stage}"
        self.run.finished_at = datetime.now(UTC)
        self._record_applied(step, f"rejected: {(comment or '')[:200]}")
        self.db.commit()
        self._publish("workflow_failed", {"step": step.stage, "error": "approval.rejected"})
        return self.run

    def _revision_producer(self, stage: str) -> str:
        from app.workflow.stages import STAGES

        order = [s.stage.value for s in STAGES]
        if stage in order:
            idx = order.index(stage)
            return order[idx - 1] if idx > 0 else stage
        return stage

    def mark_step_failed(self, step_id: uuid.UUID, error: str) -> WorkflowRun:
        step = self.db.get(WorkflowStep, step_id)
        if not step:
            raise NotFoundError("step not found")
        spec = stage_def(step.stage)
        step.error = error
        step.retry_count += 1
        if step.retry_count <= spec.retries:
            step.status = StepStatus.RETRYING
            self._record_applied(step, f"will retry ({step.retry_count}/{spec.retries})")
            self.db.commit()
            return self.advance()
        step.status = StepStatus.FAILED
        self.run.state = RunState.FAILED
        self.run.error = error
        self.run.finished_at = datetime.now(UTC)
        self._record_applied(step, f"failed permanently: {error[:300]}")
        self.db.commit()
        get_bus().publish(
            DomainEvent("workflow_failed", organization_id=str(self.run.organization_id),
                        project_id=str(self.run.project_id), run_id=str(self.run.id),
                        payload={"step": step.stage, "error": error[:300]})
        )
        return self.run

    # --- gates ----------------------------------------------------------------

    def request_approval(self, step: WorkflowStep, *, kind: str, user_id=None) -> None:
        from app.models import ProjectSettings

        settings_row = (
            self.db.query(ProjectSettings)
            .filter(ProjectSettings.project_id == self.run.project_id)
            .first()
        )
        auto = self.run_state_auto() or (settings_row.auto_approve if settings_row else False)
        step.status = StepStatus.AWAITING_APPROVAL if not auto else StepStatus.APPROVED
        self.db.commit()
        ApprovalService(self.db).request(
            org_id=self.run.organization_id,
            project_id=self.run.project_id,
            user_id=user_id or self.run.started_by,
            stage=step.stage,
            payload={"stage": step.stage, "output": step.output_json},
            run_id=self.run.id,
            auto_approve=auto,
        )
        state = self.run.staged_state_json or {}
        state.setdefault("gates", {})[step.stage] = True
        self.run.staged_state_json = state
        self.db.commit()
        if auto:
            self._settle_completed(step, {"output": step.output_json or {}, "results": []})
            self.advance()

    def run_state_auto(self) -> bool:
        return (self.run.staged_state_json or {}).get("automation_mode") == "full"

    def _gate_kind(self, step: WorkflowStep) -> str | None:
        return stage_def(step.stage).approval

    def _must_gate(self, step: WorkflowStep) -> bool:
        if not stage_def(step.stage).approval:
            return False
        gates = (self.run.staged_state_json or {}).get("gates", {})
        return not gates.get(step.stage, False)

    # --- internals --------------------------------------------------------------

    def _dispatch(self, step: WorkflowStep) -> dict | None:
        """Returns outcome dict when executed inline, None when queued asynchronously."""
        from app.workflow.executor import dispatch

        return dispatch(self.db, self.run, step)

    def _settle_completed(self, step: WorkflowStep, outcome: dict | None) -> WorkflowStep:
        outcome = outcome or {}
        results = outcome.get("results", []) or []
        step.status = StepStatus.COMPLETED
        step.output_json = outcome.get("output")
        step.finished_at = datetime.now(UTC)
        self._record_costs(step, results)
        self._record_applied(step, f"completed ({step.stage})")
        self.db.commit()
        return step

    def _record_costs(self, step: WorkflowStep, results: list) -> None:
        from app.services.cost_service import CostService
        from app.services.usage_service import UsageService

        category = CATEGORY_BY_STAGE.get(step.stage, "llm")
        for result in results:
            if not result.usage or not result.ok:
                continue
            try:
                CostService(self.db).record_provider_result(
                    org_id=self.run.organization_id, project_id=self.run.project_id,
                    run_id=self.run.id, step_id=step.id,
                    provider_name=result.provider, result=result, category=category,
                )
                UsageService(self.db).consume(
                    org_id=self.run.organization_id, metric=self._metric(category),
                    amount=result.usage.quantity, unit=result.usage.unit,
                    project_id=self.run.project_id, run_id=self.run.id,
                    provider=result.provider, category=str(category),
                )
            except Exception as exc:  # pragma: no cover
                logger.warning("cost/usage record failed: %s", exc)

    @staticmethod
    def _metric(category: str) -> str:
        return {
            "image": "images", "render": "renders", "storage": "storage_bytes",
            "seo": "tokens", "thumbnail": "images",
        }.get(category, "tokens")

    def _record_applied(self, step: WorkflowStep, message: str) -> None:
        state = self.run.staged_state_json or {}
        applied = state.get("applied_steps", [])
        applied.append({"stage": step.stage, "message": message,
                        "at": datetime.now(UTC).isoformat()})
        state["applied_steps"] = applied[-200:]
        self.run.staged_state_json = state
        self.db.add(self.run)
        self.db.commit()

    def _record_event(self, run_id, kind, message, payload=None):
        from app.models import WorkflowEvent

        self.db.add(WorkflowEvent(run_id=run_id, stage=self.run.current_stage, kind=kind,
                                  message=message, payload_json=payload))
        self.db.commit()

    def _publish(self, kind: str, payload: dict, org_id=None, project_id=None) -> None:
        get_bus().publish(
            DomainEvent(
                kind,
                organization_id=str(org_id or self.run.organization_id),
                project_id=str(project_id or self.run.project_id),
                run_id=str(self.run.id),
                payload=payload,
            )
        )


def advance_run_after_step(db, run_id, step_id, output=None) -> WorkflowRun:
    return RunController(db, WorkflowRunRepo(db).get(run_id)).mark_step_completed(step_id, output)


def advance_run_after_approval(db, run_id) -> WorkflowRun:
    run = WorkflowRunRepo(db).get(run_id)
    ctl = RunController(db, run)
    for step in ctl.steps():
        if step.status == StepStatus.APPROVED and ctl.run.current_stage == step.stage:
            step.status = StepStatus.COMPLETED
    db.commit()
    return ctl.resume()


def register_approval_handler():
    """Subscribe the engine to approval_completed events (worker and api share taps)."""
    bus = get_bus()

    def _on_approval(event: DomainEvent) -> None:
        pass  # handled transactionally by the API route's database session

    bus.subscribe("approval_completed", _on_approval)


def ts() -> str:
    return datetime.now(UTC).isoformat()
