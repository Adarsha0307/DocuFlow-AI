"""Event wiring: domain events -> engine operations (approval decisions, etc.).

These handlers run in-process alongside the API; a worker or Temporal worker
would replace the call site, not the engine logic.
"""

import logging
import uuid

from app.db.session import SessionLocal
from app.events.bus import DomainEvent, get_bus
from app.models import WorkflowRun
from app.models.enums import RunState, StepStatus
from app.repositories.workflow_repo import WorkflowStepRepo
from app.workflow.engine import RunController, advance_run_after_approval

logger = logging.getLogger("docuflow.events")


def apply_approval_decision(db, run_id: uuid.UUID, stage: str | None) -> None:
    """Flip gated steps to APPROVED and advance the run (shared, idempotent).

    Called synchronously by the API upon a decision AND by the event handler
    (which reaches the API through the bus). Advancing synchronously removes
    the read-after-write race that an async-only flip introduced.
    """
    run = db.query(WorkflowRun).filter(WorkflowRun.id == run_id).first()
    if not run or run.state == RunState.COMPLETED:
        return
    ctl = RunController(db, run)
    flipped = False
    for s in ctl.steps():
        if s.status == StepStatus.AWAITING_APPROVAL and (stage is None or s.stage == stage):
            s.status = StepStatus.APPROVED
            flipped = True
    if flipped:
        db.commit()
    advance_run_after_approval(db, run_id)


def on_approval_completed(event: DomainEvent) -> None:
    run_id = event.run_id
    if not run_id:
        return
    decision = (event.payload or {}).get("decision", "approved")
    stage = (event.payload or {}).get("stage")
    comment = (event.payload or {}).get("comment")
    db = SessionLocal()
    try:
        parsed_id = uuid.UUID(run_id)
        if decision in ("approved", "auto_approved"):
            apply_approval_decision(db, parsed_id, stage)
        else:
            step = WorkflowStepRepo(db).by_stage(parsed_id, stage) if stage else None
            run = db.query(WorkflowRun).filter(WorkflowRun.id == parsed_id).first()
            if run and step:
                ctl = RunController(db, run)
                if decision == "revision_requested":
                    ctl.revise(step, comment)
                elif decision == "rejected":
                    ctl.reject(step, comment)
    except Exception:  # pragma: no cover
        logger.exception("approval event handling failed for run %s", run_id)
    finally:
        db.close()


def register_event_handlers() -> None:
    get_bus().subscribe("approval_completed", on_approval_completed)
