﻿"""Dispatch layer: the only place the engine touches the broker.

- ``workflow_engine == "celery"``: a Celery task executes the activity and the
  worker calls back into ``RunController.mark_step_completed``. Returns ``None``
  (= queued) so the engine marks the step QUEUED and waits.
- otherwise (tests / local dev without a broker): the activity runs inline and
  the outcome dict is returned; the engine settles the step synchronously.
  A Temporal rewrite only changes this module's ``dispatch``.
"""

import uuid
from datetime import UTC, datetime

from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.logging import get_logger
from app.models import WorkflowRun, WorkflowStep
from app.workflow.handlers import execute_activity

logger = get_logger("docuflow.executor")


def dispatch(db: Session, run: WorkflowRun, step: WorkflowStep) -> dict | None:
    """Run (or queue) the step's activity.

    Returns the outcome dict (inline execution) or None (queued async).
    """
    from app.workflow.stages import stage_def

    if stage_def(step.stage).queue == "internal":
        return execute_inline(db, run, step)
    if get_settings().workflow_engine == "celery":
        try:
            send_async(step)
        except Exception as exc:  # broker unavailable â€” fall back to inline
            logger.warning("async dispatch failed (%s); falling back to inline", exc)
            return execute_inline(db, run, step)
        return None
    return execute_inline(db, run, step)


from celery import Celery  # noqa: E402

_send_app: "Celery | None" = None


def send_async(step: WorkflowStep) -> None:
    """Enqueue the activity to the broker; the worker settles via mark_step_completed."""
    from celery import Celery

    global _send_app
    if _send_app is None:
        from app.core.config import get_settings

        _send_app = Celery("docuflow_api", broker=get_settings().redis_url, backend=get_settings().redis_url)

    _send_app.send_task(
        "docuflow.execute_stage",
        args=[str(step.run_id), str(step.id)],
        queue="workflow",
        task_id=str(uuid.uuid4()),
    )


def execute_inline(db: Session, run: WorkflowRun, step: WorkflowStep) -> dict:
    """Run the activity in-process; on failure settle via the engine, no retry loop."""
    from app.workflow.engine import RunController

    step.status = "running"
    step.started_at = datetime.now(UTC)
    db.commit()
    try:
        return execute_activity(db, run, step)
    except Exception as exc:
        logger.exception("inline execution failed for %s/%s", run.id, step.stage)
        RunController(db, run).mark_step_failed(step.id, str(exc))
        return {"_error": str(exc)}


def execute_step_task(db: Session, run_id: uuid.UUID, step_id: uuid.UUID) -> str:
    """Entry point for the Celery worker: run the activity and settle the step."""
    from app.models import WorkflowRun
    from app.workflow.engine import RunController

    run = db.get(WorkflowRun, run_id)
    step = db.get(WorkflowStep, step_id)
    if not run or not step:
        raise ValueError("run/step not found")

    try:
        outcome = execute_activity(db, run, step)
        db.expire_all()
        return str(RunController(db, run).mark_step_completed(step.id, outcome.get("output")).state)
    except Exception as exc:
        logger.exception("worker execution failed for %s/%s", run_id, step_id)
        return str(RunController(db, run).mark_step_failed(step_id, str(exc)).state)
