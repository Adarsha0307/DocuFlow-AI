﻿"""Stage handlers ("activities") â€” one callable per pipeline stage.

Each handler produces the durable output stored on the step; providers return
`ProviderResult`s so the executor can record costs/usage. Handlers never mutate
run state â€” the engine owns that â€” so a Temporal rewrite drops right in.
"""

import json
import os
import re
import time
from dataclasses import dataclass, field

from sqlalchemy.orm import Session

from app.core.logging import get_logger
from app.models import Project, ProjectSettings, WorkflowRun, WorkflowStep
from app.models.enums import CreditCategory
from app.providers.base import ProviderResult
from app.providers.registry import get_registry

logger = get_logger("docuflow.handlers")

CATEGORY_BY_STAGE = {
    "topic_ideation": CreditCategory.LLM,
    "research_collection": CreditCategory.LLM,
    "fact_structuring": CreditCategory.LLM,
    "script_generation": CreditCategory.LLM,
    "script_review": CreditCategory.LLM,
    "scene_planning": CreditCategory.LLM,
    "prompt_generation": CreditCategory.LLM,
    "image_generation": CreditCategory.IMAGE,
    "image_qa": CreditCategory.LLM,
    "voiceover_generation": CreditCategory.TTS,
    "subtitle_generation": CreditCategory.STT,
    "music_prep": CreditCategory.LLM,
    "timeline_assembly": CreditCategory.LLM,
    "render": CreditCategory.RENDER,
    "thumbnail_generation": CreditCategory.IMAGE,
    "seo_generation": CreditCategory.LLM,
    "upload_preparation": CreditCategory.UPLOAD,
    "upload": CreditCategory.UPLOAD,
    "analytics_sync": CreditCategory.LLM,
    "retention_feedback": CreditCategory.LLM,
}


@dataclass
class HandlerContext:
    db: Session
    run: WorkflowRun
    step: WorkflowStep
    project: Project | None = None
    settings: ProjectSettings | None = None
    org_defaults: dict = field(default_factory=dict)

    @classmethod
    def from_step(cls, db: Session, run: WorkflowRun, step: WorkflowStep) -> "HandlerContext":
        project = db.get(Project, run.project_id) if run.project_id else None
        settings = None
        if run.project_id:
            settings = (
                db.query(ProjectSettings).filter(ProjectSettings.project_id == run.project_id).first()
            )
        return cls(
            db=db, run=run, step=step, project=project, settings=settings,
            org_defaults=settings.provider_defaults_json if settings else {},
        )

    @property
    def topic(self) -> str:
        return (self.run.staged_state_json or {}).get("topic") or "Untold Story"

    def memory(self) -> dict:
        return (self.run.staged_state_json or {}).get("memory", {})

    def stage_output(self, stage: str) -> dict:
        prior = (
            self.db.query(WorkflowStep)
            .filter(
                WorkflowStep.run_id == self.run.id,
                WorkflowStep.stage == stage,
                WorkflowStep.status == "completed",
            )
            .first()
        )
        return (prior.output_json or {}) if prior else {}

    def stage(self, stage: str) -> dict:
        return self.stage_output(stage)

    def plan(self, stage: str) -> dict:
        return self.stage_output(stage)

    def script(self, stage: str) -> dict:
        return self.stage_output(stage)


def llm(ctx: HandlerContext, system: str, user: str, *, temperature=0.7,
        max_tokens=1024, capability="llm") -> ProviderResult:
    provider = resolve_provider(ctx, capability)
    return provider.complete(
        [{"role": "user", "content": user}], system=system,
        temperature=temperature, max_tokens=max_tokens,
    )


def resolve_provider(ctx: HandlerContext, capability: str):
    """Pick the best healthy provider for a capability; mock fallback in dev."""
    registry = get_registry()
    try:
        provider = registry.resolve(capability, org_defaults=ctx.org_defaults)
        if provider.check_health().ok:
            return provider
    except Exception:  # noqa: BLE001
        pass
    for cap in (capability, "llm"):
        try:
            provider = registry.get(cap, "mock")
            if provider.check_health().ok:
                return provider
        except (KeyError, ValueError):
            continue
    raise ValueError(f"no healthy provider for capability '{capability}'")


def text_of(res: ProviderResult) -> str:
    data = res.data
    if isinstance(data, dict):
        return str(data.get("content", "") or "")
    return str(data or "")


def extract_json(text: str) -> dict:
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if not match:
        return {}
    try:
        return json.loads(match.group(0))
    except json.JSONDecodeError:
        return {}


def word_count(text: str) -> int:
    return len([w for w in re.split(r"\s+", text or "") if w])


def _scenes_promo(ctx) -> list[dict]:
    return ctx.stage_output("scene_planning").get("scenes", [])


def next_seed(ctx) -> str:
    return f"{ctx.run.id}-{ctx.step.stage}-{int(time.time() * 1000)}"


# --- stage implementations ------------------------------------------------


def handle_topic_ideation(ctx) -> dict:
    user = (
        f"Propose a viral 6-9 minute 2D documentary topic for a faceless channel. "
        f"Context: {ctx.memory() or 'new documentary channel'}."
        "Return JSON with keys: topic, angle, hook, audience."
    )
    res = llm(ctx, "You are a documentary topic strategist.", user)
    payload = extract_json(text_of(res))
    return {"output": {**payload, "topic": payload.get("topic") or ctx.topic}, "results": [res]}


def handle_research(ctx) -> dict:
    topic = ctx.stage_output("topic_ideation").get("topic") or ctx.topic
    res = llm(
        ctx,
        "You are a documentary researcher.",
        f"Collect 8-12 primary and secondary sources for the topic: {topic}. "
        "Return JSON with keys: sources (list of {title, url_or_notebook, excerpt, credibility(0-1)}).",
        max_tokens=1600,
    )
    payload = extract_json(text_of(res))
    sources = payload.get("sources", [])
    return {
        "output": {
            "sources": sources,
            "source_count": len(sources),
            "credibility_avg": round(
                sum(s.get("credibility", 0.5) for s in sources) / max(1, len(sources)), 2
            ),
        },
        "results": [res],
    }


def handle_fact_structuring(ctx) -> dict:
    sources = ctx.stage_output("research_collection").get("sources", [])
    res = llm(
        ctx,
        "You are a strict fact-checker.",
        f"Structure the research into dated facts. Sources: {json.dumps(sources)[:2000]}. "
        "Return JSON with keys: facts (list of {claim, support, verified(bool), source_index}), timeline.",
        max_tokens=1800,
    )
    payload = extract_json(text_of(res))
    facts = payload.get("facts", [])
    return {
        "output": {
            "facts": facts,
            "verified_count": len([f for f in facts if f.get("verified")]),
            "timeline": payload.get("timeline", []),
        },
        "results": [res],
    }


def handle_script_generation(ctx) -> dict:
    facts = ctx.stage("fact_structuring").get("facts", [])
    topic = ctx.stage("topic_ideation").get("topic") or ctx.topic
    res = llm(
        ctx,
        "You are a documentary scriptwriter for short-form video.",
        f"Write a 6-9 minute two-column script (visuals + VO) for: {topic}. "
        f"Facts: {json.dumps(facts)[:2000]}. Return markdown with sections and a script_v2 JSON.",
        max_tokens=2400,
    )
    content = text_of(res)
    secs = len(re.findall(r"(?m)^##\s", content)) or 1
    return {
        "output": {
            "script_md": content,
            "word_count": word_count(content),
            "sections": secs,
            "estimated_duration_s": max(120, int(word_count(content) / 2.4)),
            "script_v2": {"urns": []},
        },
        "results": [res],
    }


def handle_script_review(ctx) -> dict:
    prior = ctx.stage("script_generation")
    script = prior.get("script_md", "")
    stats = {
        "word_count": prior.get("word_count", word_count(script)),
        "sections": prior.get("sections", 1),
        "has_hook": bool(re.search(r"(?m)^##\s*Hook", script)),
        "has_closer": bool(re.search(r"(?m)^##\s*Closer|subscribe", script, re.I)),
        "estimated_duration_s": prior.get("estimated_duration_s"),
    }
    issues = []
    if not stats["has_hook"]:
        issues.append("No Hook section found")
    if not stats["has_closer"]:
        issues.append("No Closer / CTA found")
    if stats["word_count"] < 300:
        issues.append("Script under 300 words")
    verdict = "needs_revision" if issues else "approved"
    flat = {k: v for k, v in stats.items() if isinstance(v, (int, float, bool))}
    return {
        "output": {"verdict": verdict, "issues": issues, "review_stats": flat},
        "results": [],
    }


def handle_scene_planning(ctx) -> dict:
    script = ctx.stage("script_generation").get("script_md", "")
    res = llm(
        ctx,
        "You are a storyboard director for 2D animation.",
        f"Break the script into 10-14 scenes: {script[:1500]}. "
        "Return JSON with scenes: [{duration_s, visuals, motion, camera, narration}].",
        max_tokens=2000,
    )
    payload = extract_json(text_of(res))
    return {
        "output": {"scenes": payload.get("scenes", []), "scene_count": len(payload.get("scenes", []))},
        "results": [res],
    }


def handle_prompt_generation(ctx) -> dict:
    scenes = ctx.plan("scene_planning").get("scenes", [])
    res = llm(
        ctx,
        "You write production-ready image prompts for 2D documentary illustration.",
        f"Produce one prompt per scene: {json.dumps(scenes)[:2000]}. "
        "Return JSON: {prompts: [{scene_index, negative, prompt}], style_uniformity: str}",
        max_tokens=2400,
    )
    prompts = extract_json(text_of(res)).get("prompts", [])
    for i, prompt in enumerate(prompts):
        prompt["seed"] = f"{ctx.run.id}-{i}"
    return {"output": {"prompts": prompts, "prompt_count": len(prompts)}, "results": [res]}


def handle_image_generation(ctx) -> dict:
    prompts = ctx.plan("prompt_generation").get("prompts", [])
    provider = resolve_provider(ctx, "image")
    images = []
    results = []
    for spec in prompts:
        res = provider.generate(
            spec.get("prompt", ""), negative_prompt=spec.get("negative"), samples=1
        )
        results.append(res)
        if res.ok:
            data = res.data or {}
            images.append(
                {
                    "scene": spec.get("scene", len(images)),
                    "asset_key": persist_gen_image(ctx, data) or f"mock:{len(images)}",
                    "seed": spec.get("seed"),
                    "mime_type": data.get("mime_type", "image/png"),
                }
            )
    return {"output": {"images": images, "image_count": len(images)}, "results": results}


def persist_gen_image(ctx, data: dict) -> str | None:
    try:
        from app.services.storage_service import asset_key, get_storage

        payload = data.get("bytes")
        if payload is None:
            return None
        key = asset_key(org_id=ctx.run.organization_id, project_id=ctx.run.project_id,
                        kind="image", name=f"{ctx.run.id}/{next_seed(ctx)}")
        url = get_storage().put_bytes(key, payload, data.get("mime_type", "image/png"))
        return str(url or key)
    except Exception as exc:  # pragma: no cover
        logger.warning("image persist failed: %s", exc)
        return None


def handle_image_qa(ctx) -> dict:
    images = ctx.stage("image_generation").get("images", [])
    ok = True
    score = 0.6
    if images:
        system = "You are an image QC reviewer for documentary visuals."
        user = (
            "Score each scene image 0-1 for relevance, resolution-consistency and artefact safety. "
            "Return JSON {scores: [{scene, score, notes}]}. Flag any score under 0.7 as must-refresh."
        )
        res = llm(ctx, system, user, max_tokens=1200)
        payload = extract_json(text_of(res))
        for img, review in zip(images, payload.get("scores", []), strict=False):
            img["score"] = min(1.0, float(review.get("score", 0.6)))
            img["notes"] = review.get("notes", "")
        ok = all((img.get("score") or 0) >= 0.7 for img in images)
        score = sum((img.get("score") or 0) for img in images) / len(images)
    return {
        "output": {
            "images": images,
            "average_score": round(score, 2),
            "verdict": "pass" if ok else "refresh_required",
        },
        "results": [res] if images else [],
    }


def handle_voiceover_generation(ctx) -> dict:
    script = ctx.script("script_generation").get("script_md", "")
    provider = resolve_provider(ctx, "tts")
    chunks = [c for c in re.split(r"\n{2,}", script or "") if c.strip()][:12]
    tracks, results = [], []
    voice = getattr(ctx.settings, "voice", None) or "default"
    for i, chunk in enumerate(chunks):
        res = provider.synthesize(chunk[:1400], voice=voice)
        results.append(res)
        if res.ok:
            tracks.append({"idx": i, "asset_key": f"tts/{ctx.run.id}/{i}.mp3", "duration_hint": len(chunk) // 15})
    return {
        "output": {"tracks": tracks, "total_tracks": len(tracks), "voice": "default"},
        "results": results,
    }


def handle_subtitle_generation(ctx) -> dict:
    tracks = ctx.stage("voiceover_generation").get("tracks", [])
    provider = resolve_provider(ctx, "stt")
    subs = []
    results = []
    for _t in tracks:
        res = provider.transcribe(b"")
        results.append(res)
        text = (res.data or {}).get("text", "") if res.ok else ""
        for word in text.split():
            subs.append({"w": word, "s": len(subs) * 0.28, "e": (len(subs) + 1) * 0.28})
    return {
        "output": {"segments": subs, "segments_count": len(subs), "format": "srt"},
        "results": results,
    }


def handle_music_prep(ctx) -> dict:
    res = llm(
        ctx,
        "Music director house style: minimal cinematic, no dialogue clash.",
        "Suggest 3 royalty-free music tracks + SFX options. Return JSON {options: [{title, mood, bpm, license}]}",
        max_tokens=800,
    )
    options = extract_json(text_of(res)).get("options", [])
    return {
        "output": {"options": options, "selected": options[0] if options else None},
        "results": [res],
    }


def handle_timeline_assembly(ctx) -> dict:
    scenes = ctx.plan("scene_planning").get("scenes", [])
    images = ctx.stage("image_generation").get("images", [])
    voice = ctx.stage("voiceover_generation").get("tracks", [])
    subs = ctx.stage("subtitle_generation").get("segments", [])
    music = ctx.stage("music_prep").get("selected")
    timeline = []
    for i, scene in enumerate(scenes):
        timeline.append(
            {
                "scene": i,
                "visual": images[i].get("asset_key") if i < len(images) else None,
                "audio": voice[i].get("asset_key") if i < len(voice) else None,
                "duration_s": scene.get("duration_s", 20),
                "motion": scene.get("motion", "still"),
            }
        )
    commands = [
        "ffmpeg -y -f concat -safe 0 -i manifest.txt -c copy out.mp4",
        f"ffmpeg -i out.mp4 -i {music['name'] if music else 'music_lofi.wav'} -c:v copy -c:a aac mix.mp4",
    ]
    return {
        "output": {
            "timeline": timeline,
            "total_duration_s": sum(s.get("duration_s", 0) for s in timeline),
            "subtitle_segments": subs,
            "render_manifest": commands,
        },
        "results": [],
    }


def handle_render(ctx) -> dict:
    from app.providers.base import Usage

    timeline = ctx.stage("timeline_assembly")
    provider = resolve_provider(ctx, "media")
    output_path = f"media/tmp/{ctx.run.id}.mp4"
    prev = None

    def on_progress(p):
        nonlocal prev
        if p and p != prev:
            prev = p
            logger.info("render %s: %s", ctx.run.id, p)

    try:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        res = provider.render(
            scene_specs=timeline.get("timeline", []),
            output_path=output_path,
            preset="1080p",
            on_progress=on_progress,
        )
    except Exception as exc:  # renders need real media assets; degrade gracefully offline
        logger.warning("render provider failed (%s); writing manifest instead", exc)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write("mock render manifest")
        res = ProviderResult(
            ok=True, data={"output": output_path}, provider="mock",
            capability="media", usage=Usage(quantity=0, unit="render_seconds"),
            meta={"mock": True, "reason": str(exc)[:200]},
        )
    return {
        "output": {
            "file_path": output_path,
            "duration_s": timeline.get("total_duration_s", 300),
            "render_status": "completed" if res.ok else "failed",
        },
        "results": [res],
    }


def handle_thumbnail_generation(ctx) -> dict:
    project_title = ctx.project.name if ctx.project else (ctx.topic or "Documentary")
    hooks = [s.get("hook") for s in ctx.plan("scene_planning").get("scenes", []) if s.get("hook")]
    res = llm(
        ctx,
        "Thumbnail copywriter for faceless documentaries.",
        f"Create 3 short engaging thumbnail text overlays for: {project_title}. "
        f"Hooks: {', '.join(hooks) or 'The Hidden Truth'}",
        temperature=0.8, max_tokens=400,
    )
    text_lines = [line for line in text_of(res).splitlines() if line.strip()][:3]
    return {
        "output": {
            "variants": [
                {"id": i, "text": line, "style": f"style_{i}"} for i, line in enumerate(text_lines)
            ]
        },
        "results": [res],
    }


def handle_seo_generation(ctx) -> dict:
    topic = ctx.stage("topic_ideation").get("topic") or ctx.topic
    script = ctx.script("script_generation").get("script_md", "")
    res = llm(
        ctx,
        "YouTube SEO strategist.",
        f"Produce JSON with keys: title, description, tags, keywords, category_id "
        f"for a documentary video about {topic}. Return valid JSON only. "
        f"Script preview: {script[:1200]}",
        temperature=0.6, max_tokens=800,
    )
    payload = extract_json(text_of(res))
    return {"output": payload, "results": [res]}


def handle_upload_preparation(ctx) -> dict:
    seo = ctx.stage("seo_generation")
    if not seo:
        raise ValueError("SEO metadata missing before upload preparation")
    title = seo.get("title") or f"{ctx.topic} - The Untold Story"
    return {
        "output": {
            "title": title,
            "description": seo.get("description", ""),
            "tags": seo.get("tags", [])[:3],
            "category_id": seo.get("category_id", "27"),
            "visibility": "public",
            "file_path": ctx.stage("render").get("file_path"),
            "thumbnail": ctx.stage("thumbnail_generation").get("variants", [{}])[0].get("id"),
        },
        "results": [],
    }


def handle_upload(ctx) -> dict:
    prep = ctx.stage("upload_preparation")
    provider = resolve_provider(ctx, "upload")
    start = provider.start_upload(
        title=prep.get("title", "Untitled"), description=prep.get("description", ""),
        tags=prep.get("tags"), visibility=prep.get("visibility", "private"),
        publish_at=None,
    )
    output = {"session_id": start.data.get("session_id") if start.ok else None, "start_ok": start.ok}
    res = provider.finish_upload(
        output.get("session_id", ""), thumbnail_bytes=None
    )
    output["video_id"] = res.data.get("external_video_id") if res.ok else None
    output["channel"] = res.data.get("channel") if res.ok else "My Studio"
    return {"output": output, "results": [start, res]}


def handle_analytics_sync(ctx) -> dict:
    return {"output": {"synced": False, "status": "waiting_24h", "delay_h": 24}, "results": []}


def handle_retention_feedback(ctx) -> dict:
    res = llm(
        ctx,
        "Retention analyst.",
        "Write 3 lessons for improving retention on faceless documentaries. Return JSON {lessons: []}",
        max_tokens=600,
    )
    return {
        "output": {"lessons": extract_json(text_of(res)).get("lessons", [])},
        "results": [res],
    }


HANDLERS: dict[str, callable] = {
    "topic_ideation": handle_topic_ideation,
    "research_collection": handle_research,
    "fact_structuring": handle_fact_structuring,
    "script_generation": handle_script_generation,
    "script_review": handle_script_review,
    "scene_planning": handle_scene_planning,
    "prompt_generation": handle_prompt_generation,
    "image_generation": handle_image_generation,
    "image_qa": handle_image_qa,
    "voiceover_generation": handle_voiceover_generation,
    "subtitle_generation": handle_subtitle_generation,
    "music_prep": handle_music_prep,
    "timeline_assembly": handle_timeline_assembly,
    "render": handle_render,
    "thumbnail_generation": handle_thumbnail_generation,
    "seo_generation": handle_seo_generation,
    "upload_preparation": handle_upload_preparation,
    "upload": handle_upload,
    "analytics_sync": handle_analytics_sync,
    "retention_feedback": handle_retention_feedback,
}


def execute_activity(db: Session, run: WorkflowRun, step: WorkflowStep) -> dict:
    """Run the stage's handler; returns the durable output dict."""
    handler = HANDLERS[step.stage]
    ctx = HandlerContext.from_step(db, run, step)
    outcome = handler(ctx)
    return outcome
