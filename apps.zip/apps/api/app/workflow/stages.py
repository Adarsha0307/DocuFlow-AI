﻿"""Workflow stage registry: durable execution units of the production pipeline.

The pipeline is a DAG of stages. Each stage maps to:
- an activity function (business logic, imported by workers)
- optional provider capability (which AI adapters are involved)
- optional human approval checkpoint
- exporter needs (what domain artifacts it produces/stores)
"""

from dataclasses import dataclass, field

from app.models.enums import StageCode


@dataclass(frozen=True)
class StageDef:
    stage: StageCode
    label: str
    capability: str  # provider capability or "internal"
    activity: str  # symbolic task name (routing key for workers)
    queue: str  # worker queue
    approval: str | None = None  # approval kind if this stage gates on human review
    needs_content: list[str] = field(default_factory=list)  # stage outputs it consumes
    produces: str | None = None  # primary domain artifact (script, scenes, assets, ...)
    retries: int = 2
    timeout_seconds: int = 1800


STAGES: list[StageDef] = [
    StageDef(StageCode.TOPIC_IDEATION, "Topic ideation", "llm", "generate_topic", "ai"),
    StageDef(StageCode.RESEARCH_COLLECTION, "Research collection", "llm", "gather_research", "ai"),
    StageDef(StageCode.FACT_STRUCTURING, "Fact structuring", "llm", "summarize_research", "ai"),
    StageDef(StageCode.SCRIPT_GENERATION, "Script generation", "llm", "generate_script", "ai"),
    StageDef(StageCode.SCRIPT_REVIEW, "Script review", "internal", "script_review", "default",
             approval="script"),
    StageDef(StageCode.SCENE_PLANNING, "Scene planning", "llm", "generate_storyboard", "ai"),
    StageDef(StageCode.PROMPT_GENERATION, "Prompt generation", "llm", "generate_scene_prompts", "ai"),
    StageDef(StageCode.IMAGE_GENERATION, "Image generation", "image", "generate_images", "ai"),
    StageDef(StageCode.IMAGE_QA, "Image QA", "llm", "score_images", "ai",
             approval="image_set"),
    StageDef(StageCode.VOICEOVER_GENERATION, "Voiceover generation", "tts", "generate_voiceover", "ai",
             approval="voiceover_sample"),
    StageDef(StageCode.SUBTITLE_GENERATION, "Subtitle generation", "stt", "generate_subtitles", "ai"),
    StageDef(StageCode.MUSIC_PREP, "Music & SFX", "internal", "collect_music_options", "ai"),
    StageDef(StageCode.TIMELINE_ASSEMBLY, "Timeline assembly", "internal", "assemble_timeline", "worker"),
    StageDef(StageCode.RENDER, "Render", "media", "render_final_video", "worker",
             approval="final_render"),
    StageDef(StageCode.THUMBNAIL_GENERATION, "Thumbnail", "thumbnail", "generate_thumbnail", "ai",
             approval="thumbnail"),
    StageDef(StageCode.SEO_GENERATION, "SEO metadata", "seo", "generate_metadata", "ai",
             approval="metadata"),
    StageDef(StageCode.UPLOAD_PREPARATION, "Upload preparation", "internal", "validate_upload_payload", "worker"),
    StageDef(StageCode.UPLOAD, "Upload", "upload", "upload_youtube", "worker",
             approval="upload"),
    StageDef(StageCode.ANALYTICS_SYNC, "Analytics sync", "internal", "sync_analytics", "worker"),
    StageDef(StageCode.RETENTION_FEEDBACK, "Retention feedback", "llm", "compose_feedback", "worker"),
]

STAGE_MAP: dict[str, StageDef] = {s.stage.value: s for s in STAGES}

# Which prior stages a given stage depends on (linear documentary pipeline by default).
DEFAULT_ORDER: list[str] = [s.stage.value for s in STAGES]

APPROVAL_AS_NODE: dict[str, str] = {
    s.stage.value: k for s in STAGES if (k := s.approval)
}


def stage_def(stage: str) -> StageDef:
    return STAGE_MAP[stage]


def provider_capability(stage: str) -> str:
    return STAGE_MAP[stage].capability
