import os
import sys
import tempfile
import uuid
from datetime import datetime

os.environ["DATABASE_URL"] = "sqlite:///" + os.path.join(tempfile.gettempdir(), "docuflow_dbg.db")
os.environ["WORKFLOW_ENGINE"] = "local"

from fastapi.testclient import TestClient  # noqa: E402
from sqlalchemy import text  # noqa: E402

from app.db.base import Base  # noqa: E402
from app.db.session import engine  # noqa: E402
from app.main import app  # noqa: E402
from app.models import Membership, Organization, Project  # noqa: E402

Base.metadata.drop_all(engine)
Base.metadata.create_all(engine)
org = uuid.uuid4()
user = uuid.uuid4()
proj = uuid.uuid4()
now = datetime.utcnow()
with engine.begin() as c:
    c.execute(Organization.__table__.insert().values(id=org, name="O", slug="o", created_by=user))
    c.execute(
        Project.__table__.insert().values(
            id=proj, organization_id=org, name="P", topic="t", created_at=now, updated_at=now
        )
    )
    c.execute(
        Membership.__table__.insert().values(
            id=uuid.uuid4(), organization_id=org, user_id=user,
            role="owner", status="active", created_at=now, updated_at=now,
        )
    )

with TestClient(app) as client:
    h = {"X-Org-Id": str(org), "X-User-Id": str(user)}
    defs = client.get("/api/v1/workflow-definitions", headers=h).json()
    d = [x for x in defs if x["slug"] == "default_documentary_2d"][0]
    r = client.post(
        f"/api/v1/projects/{proj}/runs",
        json={"definition_id": d["id"], "automation_mode": "manual"},
        headers=h,
    )
    print("create", r.status_code)
    rid = r.json()["id"]
    steps = client.get(f"/api/v1/runs/{rid}/steps", headers=h)
    print("steps", steps.status_code, steps.json())
    appr = client.get("/api/v1/approvals/pending", headers=h)
    print("pending", appr.status_code, appr.json())
    with engine.connect() as c:
        for t in ("approvals", "workflow_steps", "workflow_runs"):
            rows = c.execute(text(f"SELECT * FROM {t}")).fetchall()
            print("TABLE", t, len(rows))
            for row in rows[:5]:
                print("  ", dict(row._mapping))