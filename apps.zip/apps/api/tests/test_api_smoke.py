"""API smoke tests: app assembly, org envelope, full run lifecycle via HTTP."""

import os
import tempfile
import uuid
from datetime import UTC, datetime

os.environ["DATABASE_URL"] = "sqlite:///" + os.path.join(tempfile.gettempdir(), "docuflow_smoke.db")
os.environ["WORKFLOW_ENGINE"] = "local"

from fastapi.testclient import TestClient  # noqa: E402

from app.db.base import Base  # noqa: E402
from app.db.session import engine  # noqa: E402
from app.main import app  # noqa: E402
from app.models import Membership, Organization, Project  # noqa: E402

ORG_ID = uuid.uuid4()
USER_ID = uuid.uuid4()
PROJECT_ID = uuid.uuid4()
NOW = datetime.now(UTC)


def _fresh_db() -> None:
    engine.dispose()
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    with engine.begin() as conn:
        conn.execute(
            Organization.__table__.insert().values(
                id=ORG_ID, name="Smoke Studio", slug="smoke-studio", created_by=USER_ID
            )
        )
        conn.execute(
            Membership.__table__.insert().values(
                id=uuid.uuid4(),
                organization_id=ORG_ID,
                user_id=USER_ID,
                role="owner",
                status="active",
                created_at=NOW,
                updated_at=NOW,
            )
        )
        conn.execute(
            Project.__table__.insert().values(
                id=PROJECT_ID,
                organization_id=ORG_ID,
                name="Smoke Doc",
                topic="Deep sea",
                created_at=NOW,
                updated_at=NOW,
            )
        )


_fresh_db()

import pytest  # noqa: E402


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as test_client:
        yield test_client


def _payload(client: TestClient) -> dict:
    r = client.get("/api/v1/workflow-definitions", headers={"X-Org-Id": str(ORG_ID)})
    assert r.status_code == 200, r.text
    defaults = [d for d in r.json() if d["slug"] == "default_documentary_2d"]
    assert defaults, r.text
    return {"definition_id": defaults[0]["id"], "automation_mode": "manual"}


def test_health_and_readyz(client: TestClient) -> None:
    assert client.get("/health").json()["status"] == "ok"
    assert client.get("/readyz").json() == {"status": "ready", "database": "up"}
    assert client.get("/metrics").headers["content-type"].startswith("text/plain")


def test_org_header_required(client: TestClient) -> None:
    r = client.get("/api/v1/runs/00000000-0000-0000-0000-000000000000")
    assert r.status_code == 401, r.text


def test_create_run_and_full_approval_walk(client: TestClient) -> None:
    headers = {"X-Org-Id": str(ORG_ID), "X-User-Id": str(USER_ID)}
    r = client.post(f"/api/v1/projects/{PROJECT_ID}/runs", json=_payload(client), headers=headers)
    assert r.status_code == 201, r.text
    run_id = r.json()["id"]

    for _ in range(30):
        detail = client.get(f"/api/v1/runs/{run_id}", headers=headers)
        assert detail.status_code == 200, detail.text
        run = detail.json()
        if run["state"] == "completed":
            break
        assert run["state"] in {"running", "awaiting_approval"}, run["state"]
        assert any(s["status"] == "awaiting_approval" for s in run["steps"]), (
            f"no gated step; state={run['state']} current={[(s['stage'], s['status']) for s in run['steps'] if s['status'] != 'completed']}"
        )

        pending = client.get("/api/v1/approvals/pending", headers=headers).json()
        assert pending, f"expected pending approvals; state={run['state']} steps={[(s['stage'], s['status']) for s in run['steps']]}"
        for a in pending:
            dec = client.post(
                f"/api/v1/approvals/{a['id']}/decision",
                json={"decision": "approved"},
                headers=headers,
            )
            assert dec.status_code == 200, f"decision {a['id'][:8]} failed: {dec.text}"

    assert run["state"] == "completed", run["state"]
    assert all(s["status"] == "completed" for s in run["steps"]), run["steps"]


def test_foreign_org_cannot_see_run(client: TestClient) -> None:
    r = client.post(
        f"/api/v1/projects/{PROJECT_ID}/runs",
        json=_payload(client),
        headers={"X-Org-Id": str(uuid.uuid4()), "X-User-Id": str(USER_ID)},
    )
    assert r.status_code == 404, r.text


def test_auth_signup_org_project_and_run(client: TestClient) -> None:
    email = f"e2e-{uuid.uuid4().hex[:8]}@example.com"
    sup = client.post(
        "/api/v1/auth/signup",
        json={"email": email, "password": "supersecret123", "name": "E2E User", "org_name": "E2E Studio"},
    )
    assert sup.status_code == 201, sup.text
    token = sup.json()["token"]
    org_id = sup.json()["organization"]["id"]

    auth = {"Authorization": f"Bearer {token}", "X-Org-Id": org_id}
    me = client.get("/api/v1/auth/me", headers=auth)
    assert me.status_code == 200, me.text
    assert any(o["name"] == "E2E Studio" for o in me.json()["organizations"])

    proj = client.post(
        f"/api/v1/orgs/{org_id}/projects",
        json={"name": "E2E Doc", "topic": "Ancient math", "automation_mode": "manual"},
        headers=auth,
    )
    assert proj.status_code == 201, proj.text
    project_id = proj.json()["id"]

    headers = {"X-Org-Id": org_id, "X-User-Id": me.json()["user"]["id"]}
    r = client.post(f"/api/v1/projects/{project_id}/runs", json=_payload(client), headers=headers)
    assert r.status_code == 201, r.text
    run_id = r.json()["id"]

    detail = client.get(f"/api/v1/runs/{run_id}", headers=headers).json()
    assert detail["state"] == "awaiting_approval"
    assert detail["current_stage"] == "script_review"
    pending = client.get("/api/v1/approvals/pending", headers=headers).json()
    assert len(pending) == 1
    dec = client.post(
        f"/api/v1/approvals/{pending[0]['id']}/decision",
        json={"decision": "approved"},
        headers=headers,
    )
    assert dec.status_code == 200, dec.text
    moved = client.get(f"/api/v1/runs/{run_id}", headers=headers).json()
    assert moved["current_stage"] != "script_review" or moved["state"] == "completed"
