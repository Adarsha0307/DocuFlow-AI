"""MCP protocol tests: JSON-RPC handshake, tool listing, tool calls over HTTP."""

import os
import tempfile
import uuid
from datetime import UTC, datetime

os.environ["DATABASE_URL"] = "sqlite:///" + os.path.join(tempfile.gettempdir(), "docuflow_mcp.db")
os.environ["WORKFLOW_ENGINE"] = "local"

from fastapi.testclient import TestClient  # noqa: E402

from app.core.security import encode_access_token  # noqa: E402
from app.db.base import Base  # noqa: E402
from app.db.session import engine  # noqa: E402
from app.main import app  # noqa: E402
from app.models import Membership, Organization, Project, User  # noqa: E402

ORG_ID = uuid.uuid4()
USER_ID = uuid.uuid4()
PROJECT_ID = uuid.uuid4()
NOW = datetime.now(UTC)
TOKEN = encode_access_token(USER_ID)


def _fresh_db() -> None:
    Base.metadata.create_all(engine)
    with engine.begin() as conn:
        conn.execute(
            User.__table__.insert().values(
                id=USER_ID, email=f"mcp{uuid.uuid4().hex[:8]}@x.io",
                password_hash="x", email_verified=True,
                created_at=NOW, updated_at=NOW,
            )
        )
        conn.execute(
            Organization.__table__.insert().values(
                id=ORG_ID, name="Mcp Studio", slug="mcp-studio", created_by=USER_ID
            )
        )
        conn.execute(
            Membership.__table__.insert().values(
                id=uuid.uuid4(),
                organization_id=ORG_ID,
                user_id=USER_ID,
                role="owner",
                status="active",
                created_at=NOW,
                updated_at=NOW,
            )
        )
        conn.execute(
            Project.__table__.insert().values(
                id=PROJECT_ID,
                organization_id=ORG_ID,
                name="Mcp Doc",
                topic="polar bears",
                created_at=NOW,
                updated_at=NOW,
            )
        )


_fresh_db()

import pytest  # noqa: E402


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as test_client:
        yield test_client


def _invoke(client: TestClient, method: str, params: dict | None = None,
            request_id: str = "1") -> dict:
    headers = {"Authorization": f"Bearer {TOKEN}", "X-Org-Id": str(ORG_ID)}
    body: dict = {"jsonrpc": "2.0", "id": request_id, "method": method}
    if params is not None:
        body["params"] = params
    r = client.post("/api/v1/mcp", json=body, headers=headers)
    assert r.status_code == 200, r.text
    return r.json()


def test_initialize_and_tools_list(client: TestClient) -> None:
    init = _invoke(client, "initialize", {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {}})
    assert init["result"]["serverInfo"]["name"] == "docuflow-mcp"
    assert init["result"]["capabilities"]["tools"]["listChanged"] is False

    listed = _invoke(client, "tools/list", {})
    names = [t["name"] for t in listed["result"]["tools"]]
    assert {"docuflow_rag_search", "docuflow_run_status", "docuflow_script_list", "docuflow_run_start"} <= set(names)


def test_tool_call_run_start_and_status(client: TestClient) -> None:
    started = _invoke(client, "tools/call", {
        "name": "docuflow_run_start",
        "arguments": {"project_id": str(PROJECT_ID)},
    })
    text = started["result"]["content"][0]["text"]
    import json

    run = json.loads(text)
    assert run["state"] == "awaiting_approval"

    status = _invoke(client, "tools/call", {
        "name": "docuflow_run_status",
        "arguments": {"run_id": run["run_id"]},
    })
    status_json = json.loads(status["result"]["content"][0]["text"])
    assert status_json["current_stage"] == "script_review"
    assert any(s["stage"] == "topic_ideation" and s["status"] == "completed" for s in status_json["steps"])


def test_tool_error_returns_jsonrpc_error(client: TestClient) -> None:
    resp = _invoke(client, "tools/call", {
        "name": "docuflow_run_status",
        "arguments": {"run_id": "not-a-uuid"},
    })
    assert "error" in resp
    assert resp["error"]["code"] == -32602


def test_unknown_method_returns_jsonrpc_error(client: TestClient) -> None:
    resp = _invoke(client, "not_a_method", {})
    assert resp["error"]["code"] == -32601
