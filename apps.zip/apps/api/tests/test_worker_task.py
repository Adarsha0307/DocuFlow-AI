"""Worker task verification: exercises docuflow.execute_stage in eager mode.

Runs the exact code path a broker would invoke (task -> execute_step_task ->
settle + auto-advance) without a live Redis.
"""

import os
import sys
import tempfile
import uuid
from datetime import UTC, datetime

os.environ["DATABASE_URL"] = "sqlite:///" + os.path.join(tempfile.gettempdir(), "docuflow_worker.db")
os.environ["WORKFLOW_ENGINE"] = "local"

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..")))

import pytest  # noqa: E402
from apps.worker.worker.celery_app import celery_app  # noqa: E402

from app.db.base import Base  # noqa: E402
from app.db.session import SessionLocal  # noqa: E402
from app.models import (  # noqa: E402
    Membership,
    Organization,
    Project,
    User,
    WorkflowRun,
    WorkflowStep,
)
from app.models.enums import RunState, StepStatus  # noqa: E402
from app.workflow.engine import RunController  # noqa: E402


@pytest.fixture(scope="module")
def db():
    engine = SessionLocal().get_bind()
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    session = SessionLocal()
    yield session
    session.close()


def _seed(db) -> tuple[uuid.UUID, uuid.UUID]:
    user = User(email=f"w{uuid.uuid4().hex[:8]}@x.io", password_hash="x", email_verified=True)
    db.add(user)
    db.flush()
    org = Organization(name="Worker Studio", slug=f"w{uuid.uuid4().hex[:6]}", created_by=user.id)
    db.add(org)
    db.flush()
    db.add(Membership(organization_id=org.id, user_id=user.id, role="owner", status="active"))
    project = Project(
        organization_id=org.id, name="Worker Doc", topic="topic",
        created_by=user.id, created_at=datetime.now(UTC), updated_at=datetime.now(UTC),
    )
    db.add(project)
    db.commit()
    return org.id, project.id


def test_worker_task_executes_stage_and_engine_continues(db):
    celery_app.conf.task_always_eager = True
    org_id, project_id = _seed(db)
    run = RunController.create(db, org_id=org_id, project_id=project_id, automation_mode="manual")
    RunController(db, run).start()
    db.refresh(run)
    assert run.state == RunState.AWAITING_APPROVAL
    assert run.current_stage == "script_review"

    step = db.query(WorkflowStep).filter_by(run_id=run.id, stage="image_generation").one()
    assert step.status == StepStatus.PENDING

    result = celery_app.tasks["docuflow.execute_stage"].apply(
        kwargs={"run_id": str(run.id), "step_id": str(step.id)}
    )
    assert result.result == RunState.AWAITING_APPROVAL.value  # run stays gated at script_review

    db.expire_all()
    step = db.get(WorkflowStep, step.id)
    assert step.status == StepStatus.COMPLETED
    assert step.output_json

    run = db.get(WorkflowRun, run.id)
    assert run.state == RunState.AWAITING_APPROVAL
    assert run.current_stage == "script_review"
