"""End-to-end smoke test for the workflow engine (inline execution, SQLite).

Exercises: definition seeding, run creation, full linear advance, approval
gating, revision requeue, and completion.
"""

import uuid
from datetime import UTC, datetime

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.db.base import Base
from app.models import Approval, WorkflowStep
from app.models.enums import RunState, StepStatus
from app.workflow.definitions import seed_system_definitions
from app.workflow.engine import RunController, advance_run_after_approval
from app.workflow.stages import APPROVAL_AS_NODE


@pytest.fixture()
def db():
    engine = create_engine("sqlite+pysqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    session = factory()
    yield session
    session.close()
    engine.dispose()


def _org_project_ids(db) -> tuple[uuid.UUID, uuid.UUID]:
    from app.models import Organization, Project

    org = Organization(name="Test Studio", slug="test-studio")
    db.add(org)
    db.flush()
    project = Project(name="Untold Story", organization_id=org.id, topic="The lost city of gold")
    db.add_all([org, project])
    db.commit()
    return org.id, project.id


def test_seed_system_definition(db):
    definition = seed_system_definitions(db)
    assert definition.slug == "default_documentary_2d"
    nodes = definition.flow_json["nodes"]
    assert nodes[0]["id"] == "start"
    assert nodes[-1]["id"] == "end"
    stages = [n["stage"] for n in nodes if n.get("stage")]
    assert stages[0] == "topic_ideation"
    assert stages[-1] == "retention_feedback"
    assert len(stages) == len(set(stages))


def test_full_run_manual_approvals(db):
    org_id, project_id = _org_project_ids(db)
    run = RunController.create(
        db, org_id=org_id, project_id=project_id, automation_mode="manual"
    )
    db.commit()
    RunController(db, run).start()
    db.refresh(run)
    assert run.state == RunState.AWAITING_APPROVAL
    assert run.current_stage == "script_review"

    # walk through every approval gate manually
    gates = list(APPROVAL_AS_NODE.keys())
    for i, gate_stage in enumerate(gates):
        db.refresh(run)
        assert run.state == RunState.AWAITING_APPROVAL, run.state
        assert run.current_stage == gate_stage, (i, run.current_stage)
        step = db.query(WorkflowStep).filter_by(run_id=run.id, stage=gate_stage).one()
        approval = db.query(Approval).filter_by(run_id=run.id, stage=gate_stage).one()
        approval.state = "approved"
        approval.decided_at = datetime.now(UTC)
        step.status = StepStatus.APPROVED
        db.commit()
        advance_run_after_approval(db, run.id)
        db.refresh(run)

    assert run.state == RunState.COMPLETED
    steps = db.query(WorkflowStep).filter_by(run_id=run.id).all()
    assert all(s.status == StepStatus.COMPLETED for s in steps)
    assert run.total_cost_usd > 0


def test_full_auto_run(db):
    org_id, project_id = _org_project_ids(db)
    run = RunController.create(db, org_id=org_id, project_id=project_id,
                               automation_mode="full")
    RunController(db, run).start()
    db.refresh(run)
    assert run.state == RunState.COMPLETED
    assert run.current_stage is None


def test_revision_requeues_producer(db):
    org_id, project_id = _org_project_ids(db)
    run = RunController.create(db, org_id=org_id, project_id=project_id,
                               automation_mode="manual")
    RunController(db, run).start()
    db.refresh(run)
    assert run.current_stage == "script_review"

    step = db.query(WorkflowStep).filter_by(run_id=run.id, stage="script_review").one()
    RunController(db, run).revise(step, "Make the hook stronger")
    db.refresh(run)
    # Inline mode: the producer re-ran immediately and the run re-gated on review.
    assert run.state == RunState.AWAITING_APPROVAL
    approvals = db.query(Approval).filter_by(run_id=run.id, stage="script_review").count()
    assert approvals >= 2  # fresh approval requested after revision
